import { lib, game, ui, get, ai, _status } from "noname"

export async function precontent() {
    game.playshuoyeMP4 = function (name, time, book, player) {
        if (game.getFileList) {
            if (game.me && game.me.name) var gameOn = true;
            if (gameOn) game.pause();
            //ui.arena.hide();
            if (!book) ui.backgroundMusic.pause();
            let video = document.createElement("video");
            video.setAttribute("autoplay", "autoplay");
            video.src = lib.assetURL + "extension/朔夜/" + name + ".mp4?t=" + Date.now();
            player.node.avatar.appendChild(video);
            video.style.margin = "0";
            video.style.width = "100%";
            video.style.height = "100%";
            video.style.left = '0px';
            video.style.top = '0px';
            video.style.position = "absolute";
            video.style.zIndex = 6;
            video.style.backgroundSize = "cover";
            video.style.objectFit = 'fill';
            let time1 = setTimeout(
                function () {
                    if (time) {
                        player.node.avatar.removeChild(video);
                        if (gameOn) game.resume();
                        ui.arena.show();
                        ui.backgroundMusic.play();
                    }
                }, (time) + 300);
            video.onended = () => {
                if (typeof time1 != 'undefined')
                    clearInterval(time1)
                player.node.avatar.removeChild(video);
                //ui.arena.show();
                game.resume()
            };
            video.addEventListener("loadedmetadata", function () {
                this.onclick = function () {
                    this.currentTime = this.duration;
                    if (typeof time1 != 'undefined')
                        clearInterval(time1)
                }
            });
            return video
        }
    };
    let precontentJS=['character/index.js',];
    Promise.all(
        precontentJS.map(path => import('../' + path))
    ).then(modules => {
        console.log('ok!')
    }).catch(error => {
        alert('error ' + error + '导入失败 !')
        console.error(error.message);
    });
    lib.arenaReady.push(() => {
        if (get.mode() == "boss") {
            lib.character.shuoye_u_aoerjiamali.isBoss = true;
        }
    });
    
}