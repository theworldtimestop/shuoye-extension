import { lib, game, ui, get, ai, _status } from '../../../../noname.js';

export const config = {}

export const help = {

}
export const files = {
    "character": [], "card": [], "skill": []
}