import { lib, game, ui, get, ai, _status } from '../../../../noname.js'

export const Package = {
    character: {},
    skill: {},
    intro: ``,
    author: `朔夜`,
    diskURL: "",
    forumURL: "",
    version: "0.01",
}