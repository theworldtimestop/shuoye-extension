import { lib, game, ui, get, ai, _status } from "noname"

const dynamicTranslates = {
	shuoyeweilian(player, skill) {
		const bool = player.storage[skill];
        let yang = "你受到大于一的伤害后[阴]:你造成的伤害+1。可将任意牌当【酒】、【杀】使用或打出。",
            yin = "造成大于一伤害后[阳]:你获得牌时摸一张牌，体力上限+1。";
        if (bool) {
            yin = `<span class='bluetext'>${yin}</span>`;
        } else {
            yang = `<span class='firetext'>${yang}</span>`;
        }
        let start = `转换技，初始阳`,
            end = `你每轮首次切换形态后开启一轮${get.poptip("shuoyeliangjie")}。`;
        return `${start}①${yang}②${yin}${end}`;
	},
};
export default dynamicTranslates;
