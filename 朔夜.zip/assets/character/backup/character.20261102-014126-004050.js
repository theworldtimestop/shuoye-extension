const characters = {
//#noname-kit-begin character:shuoye_miaoshitiannv
    shuoye_miaoshitiannv: ["female", "shen", 3, ["shuoyefushi", "shuoyeweilian"], []],
//#noname-kit-end character:shuoye_miaoshitiannv
//#noname-kit-begin character:shuoye_wutiaowu
    shuoye_wutiaowu: ["male", "wei", 4, ["shuoyexiaxian", "shuoyeshushi", "shuoyewuliang"], []],
//#noname-kit-end character:shuoye_wutiaowu
//#noname-kit-begin character:shuoye_u_aoerjiamali
    shuoye_u_aoerjiamali: ["female", "shen", 4, ["shuoye_xuanyan", "shuoye_jingtian", "shuoye_zhongji", "shuoye_ruli"], []],
//#noname-kit-end character:shuoye_u_aoerjiamali
//#noname-kit-begin character:shuoye_tianqixinghun
    shuoye_tianqixinghun: ["female", "shen", 3, ["shuoyexingqi", "shuoyemengjue", "shuoyezhouke", "shuoyetaixu"], []],
//#noname-kit-end character:shuoye_tianqixinghun
//#noname-kit-begin character:shuoye_zuguoren
    shuoye_zuguoren: ["male", "shen", 4, ["shuoyechaoneng", "shuoyeqiuxin", "shuoyedengshen"], []],
//#noname-kit-end character:shuoye_zuguoren
//#noname-kit-begin character:shuoye_puqishenfu
    shuoye_puqishenfu: ['male', 'shu', 3, ['shuoye_baishe'], []],
//#noname-kit-end character:shuoye_puqishenfu
//#noname-kit-begin character:shuoye_xier
    shuoye_xier: ['female', 'wei', '3/6', ['shuoye_shuangsheng', 'shuoye_yongheng', 'shuoye_laoyin'], []],
//#noname-kit-end character:shuoye_xier
//#noname-kit-begin character:shuoye_shuoye
    shuoye_shuoye: ['female', 'wei', 3, ['shuoye_guanxing', 'shuoye_jiugong', 'shuoye_wuxing', 'shuoye_bazhen'], []],
//#noname-kit-end character:shuoye_shuoye
//#noname-kit-begin character:shuoye_kongzhilvzhe
    shuoye_kongzhilvzhe: ['female', 'shu', 3, ['shuoye_benghuai', 'shuoye_yakong', 'shuoye_zhendang', 'shuoye_xujie'], []],
//#noname-kit-end character:shuoye_kongzhilvzhe
//#noname-kit-begin character:shuoye_fuhua
    shuoye_fuhua: ['female', 'shu', '2/7', ['shuoye_xianzong', 'shuoye_tianya', 'shuoye_fusheng', 'shuoye_duchen'], []],
//#noname-kit-end character:shuoye_fuhua
//#noname-kit-begin character:shuoye_xingti
    shuoye_xingti: ['female', 'shen', 4, ['shuoye_kuanghuan', 'shuoye_lianjin'], []],
//#noname-kit-end character:shuoye_xingti
//#noname-kit-begin character:shuoye_yuanlv
    shuoye_yuanlv: ['female', 'wei', 4, ['shuoye_qunxing', 'shuoye_qinxian', 'shuoye_shangbian', 'shuoye_xiezou'], ['forbid']],
//#noname-kit-end character:shuoye_yuanlv
//#noname-kit-begin character:shuoye_ying
    shuoye_ying: ['female', 'jin', 3, ['shuoye_zhuyuan', 'shuoye_eyao', 'shuoye_jingtu', 'shuoye_yimeng'], []],
//#noname-kit-end character:shuoye_ying
//#noname-kit-begin character:shuoye_diyabolo
    shuoye_diyabolo: ['male', 'shu', 4, ['dybl_shishan', 'dybl_muming', 'dybl_mengyan'], []],
//#noname-kit-end character:shuoye_diyabolo
//#noname-kit-begin character:shuoye_wenyang
    shuoye_wenyang: ['female', 'jin', '3/4/1', ['shuoye_quedi', 'shuoye_zhuifeng', 'shuoye_choujue'], []],
//#noname-kit-end character:shuoye_wenyang
//#noname-kit-begin character:shuoye_luxi
    shuoye_luxi: ['female', 'qun', 3, ['shuoye_diedai', 'shuoye_shouheng', 'shuoye_lichang'], ['zhu']],
//#noname-kit-end character:shuoye_luxi
//#noname-kit-begin character:shuoye_zhende
    shuoye_zhende: ['female', 'qun', '2/3/1', ['shuoye_tuji', 'shuoye_chouyan', 'shuoye_molong', 'shuoye_nupao'], []],
//#noname-kit-end character:shuoye_zhende
//#noname-kit-begin character:shuoye_aertuoliya
    shuoye_aertuoliya: ['female', 'qun', 3, ['shuoye_feichi', 'shuoye_zhuangtian', 'shuoye_yuedan', 'shuoye_ranshao'], []],
//#noname-kit-end character:shuoye_aertuoliya
//#noname-kit-begin character:shuoye_taikongyishitaer
    shuoye_taikongyishitaer: ['female', 'shen', '3/4', ['shuoye_yuanchu', 'shuoye_xinghuan', 'shuoye_shenhe', 'shuoye_shanyao'], []],
//#noname-kit-end character:shuoye_taikongyishitaer
//#noname-kit-begin character:shuoye_kongqirinai
    shuoye_kongqirinai: ['female', 'jin', 3, ['shuoye_zhongzhuang', 'shuoye_zhongmu', 'shuoye_lengjing', 'shuoye_fengji'], []],
//#noname-kit-end character:shuoye_kongqirinai
//#noname-kit-begin character:shuoye_huangquan
    shuoye_huangquan: ['female', 'jin', '3/4', ['shuoye_sixiang', 'shuoye_santu', 'shuoye_yuzhan', 'shuoye_fandu'], []],
//#noname-kit-end character:shuoye_huangquan
//#noname-kit-begin character:shuoye_feiniaomashi
    shuoye_feiniaomashi: ['female', 'wei', 3, ['shuoye_jijia', 'shuoye_zhongzhan'], []],
//#noname-kit-end character:shuoye_feiniaomashi
//#noname-kit-begin character:shuoye_ailisi
    shuoye_ailisi: ['female', 'wei', 3, ['shuoye_qingsao', 'shuoye_zhongshen', 'shuoye_guanga'], []],
//#noname-kit-end character:shuoye_ailisi
//#noname-kit-begin character:shuoye_xugouji
    shuoye_xugouji: ['female', 'wu', '3/4/1', ['shuoye_yixiang', 'shuoye_yinyu', 'shuoye_migong', 'shuoye_xugou'], []],
//#noname-kit-end character:shuoye_xugouji
//#noname-kit-begin character:shuoye_fengchuanxiangzi
    shuoye_fengchuanxiangzi: ['female', 'wei', '3/3/1', ['shuoye_yuqi', 'shuoye_weituan', "shuoye_renou"], []],
//#noname-kit-end character:shuoye_fengchuanxiangzi
//#noname-kit-begin character:shuoye_chongtiansiling
    shuoye_chongtiansiling: ['female', 'qun', '2/4/1', ['shuoye_wuming', 'shuoye_suodi', "shuoye_juedao"], []],
//#noname-kit-end character:shuoye_chongtiansiling
//#noname-kit-begin character:shuoye_weiershi
    shuoye_weiershi:['female','wei',3,['shuoye_wanxiang','shuoye_qiyuan'],[]],
//#noname-kit-end character:shuoye_weiershi
};

export default characters;
