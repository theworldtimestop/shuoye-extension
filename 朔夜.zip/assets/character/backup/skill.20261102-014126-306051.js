import { lib, game, ui, get, ai, _status } from "noname";

/** @type { importCharacterConfig['skill'] } */
const skills = {
    //妙时天女
//#noname-kit-begin skill:shuoyefushi
    shuoyefushi: {
        trigger: {
            global: "roundStart",
        },
        locked: true,
        async cost(event, trigger, player) {
            event.result = await player.chooseTarget({
                prompt: `你发动【${get.translation(event.skill)}】`,
                prompt2: "选择获得场上其他角色的一个技能。然后若以此法获得技能数不小于三，需再选择失去一个获得的技能",
                forced: true,
                filterTarget(card, player2, target) {
                    if (target === player2) return false;
                    return target.getSkills(null, false, false).filter((skill) => {
                        if (player2.hasSkill(skill)) return false;
                        const info = get.info(skill);
                        return info && !info.charlotte;
                    }).length > 0;
                },
                ai(target) {
                    const { player: player2, filterTarget } = get.event();
                    const targets = game.filterPlayer((target2) => filterTarget(null, player2, target2));
                    return Math.max(
                        ...targets.map((target2) => {
                            const skills2 = target2.getSkills(null, false, false).filter((skill) => {
                                if (player2.hasSkill(skill)) return false;
                                const info = get.info(skill);
                                return info && !info.charlotte;
                            });
                            return Math.max(...skills2.map((skill) => get.skillRank(skill)));
                        })
                    );
                }
            }).forResult();
        },
        async content(event, trigger, player) {
            const target = event.targets[0];
            const skills2 = target.getSkills(null, false, false).removeArray(player.getSkills(null, false, false)).filter((skill) => {
                const info = get.info(skill);
                return info && !info.charlotte;
            });
            if (skills2.length) {
                const list = [];
                for (let skill of skills2) {
                    list.push([skill, `<div class="popup text" style="width:calc(100% - 10px);display:inline-block"><div class="skill">【` + get.translation(skill) + "】</div><div>" + lib.translate[skill + "_info"] + "</div></div>"]);
                }
                const result = skills2.length > 1 ? await player.chooseButton({
                    createDialog: [`${get.translation(event.name)}：请获得一个技能`, [list, "textbutton"]],
                    forced: true,
                    ai(button) {
                        const info = get.info(button.link);
                        if (!info || info.ai && (info.ai.combo || info.ai.notemp || info.ai.neg)) {
                            return 0;
                        }
                        return 1 + Math.random();
                    }
                }).forResult() : { bool: true, links: skills2 };
                if (result?.bool && result.links?.length) {
                    const skill = result.links[0];
                    await player.addAdditionalSkills(event.name, skill, true);
                    if (player.additionalSkills?.[event.name]?.length >= 3) {
                        const skills2 = player.additionalSkills?.[event.name];
                        const list = [];
                        for (let skill of skills2) {
                            list.push([skill, `<div class="popup text" style="width:calc(100% - 10px);display:inline-block"><div class="skill">【` + get.translation(skill) + "】</div><div>" + lib.translate[skill + "_info"] + "</div></div>"]);
                        }
                        const result = skills2.length > 1 ? await player.chooseButton({
                            createDialog: [`${get.translation(event.name)}：请失去一个技能`, [list, "textbutton"]],
                            forced: true,
                            ai(button) {
                                const info = get.info(button.link);
                                if (!info || info.ai && (info.ai.combo || info.ai.notemp || info.ai.neg)) {
                                    return 0;
                                }
                                return 1 + Math.random();
                            }
                        }).forResult() : { bool: true, links: skills2 };
                        if (result?.bool && result.links?.length) {
                            const skill = result.links[0];
                            await player.removeAdditionalSkills(event.name, skill);
                        }
                    }
                }
            }
        },
    },
//#noname-kit-end skill:shuoyefushi
//#noname-kit-begin skill:shuoyeweilian
    shuoyeweilian: {
        derivation: "shuoyeliangjie",
        mark: true,
        marktext: "☯",
        zhuanhuanji(player, skill) {
            player.storage[skill] = !player.storage[skill];
            player.changeSkin({ characterName: "shuoye_miaoshitiannv" }, `shuoye_miaoshitiannv${player.storage[skill] ? "_shadow" : ""}`);
        },
        intro: {
            content(storage) {
                if (storage) {
                    return "你受到大于一的伤害后[阴]:你造成的伤害+1。可将任意牌当【酒】、【杀】使用或打出。";
                }
                return "造成大于一伤害后[阳]:你获得牌时摸一张牌，体力上限+1，然后切换为[阴]";
            },
        },
        enable: ["chooseToUse", "chooseToRespond"],
        filter(event, player, name) {
            if (!player.countCards("hes") || !player.storage.shuoyeweilian) {
                return false;
            }
            return get.inpileVCardList(info => {
                const name = info[2];
                return ["jiu", "sha"].includes(name);
            })
                .some(card => event.filterCard({ name: card[2], nature: card[3] }, player, event));
        },
        prompt: "可将任意牌当【酒】、【杀】使用或打出",
        chooseButton: {
            dialog(event, player) {
                const list = get.inpileVCardList(info => {
                    const name = info[2];
                    return ["jiu", "sha"].includes(name);
                }).filter(card => event.filterCard({ name: card[2], nature: card[3] }, player, event));
                const dialog = ui.create.dialog(get.translation("shuoyeweilian"), [list, "vcard"]);
                dialog.direct = true;
                return dialog;
            },
            check(button) {
                if (_status.event.getParent().type != "phase") return 1;
                const player = get.player();
                return player.getUseValue({
                    name: button.link[2],
                    nature: button.link[3],
                });
            },
            backup(links, player) {
                return {
                    viewAs: {
                        name: links[0][2],
                        nature: links[0][3],
                    },
                    filterCard: true,
                    position: "hes",
                    ai1(card) {
                        return 8 - get.value(card);
                    },
                    log: false,
                    async precontent(event, trigger, player) {
                        player.logSkill("shuoyeweilian");
                    },
                }
            },
            prompt(links, player) {
                return "将一张牌当做" + (get.translation(links[0][3]) || "") + get.translation(links[0][2]) + "使用或打出";
            },
        },
        hiddenCard(player, name) {
            if (get.type(name) != "basic" || !player.countCards("hes") || !player.storage.shuoyeweilian) return false;
            return ["jiu", "sha"].includes(name);
        },
        ai: {
            respondSha: true,
            order(item, player) {
                if (player && get.event().type == "phase") {
                    let list = get
                        .inpileVCardList(info => {
                            const name = info[2];
                            return ["jiu", "sha"].includes(name);
                        })
                        .map(card => {
                            return { name: card[2], nature: card[3] };
                        })
                        .filter(card => player.getUseValue(card, true, true) > 0);
                    if (!list.length) return 0;
                    list.sort((a, b) => (player.getUseValue(b, true, true) || 0) - (player.getUseValue(a, true, true) || 0));
                    return get.order(list[0], player) * 0.99;
                }
                return 0.001;
            },
            result: {
                player(player) {
                    if (_status.event.dying) {
                        return get.attitude(player, _status.event.dying);
                    }
                    return 1;
                },
            },
        },
        group: ["shuoyeweilian_yang", "shuoyeweilian_yin", "shuoyeweilian_change"],
        subSkill: {
            yang: {
                trigger: {
                    source: "damageSource",
                    player: "gainAfter",
                    global: "loseAsyncAfter",
                },
                forced: true,
                locked: false,
                filter(event, player) {
                    if (event.name == "damage") {
                        if (!player.storage.shuoyeweilian) {
                            return false;
                        }
                        return event.num > 1;
                    }
                    if (player.storage.shuoyeweilian) {
                        return false;
                    }
                    return event.getg?.(player)?.length > 0;
                },
                async content(event, trigger, player) {
                    await player.changeZhuanhuanji("shuoyeweilian");
                    if (trigger.name != "damage") {
                        await player.draw();
                        await player.gainMaxHp();
                    }
                },
            },
            yin: {
                trigger: {
                    player: "damageEnd",
                    source: "damageBegin1",
                },
                forced: true,
                locked: false,
                filter(event, player, name) {
                    if (name == "damageEnd") {
                        if (player.storage.shuoyeweilian) {
                            return false;
                        }
                        return event.num > 1;
                    }
                    if (!player.storage.shuoyeweilian) {
                        return false;
                    }
                    return true;
                },
                async content(event, trigger, player) {
                    await player.changeZhuanhuanji("shuoyeweilian");
                    if (event.triggername == "damageBegin1") {
                        trigger.num++;
                        game.log(player, "造成的伤害", "#y+1");
                    }
                },
            },
            change: {
                trigger: {
                    player: "changeZhuanhuanji",
                },
                forced: true,
                locked: false,
                filter(event, player) {
                    return event.skill == "shuoyeweilian" && game.getRoundHistory("everything", evt => {
                        return evt.name == "changeZhuanhuanji" && evt.player == player && evt.skill == "shuoyeweilian";
                    }).indexOf(event) == 0;
                },
                async content(event, trigger, player) {
                    player.addTempSkill("shuoyeliangjie", "roundStart");
                },
            },
            backup: {},
        },
    },
//#noname-kit-end skill:shuoyeweilian
//#noname-kit-begin skill:shuoyeliangjie
    shuoyeliangjie: {
        mod: {
            cardUsable(card, player, num) {
                if (player.isTempBanned("shuoyeliangjie")) {
                    return;
                }
                return Infinity;
            },
        },
        trigger: {
            source: "damageSource",
        },
        forced: true,
        async content(event, trigger, player) {
            await player.loseHp();
            await player.draw();
        },
        group: "shuoyeliangjie_block",
        subSkill: {
            block: {
                trigger: {
                    global: "dying",
                },
                forced: true,
                async content(event, trigger, player) {
                    player.removeSkill("shuoyeliangjie");
                },
            },
        },
    },
//#noname-kit-end skill:shuoyeliangjie
    //五条悟
//#noname-kit-begin skill:shuoyexiaxian
    shuoyexiaxian: {
        trigger: {
            global: "useCardAfter",
        },
        forced: true,
        locked: false,
        filter(event, player) {
            return event.targets?.length && event.targets.includes(player);
        },
        async content(event, trigger, player) {
            const skill = "shuoyexiaxian_distance";
            player.addTempSkill(skill, "roundStart");
            const list = player.getStorage(skill);
            player.setStorage(skill, list.concat([trigger.player]), true);
        },
        subSkill: {
            distance: {
                intro: {
                    markcount: () => null,
                    content(storage, player) {
                        if (!storage || !storage.length) {
                            return "无记录";
                        }
                        let str = "本轮游戏：";
                        for (const target of game.players) {
                            if (storage.includes(target)) {
                                str += `<br>${get.translation(target)}计算与你的距离+${storage.filter((i) => i === target).length}`;
                            }
                        }
                        return str;
                    },
                },
                onremove: true,
                mod: {
                    globalTo(from, to, distance) {
                        return distance + to.getStorage("shuoyexiaxian_distance")?.filter((i) => i === from)?.length;
                    },
                },
            },
        },
    },
//#noname-kit-end skill:shuoyexiaxian
//#noname-kit-begin skill:shuoyeshushi
    shuoyeshushi: {
        enable: "phaseUse",
        usable: 1,
        filterTarget: true,
        async content(event, trigger, player) {
            const target = event.target;
            const list = [];
            list.push("你摸两张牌");
            if (target.countDiscardableCards(player, "he")) {
                list.push("弃置其一张牌");
            }
            if (player.hp > 0) {
                list.push("背水！");
            }
            const result = await player
                .chooseControl(list)
                .set("prompt", `你对${get.translation(target)}发动${get.translation(event.name)}：选择执行一项，视为对其使用火攻`)
                .set("ai", () => {
                    const { player, target } = get.event();
                    const controls = get.event().controls.slice();
                    const bool1 = get.effect(player, { name: "draw" }, player, player) * 2 > 0;
                    const bool2 = get.effect(target, { name: "guohe_copy2" }, player, player) > 0;
                    if (bool1 && bool2 && player.getHp() + player.countCards("hs", card => player.canSaveCard(card, player)) > 2) {
                        return "背水！";
                    }
                    if (bool1) {
                        return "你摸两张牌";
                    }
                    if (bool2) {
                        return "弃置其一张牌";
                    }
                })
                .set("target", target)
                .forResult();
            const control = result.control;
            if (control == "你摸两张牌" || control == "背水！") {
                await player.draw(2);
            }
            if (control == "弃置其一张牌" || control == "背水！") {
                await player.discardPlayerCard(target, "he", true);
            }
            if (control == "背水！") {
                await player.loseHp();
                await target.loseHp();
            }
            const card = new lib.element.VCard({ name: "huogong" });
            if (player.canUse(card, target)) {
                await player.useCard(card, target);
            }
        },
        ai: {
            order() {
                return get.order({ name: "huogong" }) + 0.5;
            },
            result: {
                target(player, target) {
                    const card = new lib.element.VCard({ name: "huogong" });
                    if (player.hasSkill("shuoyewuliang_block") && target == player) {
                        return 2;
                    }
                    return Math.min(-2, get.effect(target, card, player, target));
                },
            },
        },
    },
//#noname-kit-end skill:shuoyeshushi
//#noname-kit-begin skill:shuoyewuliang
    shuoyewuliang: {
        enable: "phaseUse",
        usable: 1,
        filterTarget: true,
        async content(event, trigger, player) {
            const target = event.target;
            await target.drawTo(target.maxHp);
            target.addSkill("shuoyewuliang_block");
        },
        ai: {
            order: (item, player) => {
                if (game.hasPlayer((cur) => {
                    if (player === cur || get.attitude(player, cur) <= 0) {
                        return false;
                    }
                    return Math.min(5, cur.maxHp) - cur.countCards("h") > 2;
                })) {
                    return get.order({ name: "nanman" }, player) - 0.1;
                }
                return 10;
            },
            result: {
                target(player, target) {
                    if (get.attitude(player, target) > 0) {
                        return Math.max(0, target.maxHp - target.countCards("h")) - 3;
                    }
                    if (Math.max(0, target.maxHp - target.countCards("h")) <= 1 && target.countCards("h", "shan") && !target.hasSkillTag("respondShan", true, null, true) && player.countCards("h", function (card) {
                        return get.tag(card, "respondShan") && player.getUseValue(card, null, true) > 0 && get.effect(target, card, player, player) > 0;
                    })) {
                        return -2;
                    }
                },
            },
        },
        subSkill: {
            block: {
                mark: true,
                intro: {
                    content: "不能使用手牌且跳过弃牌阶段直到受到伤害",
                },
                charlotte: true,
                mod: {
    cardEnabled(card, player) {
        // 如果这次使用的牌包含手牌，则禁止
        if (card.cards && card.cards.length) {
            if (card.cards.some(cardx => get.position(cardx, true) == 'h')) {
                return false;
            }
        }
        // 如果 card 本身就是一张手牌，也禁止
        else if (get.itemtype(card) == 'card' && get.position(card, true) == 'h') {
            return false;
        }
        // 虚拟牌、装备区牌等不禁止
    },
},
                trigger: {
                    player: ["phaseDiscardBefore", "damageEnd"],
                },
                silent: true,
                async content(event, trigger, player) {
                    if (trigger.name == "phaseDiscard") {
                        trigger.cancel();
                    } else {
                        player.removeSkill(event.name);
                    }
                },
                ai: {
                    maixie: true,
                    effect: {
                        target(card, player, target, current) {
                            if (!get.tag(card, "damage")) {
                                return;
                            }
                            if (target.hp < 2 || player.hasSkillTag("jueqing", false, target)) {
                                return 1.5;
                            }
                            return [1, 0.8];
                        },
                    },
                },
            },
        },
    },
//#noname-kit-end skill:shuoyewuliang
    //U-奥尔加玛丽
//#noname-kit-begin skill:shuoye_xuanyan
    shuoye_xuanyan: {
        trigger: {
            global: "roundStart",
        },
        locked: true,
        async cost(event, trigger, player) {
            const list = lib.suit.slice().map(suit => [suit, get.translation(suit)]);
            event.result = await player
                .chooseButton([get.prompt2(event.skill), [list, "tdnodes"]], 2, true)
                .set("ai", button => {
                    return 1 + Math.random();
                })
                .forResult();
            if (event?.result?.links?.length) {
                event.result.cost_data = event.result.links;
            }
        },
        async content(event, trigger, player) {
            player.addTempSkill("shuoye_xuanyan_effect", "roundStart");
            player.markAuto("shuoye_xuanyan_effect", event.cost_data);
            player.addTip("shuoye_xuanyan_effect", get.translation("shuoye_xuanyan_effect") + player.getStorage("shuoye_xuanyan_effect").reduce((str, type) => str + get.translation(type), ""));
        },
        subSkill: {
            effect: {
                trigger: {
                    target: "useCardToTarget",
                    player: "useCardToPlayer",
                },
                forced: true,
                charlotte: true,
                onremove(player, skill) {
                    delete player.storage[skill];
                    player.removeTip(skill);
                },
                filter(event, player) {
                    if (event.name == "useCardToTarget") {
                        return event.player != player && player.getStorage("shuoye_xuanyan_effect").includes(get.suit(event.card));
                    }
                    return event.target != player && event.target.hasDiscardableCards(player, "h");
                },
                async content(event, trigger, player) {
                    if (trigger.name == "useCardToTarget") {
                        trigger.getParent().targets.remove(player);
                        game.log(trigger.card, "对", player, "无效");
                    } else {
                        const cards = trigger.target.getDiscardableCards(player, "h", card => {
                            return player.getStorage("shuoye_xuanyan_effect").includes(get.suit(card, trigger.target));
                        });
                        if (cards.length) {
                            await trigger.target.discard(cards).set("discarder", player);
                        }
                    }
                },
                ai: {
                    effect: {
                        target(card, player, target, current) {
                            if (target != player && target.getStorage("shuoye_xuanyan_effect").includes(get.suit(card))) {
                                return "zeroplayertarget";
                            }
                        },
                    },
                },
                mark: true,
                intro: {
                    markcount: () => 0,
                    content: "本轮其他角色使用$牌对你无效，你对其他角色使用牌时弃置其手中$的牌。",
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_xuanyan
//#noname-kit-begin skill:shuoye_jingtian
    shuoye_jingtian: {
        enable: "phaseUse",
        limited: true,
        async content(event, trigger, player) {
            player.awakenSkill(event.name);
            if (player.hasSkill("shuoye_ruli_buff")) {
                await player.recoverTo(player.maxHp);
            } else {
                await player.loseHp();
            }
            const num = player.maxHp - player.countCards("h");
            if (num <= 0) {
                return;
            }
            await player.drawTo(player.maxHp);
            const result = await player
                .chooseTarget(get.prompt(event.name), `令一名角色失去${num}点体力`, true)
                .set("ai", target => {
                    const player = get.player();
                    return get.effect(target, { name: "losehp" }, player, player);
                })
                .forResult();
            if (result?.targets?.length) {
                const [target] = result.targets;
                const next = target.loseHp(num);
                await next;
                if (!game.hasGlobalHistory("everything", evt => {
                    return evt.name == "die" && evt.player == target && evt.getParent("loseHp") == next;
                })) {
                    player.when("phaseBegin")
                        .then(() => {
                            player.refreshSkill("shuoye_jingtian");
                        });
                }
            }
        },
        ai: {
            order: 1,
            result: {
                player(player) {
                    if (player.isMaxHandcard() || player.isMaxHp()) {
                        return 0;
                    }
                    return player.maxHp - player.countCards("h");
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_jingtian
//#noname-kit-begin skill:shuoye_zhongji
    shuoye_zhongji: {
        trigger: {
            global: ["loseAfter", "loseAsyncAfter"],
        },
        forced: true,
        locked: false,
        persevereSkill: true,
        getIndex(event, player) {
            if (event.type !== "discard" || event.getlx === false) return [];
            return game.filterPlayer(target => {
                const evt = event.getl?.(target);
                return evt?.cards2?.some(card => {
                    const suit = get.suit(card, target);
                    return player.getStorage("shuoye_xuanyan_effect").includes(suit);
                });
            });
        },
        async content(event, trigger, player) {
            const target = event.indexedData;
            const cards = trigger.getl(target).cards2.filter(card => {
                const suit = get.suit(card, target);
                return player.getStorage("shuoye_xuanyan_effect").includes(suit);
            });
            if (cards.length) {
                player.addMark(event.name, cards.length);
            }
        },
        marktext: "U",
        intro: {
            name: "U",
            content: "mark",
        },
        group: ["shuoye_zhongji_use", "shuoye_zhongji_directHit"],
        subSkill: {
            use: {
                mod: {
                    cardUsable(card, player) {
                        if (player.countMark("shuoye_zhongji") >= get.cardNameLength(card)) {
                            return Infinity;
                        }
                    },
                    targetInRange(card, player, target) {
                        if (player.countMark("shuoye_zhongji") >= get.cardNameLength(card)) {
                            return true;
                        }
                    },
                },
                trigger: {
                    player: "useCard",
                },
                forced: true,
                locked: false,
                persevereSkill: true,
                filter(event, player) {
                    return player.countMark("shuoye_zhongji") >= get.cardNameLength(event.card);
                },
                async content(event, trigger, player) {
                    const num = get.cardNameLength(trigger.card);
                    trigger.baseDamage += num;
                    player.removeMark("shuoye_zhongji", num);
                    if (trigger.addCount !== false) {
                        game.log(trigger.card, "不计入次数限制");
                        trigger.addCount = false;
                        player.getStat().card[trigger.card.name]--;
                    }
                    trigger.directHit.addArray(game.filterPlayer());
                    await player.gainMaxHp(num);
                },
            },
            directHit: {
                trigger: {
                    target: "useCardToTargeted",
                },
                lastDo: true,
                forced: true,
                locked: false,
                persevereSkill: true,
                filter(event, player) {
                    if (event.player == player) {
                        return false;
                    }
                    return player.hasMark("shuoye_zhongji") && event.getParent().directHit.includes(player);
                },
                async content(event, trigger, player) {
                    while (trigger.getParent().directHit.includes(player)) {
                        trigger.getParent().directHit.remove(player);
                    }
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_zhongji
//#noname-kit-begin skill:shuoye_ruli
    shuoye_ruli: {
        persevereSkill: true,
        init(player, skill) {
            if (player.hasSkill("shuoye_ruli_buff")) {
                return;
            }
            if (get.mode() == "boss" || player.maxHp >= 100) {
                game.log(player, "激活", "#g〖人理〗");
                player.addSkill("shuoye_ruli_buff");
            }
        },
        trigger: {
            player: "gainMaxHpAfter",
        },
        forced: true,
        locked: false,
        filter(event, player) {
            return player.maxHp >= 100 && !player.hasSkill("shuoye_ruli_buff");
        },
        async content(event, trigger, player) {
            game.log(player, "激活", "#g〖人理〗");
            player.addSkill("shuoye_ruli_buff");
        },
        subSkill: {
            buff: {
                persevereSkill: true,
                trigger: {
                    player: ["dieBefore", "changeHpBegin"],
                },
                forced: true,
                charlotte: true,
                filter(event, player) {
                    if (event.name == "die") {
                        return event.getParent().name != "giveup";
                    }
                    return Math.abs(event.num) != 1;
                },
                async content(event, trigger, player) {
                    if (trigger.name == "die") {
                        trigger.cancel();
                        let maxHp = 1 - player.maxHp;
                        if (maxHp > 0) {
                            player.maxHp = maxHp;
                        }
                        let hp = 1 - player.hp;
                        if (hp > 0) {
                            player.hp = hp;
                        }
                        player.update();
                    } else {
                        trigger.num = get.sgn(trigger.num);
                    }
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_ruli
    //天启星魂
//#noname-kit-begin skill:shuoyexingqi
    shuoyexingqi: {
        persevereSkill: true,
        trigger: {
            global: "phaseBegin",
            player: "phaseJudgeBegin",
        },
        forced: true,
        locked: false,
        filter(event, player) {
            if (event.name == "phaseJudge") {
                return player.hasDiscardableCards(player, "j");
            }
            return true;
        },
        async content(event, trigger, player) {
            if (trigger.name == "phase") {
                const cards = get.cards();
                await game.cardsGotoOrdering(cards);
                await game.delay();
                const list = ["lebu", "bingliang"].filter(name => {
                    return player.canAddJudge({ name: name }, cards);
                });
                if (list.length) {
                    const name = list.randomGet();
                    await player.addJudge({ name: name }, cards);
                }
                await player.draw(player.countCards("j"));
            } else {
                await player.discard(player.getDiscardableCards(player, "j"));
            }
        },
    },
//#noname-kit-end skill:shuoyexingqi
//#noname-kit-begin skill:shuoyemengjue
    shuoyemengjue: {
        trigger: {
            global: "phaseBegin",
        },
        priority: -15,
        filter(event, player) {
            return (
                player.hasCards("j") &&
                game.hasPlayer(current => {
                    if (current == player) {
                        return false;
                    }
                    return player.getCards("j").some(card => current.canAddJudge(card));
                })
            );
        },
        async cost(event, trigger, player) {
            const result = await player
                .moveCard(
                    get.prompt2(event.skill),
                    player,
                    game.filterPlayer(current => {
                        return current != player && player.getCards("j").some(card => current.canAddJudge(card));
                    }),
                    card => get.position(card) == "j",
                )
                .set("logSkill", event.skill)
                .forResult();
            if (result?.bool) {
                event.result = {
                    bool: true,
                    cost_data: result.card,
                    skill_popup: false,
                };
            }
        },
        async content(event, trigger, player) {
            player.addTempSkill("shuoyemengjue_effect");
        },
        subSkill: {
            effect: {
                trigger: {
                    player: "changeHpBegin",
                },
                forced: true,
                charlotte: true,
                filter(event, player) {
                    return event.num < -1;
                },
                async content(event, trigger, player) {
                    trigger.num = -1;
                },
            },
        },
    },
//#noname-kit-end skill:shuoyemengjue
//#noname-kit-begin skill:shuoyezhouke
    shuoyezhouke: {
        trigger: {
            player: "loseAfter",
            global: ["equipAfter", "addJudgeAfter", "gainAfter", "loseAsyncAfter", "addToExpansionAfter"],
        },
        forced: true,
        locked: false,
        filter(event, player) {
            if (player.countMark("shuoyezhouke") >= 12) {
                return false;
            }
            let evt = event.getl?.(player);
            return evt?.js?.length;
        },
        async content(event, trigger, player) {
            player.addMark(event.name, 1, false);
            await player.gainMaxHp();
            await player.recover();
            if (player.countMark(event.name) == 12) {
                player.changeSkin({ characterName: "shuoye_tianqixinghun" }, "shuoye_tianqixinghun_shadow");
                player.addSkill("shuoyezhouke_effect");
            }
        },
        mark: true,
        intro: {
            content: "已转动#刻",
        },
        subSkill: {
            effect: {
                trigger: {
                    player: ["damageBegin4", "useCard"],
                },
                forced: true,
                locked: false,
                filter(event, player) {
                    return player.countMark("shuoyezhouke") == 12;
                },
                async content(event, trigger, player) {
                    if (trigger.name == "damage") {
                        trigger.cancel();
                    } else {
                        trigger.directHit.addArray(game.filterPlayer());
                    }
                },
            },
        },
    },
//#noname-kit-end skill:shuoyezhouke
//#noname-kit-begin skill:shuoyetaixu
    shuoyetaixu: {
        trigger: {
            source: "damageBegin1",
        },
        forced: true,
        locked: false,
        filter(event, player) {
            return player.hasCards("j") || player.hasMark("shuoyezhouke");
        },
        async content(event, trigger, player) {
            const num = player.countCards("j") + player.countMark("shuoyezhouke");
            trigger.num += num;
        },
    },
//#noname-kit-end skill:shuoyetaixu
    //祖国人
//#noname-kit-begin skill:shuoyechaoneng
    shuoyechaoneng: {
        mod: {
            cardUsable: () => Infinity,
            targetInRange: () => true,
        },
        trigger: {
            player: ["damageBegin3", "useCard"],
        },
        forced: true,
        locked: false,
        async content(event, trigger, player) {
            if (trigger.name == "damage") {
                trigger.num--;
            } else {
                await player.draw();
                trigger.baseDamage++;
            }
        },
    },
//#noname-kit-end skill:shuoyechaoneng
//#noname-kit-begin skill:shuoyeqiuxin
    shuoyeqiuxin: {
        trigger: {
            global: ["useCard", "respond"],
        },
        forced: true,
        filter(event, player) {
            if (!event.respondTo || !Array.isArray(event.respondTo)) {
                return false;
            }
            if (player != event.respondTo[0]) {
                return false;
            }
            return event.respondTo[1];
        },
        async content(event, trigger, player) {
            player.addTempSkill("fengyin");
            player
                .when("useCardAfter")
                .filter(evt => evt.card == trigger.respondTo[1])
                .then(async (event, trigger, player) => {
                    const targets = game.filterPlayer(target => target != player);
                    const func = async target => {
                        const result = await target.chooseToUse(
                            function (card, player2, event2) {
                                return lib.filter.filterCard.apply(this, arguments);
                            },
                            "求心：你可以对" + get.translation(player) + "使用一张牌"
                        ).set("targetRequired", true).set("complexSelect", true).set("complexTarget", true).set("filterTarget", function (card, player2, target2) {
                            if (target2 != _status.event.sourcex && !ui.selected.targets.includes(_status.event.sourcex)) {
                                return false;
                            }
                            return lib.filter.filterTarget.apply(this, arguments);
                        }).set("sourcex", player);
                    };
                    await game.doAsyncInOrder(targets, func);
                });
        },
    },
//#noname-kit-end skill:shuoyeqiuxin
//#noname-kit-begin skill:shuoyedengshen
    shuoyedengshen: {
        init(player, skill) {
            player.updates ??= [];
            game.shuoyedengshenCheck = player => {
                const num = player.getHandcardLimit();
                if (num >= 10) {
                    const next = game.createEvent("shuoyedengshenChange");
                    next.player = player;
                    next.setContent("emptyEvent");
                    player.updates.remove(game.shuoyedengshenCheck);
                }
            };
            player.updates.add(game.shuoyedengshenCheck);
        },
        onremove(player, skill) {
            player.updates.remove(game.shuoyedengshenCheck);
        },
        trigger: {
            player: "gainAfter",
            global: "loseAsyncAfter",
        },
        forced: true,
        locked: false,
        dutySkill: true,
        filter(event, player) {
            if (_status.currentPhase == player) {
                return false;
            }
            return event.getg && event.getg(player)?.length;
        },
        async content(event, trigger, player) {
            player.addSkill("shuoyedengshen_buff");
            player.addMark("shuoyedengshen_buff", 1, false);
            player.update();
        },
        group: ["shuoyedengshen_achieve", "shuoyedengshen_fail"],
        subSkill: {
            achieve: {
                trigger: {
                    player: "loseAfter",
                    global: ["equipAfter", "addJudgeAfter", "gainAfter", "loseAsyncAfter", "addToExpansionAfter"],
                },
                forced: true,
                locked: false,
                skillAnimation: true,
                animationColor: "fire",
                filter(event, player) {
                    if (player.hasCards("h")) {
                        return false;
                    }
                    const evt = event.getl(player);
                    return evt && evt.player === player && evt.hs && evt.hs.length > 0;
                },
                async content(event, trigger, player) {
                    player.awakenSkill("shuoyedengshen");
                    game.log(player, "成功完成使命");
                    await player.removeSkills("shuoyechaoneng");
                },
            },
            fail: {
                trigger: {
                    player: "shuoyedengshenChange",
                },
                forced: true,
                locked: false,
                async content(event, trigger, player) {
                    player.awakenSkill("shuoyedengshen");
                    game.log(player, "使命失败");
                    await player.removeSkills("shuoyeqiuxin");
                },
            },
            buff: {
                mod: {
                    maxHandcard(player, num) {
                        return num + player.countMark("shuoyedengshen_buff");
                    },
                },
            },
        },
    },
//#noname-kit-end skill:shuoyedengshen
    //薇尔诗
//#noname-kit-begin skill:shuoye_rongguang
    shuoye_rongguang: {
        trigger: {
            player: "dying",
        },
        forced: true,
        content: function () {
            "step 0"
            var num = player.maxHp - player.hp;
            player.recover(num);
            event.num = num;
            player.chooseTarget(get.prompt2("shuoye_rongguang"), 1, function (card, player, target) {
                return player != target;
            }).set("ai", function (target) {
                var player = _status.event.player;
                return get.attitude(player, target) < 0;
            });
            "step 1"
            if (result.bool) {
                result.targets[0].damage(event.num);
                player.restoreSkill("shuoye_qiyuan");
                player.addSkill("shuoye_chudan");
                player.removeSkill("shuoye_rongguang");
            }
        },
    },
//#noname-kit-end skill:shuoye_rongguang
//#noname-kit-begin skill:shuoye_fenzheng
    shuoye_fenzheng: {
        trigger: {
            player: "phaseBegin",
        },
        forced: true,
        content: function () {
            player.discard(player.getCards("j"));
            player.gainMaxHp();
            player.changeHujia(1);
            player.addSkill("shuoye_rongguang");
            player.removeSkill("shuoye_fenzheng");
        },
    },
//#noname-kit-end skill:shuoye_fenzheng
//#noname-kit-begin skill:shuoye_mengya
    shuoye_mengya: {
        trigger: {
            player: "damageAfter",
        },
        direct: true,
        content: function () {
            "step 0"
            player.chooseTarget(get.prompt2("shuoye_mengya"), 1, function (card, player, target) {
                return player != target;
            }).set("ai", function (target) {
                var player = _status.event.player;
                return get.attitude(player, target) < 0;
            });
            "step 1"
            if (result.bool) {
                var target = result.targets[0];
                var list = ["lebu", "bingliang", "shandian"];
                var list2 = list.randomGet(1);
                event.list = list;
                event.target = target;
                event.list2 = list2;
                game.log(player, "令", target, "进行【", get.translation(list2), "】的判定");
                target.judge(true);
            }
            else {
                event.finish();
            }
            "step 2"
            if (event.list2 == "lebu") {
                if (result.suit != "heart") {
                    event.target.skip("phaseUse");
                    event.target.loseMaxHp(target.maxHp - target.hp);
                    event.target.changeHujia(-target.hujia);
                    player.removeSkill("shuoye_mengya");
                    player.addSkill("shuoye_fenzheng");
                }
            }
            if (event.list2 == "bingliang") {
                if (result.suit != "heart") {
                    event.target.skip("phaseDraw");
                    event.target.loseMaxHp(target.maxHp - target.hp);
                    event.target.changeHujia(-target.hujia);
                    player.removeSkill("shuoye_mengya");
                    player.addSkill("shuoye_fenzheng");
                }
            }
            if (event.list2 == "shandian") {
                if (result.suit != "heart") {
                    event.target.damage(3, "thunder", "nosource");
                    event.target.loseMaxHp(target.maxHp - target.hp);
                    event.target.changeHujia(-target.hujia);
                    player.removeSkill("shuoye_mengya");
                    player.addSkill("shuoye_fenzheng");
                }
            }
        },
    },
//#noname-kit-end skill:shuoye_mengya
//#noname-kit-begin skill:shuoye_chudan
    shuoye_chudan: {
        subSkill: {
            damage: {
                trigger: {
                    source: "damageBegin",
                },
                forced: true,
                content: function () {
                    "step"
                    trigger.num++;
                    "step 1"
                    player.recover(num);
                },
            },
        },
        group: "shuoye_chudan_damage",
        trigger: {
            global: ["useCard", "respond"],
        },
        locked: true,
        forced: true,
        filter: function (event, player) {
            return Array.isArray(event.respondTo) && event.respondTo[0] != event.player && event.respondTo[0] == player && get.tag(event.respondTo[1], "damage");
        },
        content: function () {
            player.addSkill("shuoye_mengya");
            player.removeSkill("shuoye_chudan");
        },
    },
//#noname-kit-end skill:shuoye_chudan
//#noname-kit-begin skill:shuoye_qiyuan
    shuoye_qiyuan: {
        subSkill: {
            jueqing: {
                trigger: { source: 'damageBefore' },
                forced: true,
                check: function () { return false; },
                content: function () {
                    trigger.cancel();
                    trigger.player.loseHp(trigger.num);
                },
                ai: {
                    jueqing: true,
                },
            },
            add: {
                mod: {
                    targetInRange: function (card) {
                        if (!card.cards || !card.cards.length) return;
                        for (var i of card.cards) {
                            if (!i.hasGaintag('shuoye_qiyuan_add')) return;
                        }
                        return true;
                    },
                    cardUsable: function (card) {
                        if (!card.cards || !card.cards.length) return;
                        for (var i of card.cards) {
                            if (!i.hasGaintag('shuoye_qiyuan_add')) return;
                        }
                        return Infinity;
                    },
                },
            },
        },
        enable: "phaseUse",
        limited: true,
        filterTarget: function (card, player, target) {
            return player != target;
        },
        prompt2: "令一名其他角色失去所有体力，并增加等量护甲，然后你摸等量的牌",
        content: function () {

            var num = target.hp;
            player.addTempSkill("shuoye_qiyuan_jueqing");
            target.loseHp(num);
            target.changeHujia(num, null, true);
            player.draw(num).gaintag = ["shuoye_qiyuan_add"];
            player.addSkill("shuoye_qiyuan_add");
            player.awakenSkill("shuoye_qiyuan");

        },
    },
//#noname-kit-end skill:shuoye_qiyuan
//#noname-kit-begin skill:shuoye_wanxiang
    shuoye_wanxiang: {
        derivation: ["shuoye_chudan", "shuoye_mengya", "shuoye_fenzheng", "shuoye_rongguang"],
        group: ["shuoye_wanxiang_start", "shuoye_wanxiang_damage", "shuoye_wanxiang_draw"],
        subSkill: {
            damage: {
                trigger: {
                    source: "damageBegin",
                },
                forced: true,
                filter: function (event, player) {
                    return player.storage.shuoye_wanxiang_damage > 0;
                },
                content: function () {
                    trigger.num += player.storage.shuoye_wanxiang_damage;
                },
            },
            draw: {
                trigger: {
                    player: "damageAfter",
                },
                usable: 1,
                filter: function (event, player) {
                    return player.storage.shuoye_wanxiang_draw > 0;
                },
                content: function () {
                    var num = player.storage.shuoye_wanxiang_draw;
                    player.gainMaxHp(num);
                    player.draw(num);
                },
            },
            start: {
                trigger: {
                    global: "phaseBefore",
                    player: "enterGame",
                },
                forced: true,
                filter: function (event, player) {
                    return (event.name != 'phase' || game.phaseNumber == 0);
                },
                content: function () {
                    player.addSkill("shuoye_chudan");
                },
            },
        },
        init: function (player) {
            player.storage.shuoye_wanxiang_draw = 0;
            player.storage.shuoye_wanxiang_damage = 0;
        },

        trigger: {
            global: "dieBegin",
        },
        forced: true,
        filter: function (event, player) {
            return event.player != player && get.distance(player, event.player) > 0;
        },
        content: function () {
            var num = get.distance(player, event.player);
            if (num == 1) {
                player.disableJudge();
            }
            if (num == 2) {
                player.storage.shuoye_wanxiang_damage++;
            }
            if (num >= 3) {
                player.storage.shuoye_wanxiang_draw++;
            }
        },
    },
//#noname-kit-end skill:shuoye_wanxiang
    //冲田总司
//#noname-kit-begin skill:shuoye_wuming
    shuoye_wuming: {
        trigger: {
            player: "useCard",
        },
        forced: true,
        filter(event, player) {
            return !player.hasStorage("shuoye_wuming_used", get.type(event.card));
        },
        async content(event, trigger, player) {
            player.addSkill("shuoye_wuming_used");
            player.markAuto("shuoye_wuming_used", [get.type(trigger.card)]);
            //player.addTip(event.name, get.translation(event.name) + player.getStorage(event.name).reduce((str, type) => str + get.translation(type), ""));
            if (player.getStorage("shuoye_wuming_used").length >= 3) {
                player.removeSkill("shuoye_wuming_used");
                //player.removeTip(event.name);
                //delete player.storage[event.name];
                const list = [], num = player.getDamagedHp() + 1;;
                list.push("失去体力");
                list.push("减少体力上限");
                if (!player.hasSkill("shuoye_wuming_delete")) list.push("视为使用杀");
                const { result: { index } } = await player
                    .chooseControl(list)
                    .set("prompt", `选择失去1点体力或体力上限，或者视为使用${num}张无视防具的杀并令此选项失效至你令一名角色进入濒死`)
                    .set("ai", () => {
                        const player = get.player();
                        let controls = get.event("controls");
                        if (controls.includes("视为使用杀")) return "视为使用杀";
                        if (player.hp == player.maxHp) return "失去体力";
                        if (player.hp < player.maxHp - 1 || player.hp <= 2) return "减少体力上限";
                        return "失去体力";
                    });
                if (index == 0) {
                    await player.loseHp();
                } else if (index == 1) {
                    await player.loseMaxHp();
                } else {
                    player.addTempSkill("shuoye_wuming_delete", { source: "dying" });
                    for (var i = 0; i < num; i++) {
                        const card = new lib.element.VCard({ name: "sha", storage: { shuoye_wuming: true } });
                        if (player.hasUseTarget(card, true, false)) await player.chooseUseTarget(card, true, false);
                    }
                }
            }
        },
        ai: {
            unequip: true,
            skillTagFilter(player, tag, arg) {
                if (!arg?.card?.storage?.shuoye_wuming) return false;
            },
        },
        subSkill: {
            used: {
                charlotte: true,
                onremove: true,
                mark: true,
                intro: {
                    content: "已使用过的类型：$",
                },
            },
            delete: {
                charlotte: true,
            },
        },
    },
//#noname-kit-end skill:shuoye_wuming
//#noname-kit-begin skill:shuoye_suodi
    shuoye_suodi: {
        trigger: {
            global: ["chooseToUseBegin", "chooseToRespondBegin"],
        },
        usable: 2,
        popup: false,
        filter(event, player) {
            var evt = event.getParent();
            if (!evt?.card || evt?.player == event.player) return false;
            return get
                .inpileVCardList(info => {
                    const name = info[2],
                        type = get.type(name),
                        infox = get.info({ name: name });
                    return ["basic"].includes(type);
                })
                .some(card => event.filterCard({ name: card[2], nature: card[3] }, event.player, event));
        },
        async cost(event, trigger, player) {
            const list = get
                .inpileVCardList(info => {
                    const name = info[2], type = get.type(name), infox = get.info({ name: name });
                    return type == "basic";
                })
                .filter(card => trigger.filterCard({ name: card[2], nature: card[3] }, trigger.player, trigger));
            if (!list.length) return;
            var evt = trigger.getParent();
            var name = list[0][2], names = '';
            names += '【' + get.translation(name) + '】';
            var reason = (trigger.name == 'chooseToUse' ? '使用' : '打出');
            var str = get.translation(trigger.player) + (evt.card ? '因' + get.translation(evt.card) : '') + '需要' + reason + '一张' + names + '，是否代替其' + reason + reason + '使用之';
            event.result = await player
                .chooseBool(get.prompt('shuoye_suodi', trigger.player), str)
                .set('ai', () => {
                    const player = get.player();
                    const trigger = get.event().getTrigger().player;
                    return get.attitude(player, trigger.player) > 0;
                })
                .forResult();
            event.result.cost_data = { card: { name: name, isCard: true } };
        },
        async content(event, trigger, player) {
            player.logSkill('shuoye_suodi', trigger.player);
            var card = event.cost_data.card,
                types = player.getStorage("shuoye_wuming_used");
            const { result: { bool } } = await player
                .chooseToUse(function (card, player, event) {
                    if (get.event("types").includes(get.type(card))) return false;
                    return lib.filter.filterCard.apply(this, arguments);
                }, `使用一张未记录种类的牌，或取消弃置一张${get.translation(card)}`)
                .set("types", types)
            if (!bool) {
                event.result = await player
                    .chooseToDiscard("h", `弃置一张${get.translation(card)}`)
                    .set("cardx", card)
                    .set("filterCard", card => {
                        const player = get.player();
                        return get.event("cardx").name == get.name(card, player);
                    })
                    .forResult();
            } else event.result = { bool: true };
            if (event.result?.bool) {
                trigger.untrigger();
                trigger.set('responded', true);
                var result = {
                    bool: true,
                    card: card,
                    cards: [],
                };
                trigger.result = result;
                await player.draw();
                player.addSkill("shuoye_suodi_effect");
                player.addMark("shuoye_suodi_effect", 1, false);
            }
        },
        subSkill: {
            effect: {
                trigger: {
                    source: "damageBegin1",
                },
                forced: true,
                charlotte: true,
                onremove: true,
                async content(event, trigger, player) {
                    trigger.num += player.countMark(event.name);
                    player.removeSkill(event.name);
                },
                mark: true,
                intro: {
                    content: "你下一次造成的伤害+#",
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_suodi
//#noname-kit-begin skill:shuoye_juedao
    shuoye_juedao: {
        enable: "chooseToUse",
        hiddenCard(player, name) {
            if (_status.currentPhase == player) return false;
            if (player.hasSkill("shuoye_juedao_blocker", null, null, false)) return false;
            return get.type(name) == "basic" &&
                player.countCards("h", card => !player.hasStorage("shuoye_wuming_used", get.type(card)));
        },
        filter(event, player) {
            if (_status.currentPhase == player) return false;
            if (event.type == "wuxie" || event.shuoye_juedao) return false;
            if (!player.countCards("h", card => !player.hasStorage("shuoye_wuming_used", get.type(card)))) return false;
            for (const name of lib.inpile) {
                if (get.type(name) != "basic") continue;
                const card = { name: name, isCard: true };
                if (event.filterCard(card, player, event)) return true;
                if (name == "sha") {
                    for (const nature of lib.inpile_nature) {
                        card.nature = nature;
                        if (event.filterCard(card, player, event)) return true;
                    }
                }
            }
            return false;
        },
        chooseButton: {
            dialog(event, player) {
                const vcards = get.inpileVCardList(info => {
                    if (info[0] != "basic") return;
                    const card = { name: info[2], nature: info[3], isCard: true };
                    return event.filterCard(card, player, event);
                });
                const dialog = ui.create.dialog("绝刀", [vcards, "vcard"], "hidden");
                dialog.direct = true;
                return dialog;
            },
            check(button) {
                if (get.event().getParent().type != "phase") return 1;
                const player = get.player();
                const card = { name: button.link[2], nature: button.link[3] };
                if (
                    game.hasPlayer(current => {
                        return player.canUse(card, current) && get.effect(current, card, player, player) > 0;
                    })
                ) {
                    switch (button.link[2]) {
                        case "tao":
                            return 5;
                        case "jiu":
                            return 3.01;
                        case "sha":
                            if (button.link[3] == "fire") return 2.95;
                            else if (button.link[3] == "thunder") return 2.92;
                            else return 2.9;
                    }
                }
                return 0;
            },
            backup(links, player) {
                return {
                    filterCard(card) {
                        const player = get.player();
                        return get.itemtype(card) == "card" && player.hasUseTarget(card);
                    },
                    viewAs: {
                        name: links[0][2],
                        nature: links[0][3],
                        suit: "none",
                        number: null,
                        isCard: true,
                    },
                    ai1(card) {
                        return 1 / (1.1 + Math.max(-1, get.value(card)));
                    },
                    log: false,
                    async precontent(event, trigger, player) {
                        player.logSkill("shuoye_juedao");
                        var viewAs = new lib.element.VCard({
                            name: event.result.card.name,
                            nature: event.result.card.nature,
                            isCard: true,
                        });
                        const card = event.result.cards[0];
                        event.result.cards = [];
                        if (player.hasUseTarget(card)) {
                            await player.chooseUseTarget(card, true);
                            event.result2 = { bool: true }
                        }
                        if (event.result2?.bool) {
                            game.broadcastAll(viewAs => {
                                lib.skill.shuoye_juedao_backup2.viewAs = viewAs;
                            }, lib.skill.shuoye_juedao_backup.viewAs);
                            var evt = event.getParent();
                            evt.set("_backupevent", "shuoye_juedao_backup2");
                            evt.set("openskilldialog", `请选择${get.translation(viewAs.nature)}${get.translation(viewAs.name)}的目标`);
                            evt.backup("shuoye_juedao_backup2");
                            evt.set("norestore", true);
                            evt.set("custom", {
                                add: {},
                                replace: { window() { } },
                            });
                            evt.goto(0);
                        } else {
                            var evt = event.getParent();
                            evt.set("shuoye_juedao", true);
                            evt.goto(0);
                            player.addTempSkill("shuoye_juedao_blocker", {
                                player: ["useCard1", "useSkillBegin", "phaseUseEnd"],
                            });
                        }
                        await game.delayx();
                    },
                    ai: { order: 10 },
                };
            },
            prompt(links, player) {
                return `使用一张未记录类型的牌视为你使用一张${get.translation(links[0][3] || "")}${get.translation(links[0][2])}`;
            },
        },
        ai: {
            order() {
                const player = get.player(),
                    event = get.event();
                if (event.filterCard({ name: "jiu" }, player, event) && get.effect(player, { name: "jiu" }) > 0) {
                    return get.order({ name: "jiu" }) + 0.1;
                }
                return get.order({ name: "sha" }) + 0.1;
            },
            respondSha: true,
            fireAttack: true,
            respondShan: true,
            skillTagFilter(player, tag, arg) {
                if (player.hasSkill("shuoye_juedao_blocker", null, null, false)) return false;
            },
            result: {
                player(player) {
                    if (_status.event.dying) return get.attitude(player, _status.event.dying);
                    return 1;
                },
            },
        },
        subSkill: {
            backup: {},
            backup2: {
                filterCard: () => false,
                selectCard: -1,
                log: false,
            },
            blocker: {
                charlotte: true,
            },
        },
    },
//#noname-kit-end skill:shuoye_juedao
    //
//#noname-kit-begin skill:shuoye_yuqi
    shuoye_yuqi: {
        persevereSkill: true,
        forced: true,
        popup: false,
        locked: false,
        beginMarkCount: 10,
        maxMarkCount: 100,
        addMark(player, num) {
            num = Math.min(num, lib.skill.shuoye_yuqi.maxMarkCount - player.countMark("shuoye_yuqi"));
            player.addMark("shuoye_yuqi", num);
        },
        group: ["shuoye_yuqi_begin", "shuoye_yuqi_add", "shuoye_yuqi_remove"],
        marktext: "幸福",
        intro: {
            name: "幸福",
            "name2": "幸福",
            content: "当前幸福值为#",
        },
        subSkill: {
            begin: {
                persevereSkill: true,
                trigger: {
                    global: "phaseBefore",
                    player: "enterGame",
                },
                filter(event, player) {
                    return event.name != "phase" || game.phaseNumber == 0;
                },
                forced: true,
                locked: false,
                async content(event, trigger, player) {
                    const num = lib.skill.shuoye_yuqi.beginMarkCount;
                    lib.skill.shuoye_yuqi.addMark(player, num);
                },
            },
            add: {
                audio: "shuoye_yuqi",
                persevereSkill: true,
                trigger: {
                    player: ["useCardAfter", "gainAfter"],
                    source: "damageSource",
                    global: "loseAsyncAfter",
                },
                filter(event, player) {
                    if (player.countMark("shuoye_yuqi") >= lib.skill.shuoye_yuqi.maxMarkCount) return false;
                    if (event.name == "useCard") return true;
                    if (event.name === "damage") return event.num > 0;
                    return event.getg(player).length > 0;
                },
                getIndex(event, player, triggername) {
                    if (event.name === "damage") return event.num;
                    return 1;
                },
                forced: true,
                locked: false,
                async content(event, trigger, player) {
                    let toAdd = ((trigger.name === "useCard") * 2 + (event.triggername === "damageSource") * 10);
                    switch (event.triggername) {
                        case "useCardAfter": toAdd = 2; break;
                        case "damageSource": toAdd = 10; break;
                        default: toAdd = 7; break;
                    }
                    lib.skill.shuoye_yuqi.addMark(player, toAdd);
                },
            },
            remove: {
                audio: "shuoye_yuqi",
                persevereSkill: true,
                trigger: {
                    player: "damageEnd",
                },
                filter(event, player) {
                    return event.num > 0 && player.countMark("shuoye_yuqi");
                },
                getIndex(event, player, triggername) {
                    return event.num;
                },
                forced: true,
                locked: false,
                async content(event, trigger, player) {
                    player.removeMark("shuoye_yuqi", 5);
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_yuqi
//#noname-kit-begin skill:shuoye_weituan
    shuoye_weituan: {
        trigger: {
            player: ["shuoye_yuqi_beginAfter", "shuoye_yuqi_addAfter", "shuoye_yuqi_removeAfter"],
        },
        forced: true,
        popup: false,
        locked: false,
        async content(event, trigger, player) {
            const skills = [];
            const num = player.countMark("shuoye_yuqi");
            if (num >= 10) skills.add("shuoye_dinghan");
            if (num >= 40) skills.add("shuoye_shenxian");
            if (num >= 70) skills.add("shuoye_powei");
            if (num >= 100) skills.add("shuoye_dengshen");
            player.addAdditionalSkill("shuoye_weituan", skills, true);
        },
        onremove(player, skill) {
            player.removeAdditionalSkill(skill);
        },
    },
//#noname-kit-end skill:shuoye_weituan
//#noname-kit-begin skill:shuoye_dinghan
    shuoye_dinghan: {
        trigger: {
            target: "useCardToTarget",
            player: "addJudgeBefore",
        },
        forced: true,
        locked: false,
        filter(event, player) {
            if (event.name == "useCardToTarget" && get.type(event.card, null, false) != "trick") return false;
            return !player.getStorage("shuoye_dinghan").includes(event.card.name);
        },
        content() {
            player.markAuto("shuoye_dinghan", [trigger.card.name]);
            if (trigger.name == "addJudge") {
                trigger.cancel();
                var owner = get.owner(trigger.card);
                if (owner && owner.getCards("hej").includes(trigger.card)) owner.lose(trigger.card, ui.discardPile);
                else game.cardsDiscard(trigger.card);
                game.log(trigger.card, "进入了弃牌堆");
            } else {
                trigger.targets.remove(player);
                trigger.getParent().triggeredTargets2.remove(player);
                trigger.untrigger();
            }
        },
        onremove: true,
        intro: {
            content: "已记录牌名：$",
        },
        group: "shuoye_dinghan_add",
        subSkill: {
            add: {
                trigger: {
                    player: "phaseBegin",
                },
                async cost(event, trigger, player) {
                    var dialog = [get.prompt("shuoye_dinghan")];
                    var list1 = player.getStorage("shuoye_dinghan"),
                        list2 = lib.inpile.filter(function (i) {
                            return get.type2(i, false) == "trick" && !list1.includes(i);
                        })
                    if (list1.length) {
                        dialog.push('<div class="text center">已记录</div>');
                        dialog.push([list1, "vcard"]);
                    }
                    if (list2.length) {
                        dialog.push('<div class="text center">未记录</div>');
                        dialog.push([list2, "vcard"]);
                    }
                    const { result: { bool, links } } = await player.chooseButton(dialog)
                        .set("ai", function (button) {
                            var player = _status.event.player,
                                name = button.link[2];
                            if (player.getStorage("shuoye_dinghan").includes(name)) {
                                return -get.effect(player, { name: name }, player, player);
                            } else {
                                return get.effect(player, { name: name }, player, player) * (1 + player.countCards("hs", name));
                            }
                        });
                    if (bool) event.result = { bool, cost_data: { links } };
                },
                async content(event, trigger, player) {
                    var name = event.cost_data.links[0][2];
                    if (player.getStorage("shuoye_dinghan").includes(name)) {
                        player.unmarkAuto("shuoye_dinghan", [name]);
                        game.log(player, "从定汉记录中移除了", "#y" + get.translation(name));
                    } else {
                        player.markAuto("shuoye_dinghan", [name]);
                        game.log(player, "向定汉记录中添加了", "#y" + get.translation(name));
                    }
                    await game.delayx();
                    const card = new lib.element.VCard({ name: name });
                    if (player.hasUseTarget(card)) await player.chooseUseTarget(card);
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_dinghan
//#noname-kit-begin skill:shuoye_shenxian
    shuoye_shenxian: {
        trigger: {
            global: ["loseAfter", "loseAsyncAfter"],
        },
        forced: true,
        locked: false,
        filter(event, player) {
            if (event.type != "discard" || event.getlx === false) return false;
            if (event.name == "lose" && event.player == player) return false;
            var cards = event.cards.slice(0);
            var evt = event.getl(player);
            if (evt && evt.cards) cards.removeArray(evt.cards);
            for (var i = 0; i < cards.length; i++) {
                if (get.type(cards[i], null, event.hs && event.hs.includes(cards[i]) ? event.player : false) == "basic" && cards[i].original != "j") {
                    return true;
                }
            }
            return false;
        },
        async content(event, trigger, player) {
            if (trigger.delay == false) await game.delay();
            await player.draw();
        },
        ai: {
            threaten: 1.5,
        },
    },
//#noname-kit-end skill:shuoye_shenxian
//#noname-kit-begin skill:shuoye_powei
    shuoye_powei: {
        trigger: {
            global: "phaseBegin",
        },
        popup: false,
        filter(event, player) {
            return event.player != player && player.countCards("h") > 0;
        },
        async cost(event, trigger, player) {
            var list = [],
                target = trigger.player,
                choiceList = ["弃置一张牌并对其造成1点伤害", "弃置其一张手牌"];
            if (
                player.hasCard(function (card) {
                    return lib.filter.cardDiscardable(card, player, "shuoye_powei");
                }, "he")
            )
                list.push("选项一");
            else choiceList[0] = '<span style="opacity:0.5">' + choiceList[0] + "</span>";
            if (player.hp >= target.hp && target.countCards("h") > 0) list.push("选项二");
            else choiceList[1] = '<span style="opacity:0.5">' + choiceList[1] + "</span>";
            const { result: { control } } = await player
                .chooseControl(list, "cancel2")
                .set("prompt", get.prompt(event.skill, target))
                .set("choiceList", choiceList)
                .set("ai", function () {
                    const player = get.player();
                    var evt = get.event().getTrigger();
                    if (
                        player.hasCard(function (card) {
                            return lib.filter.cardDiscardable(card, player, "shuoye_powei") && get.value(card, player) < 7;
                        }, "h") &&
                        get.damageEffect(evt.player, player, player) > 0
                    )
                        return "选项一";
                    if (evt.player.countCards("h") > 0 && get.attitude(player, evt.player) <= 0 && !evt.player.hasSkillTag("noh")) return "选项二";
                    return "cancel2";
                });
            if (control != "cancel2") event.result = { bool: true, cost_data: { control } }
        },
        async content(event, trigger, player) {
            const target = trigger.player;
            const control = event.cost_data.control;
            player.logSkill(event.name, target);
            if (control == "选项一") {
                if (player.countCards("h")) await player.chooseToDiscard("he", true);
                await target.damage();
            } else if (trigger.player.countDiscardableCards(player, "he")) {
                await player.discardPlayerCard(target, "he", true)
            }
        },
        ai: {
            expose: 0.2,
        },
    },
//#noname-kit-end skill:shuoye_powei
//#noname-kit-begin skill:shuoye_dengshen
    shuoye_dengshen: {
        audio: "ext:朔夜/audio:1",
        enable: "phaseUse",
        limited: true,
        skillAnimation: true,
        animationColor: "thunder",
        filterCard: () => false,
        selectCard: [-1, -2],
        async contentBefore(event, trigger, player) {
            player.changeSkin({ characterName: "shuoye_fengchuanxiangzi" }, "shuoye_fengchuanxiangzi_shadow");
            player.awakenSkill("shuoye_dengshen");
        },
        async content(event, trigger, player) {
            const cards = ["cardPile", "discardPile"].map(pos => Array.from(ui[pos].childNodes)).flat();
            const filter = card => ["equip2", "equip4"].includes(get.subtype(card));
            const cardx = cards.filter(filter);
            if (cardx.length) {
                await game.cardsGotoSpecial(cardx);
                game.log(cardx, "被移出了游戏");
            }
            for (const target of game.filterPlayer()) {
                const sishis = target.getCards("hej", filter);
                if (sishis.length) {
                    target.$throw(sishis);
                    game.log(sishis, "被移出了游戏");
                    await target.lose(sishis, ui.special);
                }
            }
            await player.changeSkills(["shuoye_taoming"], ["shuoye_weituan"]);
            player.removeMark("shuoye_yuqi", 77);
        },
        ai: {
            order: 0.1,
            result: {
                player(player) {
                    return 1;
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_dengshen
//#noname-kit-begin skill:shuoye_taoming
    shuoye_taoming: {
        trigger: {
            player: ["shuoye_yuqi_beginAfter", "shuoye_yuqi_addAfter", "shuoye_yuqi_removeAfter", "shuoye_dengshenAfter"],
        },
        forced: true,
        popup: false,
        locked: false,
        async content(event, trigger, player) {
            const skills = [];
            const num = player.countMark("shuoye_yuqi");
            if (num >= 10) skills.add("shuoye_huishi");
            if (num >= 40) skills.add("lianpo");
            if (num >= 70) skills.add("shenzhu");
            if (num >= 100) skills.add("shuoye_shenfen");
            player.addAdditionalSkill("shuoye_taoming", skills);
        },
        onremove(player, skill) {
            player.removeAdditionalSkill(skill);
        },
    },
//#noname-kit-end skill:shuoye_taoming
//#noname-kit-begin skill:shuoye_renou
    shuoye_renou: {
        trigger: {
            global: "phaseBefore",
            player: "enterGame",
        },
        popup: false,
        locked: true,
        zhuSkill: true,
        filter(event, player) {
            if (!player.hasZhuSkill("shuoye_renou")) return false;
            return game.hasPlayer(current => current != player) && (event.name != "phase" || game.phaseNumber == 0);
        },
        async content(event, trigger, player) {
            const targets = game.filterPlayer(target => target.group == player.group);
            for (const target of targets) {
                const { result: { bool } } = await target.chooseToGive(player)
                    .set("ai", card => {
                        return 7 - get.value(card);
                    })
                if (bool) {
                    await target.draw(2);
                }
            }
        }
    },
//#noname-kit-end skill:shuoye_renou
//#noname-kit-begin skill:shuoye_huishi
    shuoye_huishi: {
        enable: "phaseUse",
        usable: 1,
        frequent: true,
        filter(event, player) {
            return player.maxHp < 10;
        },
        content() {
            "step 0";
            event.cards = [];
            event.suits = [];
            "step 1";
            player
                .judge(function (result) {
                    var evt = _status.event.getParent("shuoye_huishi");
                    if (evt && evt.suits && evt.suits.includes(get.suit(result))) return 0;
                    return 1;
                })
                .set("callback", lib.skill.shuoye_huishi.callback).judge2 = function (result) {
                    return result.bool ? true : false;
                };
            "step 2";
            var cards = cards.filterInD();
            if (cards.length)
                player
                    .chooseTarget("将" + get.translation(cards) + "交给一名角色", true)
                    .set("ai", function (target) {
                        var player = _status.event.player,
                            att = get.attitude(player, target);
                        if (att <= 0) return att;
                        if (target.countCards("h") + _status.event.num >= _status.event.max) att /= 3;
                        if (target.hasSkillTag("nogain")) att /= 10;
                        return att;
                    })
                    .set("num", cards.length)
                    .set(
                        "max",
                        game.filterPlayer().reduce((num, i) => {
                            return Math.max(num, i.countCards("h"));
                        }, 0)
                    );
            else event.finish();
            "step 3";
            if (result.bool) {
                var target = result.targets[0];
                event.target = target;
                player.line(target, "green");
                target.gain(cards, "gain2").giver = player;
            } else event.finish();
            "step 4";
            if (target.isMaxHandcard()) player.loseMaxHp();
        },
        callback() {
            "step 0";
            var evt = event.getParent(2);
            event.getParent().orderingCards.remove(event.judgeResult.card);
            evt.cards.push(event.judgeResult.card);
            if (event.getParent().result.bool && player.maxHp < 10) {
                evt.suits.push(event.getParent().result.suit);
                player.gainMaxHp();
                player.chooseBool("是否继续发动【慧识】？").set("frequentSkill", "shuoye_huishi");
            } else event._result = { bool: false };
            "step 1";
            if (result.bool) event.getParent(2).redo();
        },
        ai: {
            order: 9,
            result: {
                player: 1,
            },
        },
        group: "shuoye_huishi_use",
        subSkill: {
            use: {
                trigger: {
                    player: "shuoye_huishiAfter",
                },
                usable: 1,
                async cost(event, trigger, player) {
                    const list = get.inpileVCardList(info => {
                        var name = info[2];
                        if (!["basic", "trick"].includes(get.type(name))) return false;
                        return player.hasUseTarget({ name: name, isCard: true });
                    });
                    if (!list.length) return;
                    const { result: { bool, links } } = await player.chooseButton([get.prompt2(event.skill), [list, "vcard"]])
                        .set("ai", button => {
                            return get.player().getUseValue({ name: button.link[2] });
                        });
                    if (bool) event.result = { bool, cost_data: { links } };
                },
                async content(event, trigger, player) {
                    const name = event.cost_data.links[0][2];
                    if (player.countCards("hes")) {
                        await player.chooseToDiscard("hes", 2, true);
                        if (player.hasUseTarget({ name: name, isCard: true })) {
                            await player.chooseUseTarget({ name: name, isCard: true }, true);
                        }
                        await player.useSkill("shuoye_huishi");
                    }
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_huishi
//#noname-kit-begin skill:shuoye_shenfen
    shuoye_shenfen: {
        audio: "ext:朔夜/audio:1",
        enable: "phaseUse",
        usable: 1,
        filterCard: true,
        position: "hes",
        selectCard() {
            return game.countPlayer();
        },
        check(card) {
            return 7 - get.value(card);
        },
        async content(event, trigger, player) {
            const targets = game.filterPlayer(i => i != player);
            for (const target of targets) {
                await target.damage();
            }
            for (const target of targets) {
                if (target.countCards("he", card => get.type(card) == "equip")) {
                    await target.chooseToDiscard("he", card => get.type(card) == "equip", true);
                }
                if (target.countCards("h")) {
                    await target.chooseToDiscard("h");
                }
            }
            const { result } = await player.chooseTarget("令一名角色一个技能失效直至其下回合结束", true)
                .set("ai", target => {
                    return -get.attitude(get.player(), target);
                })
            if (result.bool) {
                const target = result.targets[0];
                const skills = target.getSkills(null, false, false)
                    .filter(skill => {
                        var info = get.info(skill);
                        return info && !info.charlotte && lib.translate[skill + "_info"];
                    });
                if (!skills.length) return;
                const list = skills.map(skill => [skill, '【' + get.translation(skill) + '】：' + lib.translate[skill + '_info']]);
                const { result: { bool, links } } = await player.chooseButton([`令${get.translation(target)}的一个技能失效`, [list, 'textbutton']], true)
                    .set('ai', button => {
                        return 1 + Math.random();
                    });
                if (bool) {
                    target.disableSkill('shuoye_shenfen_disable', links);
                    target.addTempSkill('shuoye_shenfen_disable', { player: "phaseEnd" });
                }
            }
        },
        ai: {
            order: 1,
            result: {
                player: 1,
            },
        },
        subSkill: {
            disable: {
                charlotte: true,
                onremove(player, skill) {
                    player.enableSkill(skill);
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_shenfen

//#noname-kit-begin skill:shuoye_yuanchu
    shuoye_yuanchu: {
        trigger: {
            target: 'useCardToTarget',
        },
        forced: true,
        locked: false,
        persevereSkill: true,
        filter(event, player) {
            if (event.player == player || typeof get.number(event.card) != 'number') return false;
            return !player.getStorage('shuoye_yuanchu').includes(get.number(event.card));
        },
        async content(event, trigger, player) {
            if (typeof get.number(trigger.card) == 'number') {
                player.markAuto(event.name, [get.number(trigger.card)]);
            }
            trigger.getParent().excluded.add(player);
        },
        mark: true,
        intro: {
            content: '已记录的点数：$',
        },
        group: ['shuoye_yuanchu_damage', 'shuoye_yuanchu_round'],
        subSkill: {
            damage: {
                trigger: {
                    source: 'damageBegin1',
                },
                popup: false,
                persevereSkill: true,
                filter(event, player) {
                    return player.getStorage('shuoye_yuanchu').length;
                },
                async cost(event, trigger, player) {
                    var list = player.getStorage('shuoye_yuanchu')
                        .sort((a, b) => a - b)
                        .map(info => [info, info]);
                    const { result: { bool, links } } = await player.chooseButton(['你可以减少一项【原初】记录令伤害+1', [list, 'tdnodes']])
                        .set('ai', button => {
                            return 1 + Math.random();
                        });
                    event.result = { bool, cost_data: { links } };
                },
                async content(event, trigger, player) {
                    player.logSkill(event.name);
                    player.unmarkAuto('shuoye_yuanchu', event.cost_data.links);
                    trigger.num++;
                },
            },
            round: {
                persevereSkill: true,
                trigger: {
                    global: 'roundStart',
                },
                forced: true,
                locked: false,
                async content(event, trigger, player) {
                    var hasRecord = player.getStorage('shuoye_yuanchu')
                        .sort((a, b) => a - b),
                        noRecord = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].removeArray(hasRecord);
                    const { result: { bool, links } } = await player.chooseButton(['你须减少或增加一项〖原初〗记录',
                        [hasRecord.map(info => [info, info]), 'tdnodes'],
                        [noRecord.map(info => [info, info]), 'tdnodes'],
                    ])
                        .set('ai', button => {
                            const player = get.player();
                            return 1 + Math.random();
                        })
                    if (bool) {
                        if (hasRecord.includes(links[0])) player.unmarkAuto('shuoye_yuanchu', links);
                        else player.markAuto('shuoye_yuanchu', links);
                    }
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_yuanchu
//#noname-kit-begin skill:shuoye_xinghuan
    shuoye_xinghuan: {
        trigger: {
            player: 'phaseUseBegin',
        },
        popup: false,
        locked: false,
        filter(event, player) {
            return player.getStorage('shuoye_yuanchu').length;
        },
        async cost(event, trigger, player) {
            event.result = await player.chooseCard('h')
                .set('prompt', get.prompt2('shuoye_xinghuan'))
                .set('selectCard', () => {
                    const player = get.player();
                    const Max = Math.min(player.maxHp - 1, player.getStorage('shuoye_yuanchu').length)
                    return [1, Max];
                })
                .set('ai', card => {
                    const player = get.player();
                    if (ui.selected.cards.length > player.maxHp) return 0;
                    if (player.hasUseTarget(card) && !player.hasValueTarget(card)) return 0;
                    if (["sha", "shan", "wuxie", "caochuan"].includes(card.name)) return 2 + Math.random();
                    return 1 + Math.random();
                })
                .forResult();
        },
        async content(event, trigger, player) {
            player.logSkill(event.name);
            player.addToExpansion(event.cards).gaintag.add('shuoye_xinghuan');
            player.loseMaxHp(event.cards.length);
        },
        mod: {
            cardUsable(card, player, num) {
                if (card.storage && card.storage.shuoye_shenhe) return Infinity;
            },
        },
        marktext: "环",
        intro: {
            content: "expansion",
            markcount: "expansion",
        },
        onremove(player, skill) {
            const cards = player.getExpansions(skill);
            if (cards.length) player.loseToDiscardpile(cards);
        },
    },
//#noname-kit-end skill:shuoye_xinghuan
//#noname-kit-begin skill:shuoye_shenhe
    shuoye_shenhe: {
        trigger: {
            player: 'logSkillBegin',
        },
        forced: true,
        locked: false,
        filter(event, player) {
            return event.skill == 'shuoye_xinghuan';
        },
        async content(event, trigger, player) {
            const list = lib.inpile.filter(info => {
                return ['basic', 'trick'].includes(get.type({ name: info }));
            }).map(info => ['', '', info, '']);
            const { result: { bool, links } } = await player.chooseButton(true, [`你需指定${player.getStorage('shuoye_yuanchu').length}种基本或普通锦囊牌名，然后直到你下次发动【星环】前，你【环】区的牌只能视为这些牌名之中的牌使用或打出`, [list, 'vcard']])
                .set('selectButton', player.getStorage('shuoye_yuanchu').length)
                .set('ai', button => {
                    return get.value({ name: button.link[2] });
                });
            if (bool) {
                player.setStorage('shuoye_shenhe', links.map(info => info[2]));
            }
        },
        ai: {
            combo: ['shuoye_yuanchu', 'shuoye_xinghuan'],
        },
        mark: true,
        intro: {
            content: 'cards',
        },
        group: 'shuoye_shenhe_use',
        subSkill: {
            use: {
                enable: ['chooseToUse', 'chooseToRespond'],
                filter(event, player) {
                    if (!player.getExpansions('shuoye_xinghuan').length) return false;
                    return get.inpileVCardList(info => {
                        const name = info[2], type = get.type(name), infox = get.info({ name: name });
                        return ['basic', 'trick'].includes(type) && player.getStorage('shuoye_shenhe').includes(name);
                    }).filter(card => event.filterCard({ name: card[2], nature: card[3], storage: { shuoye_shenhe: true } }, player, event)).length;
                },
                chooseButton: {
                    dialog(event, player) {
                        const list = get.inpileVCardList(info => {
                            const name = info[2], type = get.type(name), infox = get.info({ name: name });
                            return ['basic', 'trick'].includes(type) && player.getStorage('shuoye_shenhe').includes(name);
                        }).filter(card => event.filterCard({ name: card[2], nature: card[3], storage: { shuoye_shenhe: true } }, player, event));
                        const dialog = ui.create.dialog('神核', [list, 'vcard']);
                        dialog.add(player.getExpansions('shuoye_xinghuan'));
                        return dialog;
                    },
                    select: 2,
                    complexSelect: true,
                    filter(button, player) {
                        if (ui.selected.buttons.length) return player.getExpansions('shuoye_xinghuan').includes(button.link);
                        return !player.getExpansions('shuoye_xinghuan').includes(button.link);
                    },
                    check(button) {
                        const player = get.player();
                        if (!ui.selected.buttons.length) {
                            if (player.getExpansions('shuoye_xinghuan').includes(button.link)) return 2;
                            return player.getUseValue({ name: button.link[2], nature: button.link[3] })
                        }
                        return 1;
                    },
                    backup(links, player) {
                        return {
                            filterCard(card, player) {
                                return card == links[1];
                            },
                            selectCard: -1,
                            check(card) {
                                return 1;
                            },
                            position: 'x',
                            viewAs: {
                                name: links[0][2],
                                nature: links[0][3],
                                storage: {
                                    shuoye_shenhe: true,
                                }
                            },
                            async precontent(event, trigger, player) {
                                if (get.info('xunshi').isXunshi(event.result.card)) {
                                    player.tempBanSkill('shuoye_shenhe', false);
                                }
                            },
                        }
                    },
                    prompt(links) {
                        return '将一张【环】当做' + (get.translation(links[0][3]) || '') + get.translation(links[0][2]) + '使用';
                    },
                },
                hiddenCard(player, name) {
                    if (!player.getExpansions('shuoye_xinghuan').length) return false;
                    if (player.isTempBanned('shuoye_shenhe')) return false;
                    return player.getStorage('shuoye_shenhe').includes(name);
                },
                ai: {
                    save: true,
                    respondSha: true,
                    respondShan: true,
                    skillTagFilter(player, tag, arg) {
                        if (!player.getExpansions('shuoye_xinghuan').length) return false;
                        if (player.isTempBanned('shuoye_shenhe')) return false;
                    },
                    order: 2,
                    result: {
                        player(player) {
                            if (_status.event.dying) return get.attitude(player, _status.event.dying);
                            return 1;
                        },
                    },
                },
            },
            use_backup: {},
        },
    },
//#noname-kit-end skill:shuoye_shenhe
//#noname-kit-begin skill:shuoye_shanyao
    shuoye_shanyao: {
        derivation: 'shuoye_huangguan',
        trigger: {
            player: 'phaseBegin',
        },
        forced: true,
        juexingji: true,
        skillAnimation: true,
        animationColor: "gray",
        filter(event, player) {
            return player.maxHp >= 10;
        },
        async content(event, trigger, player) {
            player.awakenSkill(event.name);
            player.addSkills('shuoye_huangguan');
        },
        ai: {
            combo: ['shuoye_yuanchu', 'shuoye_xinghuan'],
        },
        group: 'shuoye_shanyao_draw',
        subSkill: {
            draw: {
                trigger: {
                    global: ['useCard', 'respond'],
                },
                forced: true,
                filter(event, player) {
                    return typeof get.number(event.card, false) == "number"
                        && player.getStorage('shuoye_yuanchu').includes(get.number(event.card));
                },
                async content(event, trigger, player) {
                    await player.draw();
                    player.gainMaxHp();
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_shanyao
//#noname-kit-begin skill:shuoye_huangguan
    shuoye_huangguan: {
        locked: true,
        group: ['shuoye_huangguan_limit', 'shuoye_huangguan_use', 'shuoye_huangguan_hujia'],
        subSkill: {
            limit: {
                trigger: {
                    player: "loseAfter",
                    global: ["equipAfter", "addJudgeAfter", "gainAfter", "loseAsyncAfter", "addToExpansionAfter"],
                },
                forced: true,
                popup: false,
                charlotte: true,
                filter(event, player) {
                    var evt = event.getl(player);
                    if (!evt || !evt.hs || evt.hs.length == 0 || player.countCards("h") >= player.getStorage('shuoye_yuanchu').length) return false;
                    var evt = event;
                    for (var i = 0; i < 4; i++) {
                        evt = evt.getParent("shuoye_huangguan_limit");
                        if (evt.name != "shuoye_huangguan_limit") return true;
                    }
                    return false;
                },
                async content(event, trigger, player) {
                    if (player.getStorage('shuoye_yuanchu').length) player.drawTo(player.getStorage('shuoye_yuanchu').length);
                },
            },
            use: {
                trigger: {
                    player: "loseAfter",
                    global: ["equipAfter", "addJudgeAfter", "gainAfter", "loseAsyncAfter", "addToExpansionAfter"],
                },
                direct: true,
                filter(event, player) {
                    const evt = event.getl(player);
                    return evt && evt.player == player && evt.cards2 && evt.cards2.length;
                },
                async content(event, trigger, player) {
                    const { result: { bool } } = await player.chooseToUse(function (card) {
                        return lib.filter.cardEnabled(card, _status.event.player, _status.event);
                    })
                        .set('oncard', (card, player) => {
                            player.tempBanSkill('shuoye_huangguan_use', false, false)
                        })
                    if (bool) {
                        player.gainMaxHp();
                    }
                },
            },
            hujia: {
                trigger: {
                    player: 'loseMaxHpBegin',
                },
                forced: true,
                async content(event, trigger, player) {
                    player.changeHujia();
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_huangguan

//#noname-kit-begin skill:shuoye_feichi
    shuoye_feichi: {
        trigger: {
            player: ['useCard', 'respond']
        },
        forced: true,
        filter(event, player) {
            return player.getRoundHistory('useSkill', evt => evt.skill == 'shuoye_feichi').length < player.getHp();
        },
        async content(event, trigger, player) {
            let num = player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_ranshao').length + 1,
                cards = [];
            do {
                num--;
                var card = get.cardPile(function (cardx) {
                    if (cards.includes(cardx)) return false;
                    return get.type(cardx) != get.type(trigger.card)
                });
                if (card) cards.push(card);
            } while (num > 0)
            if (cards.length) player.gain(cards, 'draw');
        },
    },
//#noname-kit-end skill:shuoye_feichi
//#noname-kit-begin skill:shuoye_zhuangtian
    shuoye_zhuangtian: {
        trigger: {
            player: "gainAfter",
            global: "loseAsyncAfter",
        },
        usable: 1,
        filter(event, player) {
            const length = player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_ranshao').length * 3 + 3;
            if (
                get.info('shuoye_zhuangtian').group
                    .reduce((p, c) => p + player.getExpansions(c).length, 0) >= length) return false;
            var evt = event.getParent("phaseDraw");
            if (evt && evt.name == "phaseDraw") return false;
            var cards = event.getg(player).filter(i => get.owner(i) == player && get.position(i) == "h");
            if (!cards.length) return false;
            return true;
        },
        async content(event, trigger, player) {
            let gainCards = trigger.getg(player)
                .filter(i => get.owner(i) == player && get.position(i) == "h"),
                num = gainCards.length,
                areas = get.info('shuoye_zhuangtian').group,
                types = ['equip', 'basic', 'trick'],
                translates = ['狙', '手', '步'],
                length = player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_ranshao').length * 3 + 3;
            for (var i = 0; i < 3; i++) {
                if (player.countCards('h', function (card) {
                    return get.type2(card) == types[i];
                })) {
                    const { result: { bool, cards } } = await player.chooseCard([1, num], function (card) {
                        return get.type2(card) == types[i];
                    })
                        .set('prompt', `你可以将${get.translation(types[i])}手牌置入${get.translation(translates[i])}区域`)
                        .set('ai', card => {
                            return 6.5 - get.value(card);
                        });
                    if (bool) {
                        player.addToExpansion(cards, player, "gain2").gaintag.add(areas[i]);
                        num -= cards.length;
                        if (num <= 0 || areas.reduce((p, c) => p + player.getExpansions(c).length, 0) >= length) break;
                    }
                }
            }
        },
        group: ['shuoye_zhuangtian_ju', 'shuoye_zhuangtian_shou', 'shuoye_zhuangtian_bu'],
        subSkill: {
            ju: {
                mark: true,
                marktext: '狙',
                intro: {
                    name: "狙",
                    content: "expansion",
                    markcount: "expansion",
                },
                onremove(player, skill) {
                    var cards = player.getExpansions(skill);
                    if (cards.length) player.loseToDiscardpile(cards);
                },
            },
            shou: {
                mark: true,
                marktext: '手',
                intro: {
                    name: "手",
                    content: "expansion",
                    markcount: "expansion",
                },
                onremove(player, skill) {
                    var cards = player.getExpansions(skill);
                    if (cards.length) player.loseToDiscardpile(cards);
                },
            },
            bu: {
                mark: true,
                marktext: '步',
                intro: {
                    name: "步",
                    content: "expansion",
                    markcount: "expansion",
                },
                onremove(player, skill) {
                    var cards = player.getExpansions(skill);
                    if (cards.length) player.loseToDiscardpile(cards);
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_zhuangtian
//#noname-kit-begin skill:shuoye_yuedan
    shuoye_yuedan: {
        mod: {
            targetInRange(card, player, target) {
                if (card.storage && card.storage.shuoye_zhuangtian_ju) return true;
            },
            cardUsable(card, player, num) {
                if (card.storage && card.storage.shuoye_zhuangtian_bu) return Infinity;
            },
        },
        trigger: {
            source: 'damageBegin',
            player: ['phaseUseBegin', 'damageBegin'],
        },
        forced: true,
        async content(event, trigger, player) { },
        ai: {
            combo: 'shuoye_zhuangtian',
        },
        backups: [
            {
                viewAs: {
                    name: 'sha',
                    nature: "fire",
                    storage: {
                        shuoye_yuedan_ju: true,
                    }
                },
                selectTarget: 1,
                async precontent(event, trigger, player) {
                    var targets = event.result.targets,
                        cards = event.result.cards,
                        num = event.result.cards.length;
                    for (var target of targets) {
                        target.addTempSkill("fengyin");
                    }
                    var viewAs = new lib.element.VCard({ name: event.result.card.name, isCard: true });
                    event.result.card = viewAs;
                    event.result.cards = [];
                    event.result._apply_args = {
                        shanReq: 2,
                        oncard: () => {
                            _status.event.baseDamage += num;
                            var evt = get.event();
                            for (var target of game.filterPlayer(null, null, true)) {
                                var id = target.playerid;
                                var map = evt.customArgs;
                                if (!map[id]) map[id] = {};
                                map[id].shanRequired = evt.shanReq;
                            }
                            _status.event.player.loseToDiscardpile(cards);
                        },
                    };
                },
            },
            {
                viewAs: {
                    name: 'sha',
                    storage: {
                        shuoye_yuedan_shou: true,
                    },
                },
                async precontent(event, trigger, player) {
                    player.when('useCard')
                        .filter(event => event.card.storage && event.card.storage.shuoye_yuedan_shou)
                        .then(() => {
                            player.addSkill('shuoye_yuedan_shou');
                            player.draw(num).gaintag = ["shuoye_yuedan_shou"];
                        })
                        .vars({ num: event.result.cards.length })
                    player.loseToDiscardpile(event.result.cards);
                    event.result.cards = [];
                },
            },
            {
                filterTarget(card, player, target) {
                    return player.canUse({ name: 'sha', nature: 'thunder' }, target);
                },
                async content(event, trigger, player) {
                    const target = event.targets[0];
                    let effectCount = event.cards.length;
                    do {
                        const { result: { bool } } = await player.chooseUseTarget({ name: 'sha', nature: 'thunder' }, false);
                        if (!bool) {
                            if (game.hasPlayer(function (current) {
                                return current.countDiscardableCards(player, 'hej');
                            })) {
                                do {
                                    effectCount--;
                                    const { result } = await player.chooseTarget(`弃置一名角色区域内的一张牌`, function (card, player, target) {
                                        return target.countDiscardableCards(player, 'hej');
                                    });
                                    if (result.bool) {
                                        await player.discardPlayerCard(result.targets[0], 'hej', true);
                                    }
                                } while (effectCount > 0)
                            } else break;
                        } else effectCount--;
                    } while (effectCount > 0);
                },
                ai: {
                    result: {
                        target(player, target) {
                            return get.effect(target, { name: 'sha', nature: 'thunder', player, player });
                        },
                    },
                },
            },
        ],
        group: ['shuoye_yuedan_use', 'shuoye_yuedan_lose', 'shuoye_yuedan_mark'],
        subSkill: {
            use: {
                enable: 'chooseToUse',
                filter(event, player) {
                    return get.info('shuoye_zhuangtian').group.some(info => {
                        return player.getExpansions(info).length && player.getExpansions(info).some(cards => {
                            const card = { name: 'sha', storage: {} };
                            card.storage[info] = true;
                            const sha = new lib.element.VCard(card);
                            return event.filterCard(get.autoViewAs(card, cards, "unsure"), player, event);
                        });
                    });
                },
                chooseButton: {
                    dialog(event, player) {
                        const dialog = ui.create.dialog('约弹');
                        if (player.getExpansions('shuoye_zhuangtian_ju').length) {
                            dialog.add('狙区域');
                            dialog.add(player.getExpansions('shuoye_zhuangtian_ju'));
                        }
                        if (player.getExpansions('shuoye_zhuangtian_shou').length) {
                            dialog.add('手区域');
                            dialog.add(player.getExpansions('shuoye_zhuangtian_shou'));
                        }
                        if (player.getExpansions('shuoye_zhuangtian_bu').length) {
                            dialog.add('步区域');
                            dialog.add(player.getExpansions('shuoye_zhuangtian_bu'));
                        }
                        return dialog;
                    },
                    select: [1, Infinity],
                    filter(button, player) {
                        if (ui.selected.buttons.length) {
                            const ownarea = ['shuoye_zhuangtian_ju', 'shuoye_zhuangtian_shou', 'shuoye_zhuangtian_bu'].find(area => {
                                return player.getExpansions(area).includes(ui.selected.buttons[0].link);
                            });
                            return player.getExpansions(ownarea).includes(button.link);
                        }
                        const own = ['shuoye_zhuangtian_ju', 'shuoye_zhuangtian_shou', 'shuoye_zhuangtian_bu'].find(area => {
                            return player.getExpansions(area).includes(button.link);
                        });
                        let vcard = {};
                        vcard.name = 'sha';
                        if (!vcard.storage) vcard.storage = {};
                        vcard.storage[own] = true;
                        return player.hasUseTarget(vcard, true, true);
                    },
                    check(button) {
                        const player = get.player();
                        let eff = 1;
                        if (!ui.selected.buttons.length) {
                            let ownarea = ['shuoye_zhuangtian_ju', 'shuoye_zhuangtian_shou', 'shuoye_zhuangtian_bu'].find(area => {
                                return player.getExpansions(area).includes(button.link);
                            });
                            switch (ownarea) {
                                case 'shuoye_zhuangtian_ju': {
                                    eff += player.getUseValue({ name: 'sha', nature: 'fire' }) + Math.random();
                                }
                                    break;
                                case 'shuoye_zhuangtian_shou': {
                                    eff += player.getUseValue({ name: 'sha' }) + get.effect(player, { name: "draw" }, player, player) * Math.sqrt(player.getExpansions('shuoye_zhuangtian_shou').length);
                                }
                                    break;
                                case 'shuoye_zhuangtian_bu': {
                                    eff += player.getUseValue({ name: 'sha', nature: 'thunder' }) + Math.random();
                                }
                                    break;
                            }
                            if (!player.getStorage('shuoye_yuedan_mark').includes(ownarea)) eff += 10;
                        }
                        return eff;
                    },
                    backup(links, player) {
                        let zhuangtianArea = ['shuoye_zhuangtian_ju', 'shuoye_zhuangtian_shou', 'shuoye_zhuangtian_bu'];
                        let index = zhuangtianArea.find(area => {
                            return player.getExpansions(area).includes(links[0]);
                        });
                        const next = get.copy(lib.skill.shuoye_yuedan.backups[zhuangtianArea.indexOf(index)]);
                        next.filterCard = function (card) {
                            return links.includes(card);
                        };
                        next.selectCard = -1;
                        next.position = 'x';
                        return next;
                    },
                    prompt(links, player) {
                        const zhuangtianArea = ['shuoye_zhuangtian_ju', 'shuoye_zhuangtian_shou', 'shuoye_zhuangtian_bu'];
                        const index = zhuangtianArea.find(area => {
                            return player.getExpansions(area).includes(links[0]);
                        });
                        return [
                            '你可以弃置X张【狙】内的牌，令一名角色本回合内非锁定技失效，然后视为对其使用一张无视距离限制，需要两张【闪】才可响应且基础伤害值+X的火【杀】。',
                            '你可以弃置Y张【手】内的牌，视为使用一张【杀】并摸Y张牌，以此法摸的牌不计入手牌上限。',
                            '你可以弃置Z张【步】内的牌，视为对目标使用一张无次数限制的雷【杀】重复该流程Z次。若中止流程，则改为用剩余的次数重复弃置场上任意一名角色区内的一张牌。'
                        ][zhuangtianArea.indexOf(index)];
                    },
                },
                hiddenCard(player, name) {
                    return name == 'sha';
                },
                ai: {
                    respondSha: true,
                    skillTagFilter: (player, tag, arg) => {
                        if (tag == "respondSha" && arg != "use") return false;
                    },
                    order() {
                        return get.order({ name: 'sha' }) + 0.1;
                    },
                    result: {
                        player(player) {
                            return 1;
                        },
                    },
                },
            },
            use_backup: {},
            lose: {
                trigger: {
                    player: "loseAfter",
                },
                locked: true,
                filter(event, player) {
                    if (!event._shuoye_yuedan_lose) return false;
                    if (!event.xs || !event.xs.length) return false;
                    for (var i in event.gaintag_map) {
                        if (['shuoye_zhuangtian_ju', 'shuoye_zhuangtian_shou', 'shuoye_zhuangtian_bu']
                            .some(info => event.gaintag_map[i].includes(info))) return true;
                        return false;
                    }
                },
                prompt2: `当你每个区域均弃置过一轮牌后，你可以增加一点体力上限，然后选择恢复一点体力或视为使用任意普通锦囊牌`,
                async content(event, trigger, player) {
                    await player.gainMaxHp();
                    const { result: { control } } = await player.chooseControl('回复1点体力', '视为使用普通锦囊牌')
                        .set('ai', () => {
                            if (player.getHp() <= 2 && get.recoverEffect(player, player, player) > 0) return '回复1点体力';
                            return '视为使用普通锦囊牌';
                        });
                    if (control == '回复1点体力') {
                        player.recover();
                    } else {
                        const list = get.inpileVCardList(info => {
                            const name = info[2], type = get.type(name), infox = get.info({ name: name });
                            return type == 'trick';
                        });
                        const { result: { bool, links } } = await player.chooseButton([[list, 'vcard']]).set('filterButton', button => {
                            return player.hasUseTarget({ name: button.link[2] })
                        }).set('ai', button => {
                            return player.getUseValue({ name: button.link[2] });
                        });
                        if (bool) {
                            player.chooseUseTarget({ name: links[0][2], isCard: true }, true);
                        }
                    }
                },
            },
            mark: {
                trigger: {
                    player: "loseAfter",
                },
                forced: true,
                popup: false,
                charlotte: true,
                firstDo: true,
                filter(event, player) {
                    if (!event.xs || !event.xs.length) return false;
                    for (var i in event.gaintag_map) {
                        if (['shuoye_zhuangtian_ju', 'shuoye_zhuangtian_shou', 'shuoye_zhuangtian_bu'].some(info => event.gaintag_map[i].includes(info))) return true;
                        return false;
                    }
                },
                async content(event, trigger, player) {
                    for (var i in trigger.gaintag_map) {
                        ['shuoye_zhuangtian_ju', 'shuoye_zhuangtian_shou', 'shuoye_zhuangtian_bu'].forEach(info => {
                            if (trigger.gaintag_map[i].includes(info)) player.markAuto('shuoye_yuedan_mark', info)
                        });
                    }
                    if (player.getStorage('shuoye_yuedan_mark').length >= 3) {
                        trigger._shuoye_yuedan_lose = true;
                        delete player.storage.shuoye_yuedan_mark;
                    }
                },
            },
            ju: {},
            bu: {},
            shou: {
                charlotte: true,
                mod: {
                    ignoredHandcard(card, player) {
                        if (card.hasGaintag('shuoye_yuedan_shou')) {
                            return true;
                        }
                    },
                    cardDiscardable(card, player, name) {
                        if (name == "phaseDiscard" && card.hasGaintag('shuoye_yuedan_shou')) return false;
                    },
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_yuedan
//#noname-kit-begin skill:shuoye_ranshao
    shuoye_ranshao: {
        trigger: {
            source: 'dieAfter',
        },
        forced: true,
        async content(event, trigger, player) { },
        ai: {
            combo: ['shuoye_zhuangtian', 'shuoye_feichi'],
        },
    },
//#noname-kit-end skill:shuoye_ranshao

//#noname-kit-begin skill:shuoye_tuji
    "shuoye_tuji": {
        trigger: {
            player: "useCard",
        },
        forced: true,
        filter(event, player) {
            return player.getHistory("useCard").length <= player.hujia;
        },
        async content(event, trigger, player) {
            trigger.directHit.addArray(game.filterPlayer());
            player.when('useCardAfter')
                .filter((event) => event.card == trigger.card)
                .then(() => {
                    if (player.hasHistory('sourceDamage', evt => evt.card == trigger.card)) {
                        event.finish();
                        return;
                    }
                    const list = [], cards = trigger.cards.filterInD();
                    event.cards = cards;
                    list.push('选项一');
                    if (trigger.cards.filterInD().length && get.type(trigger.card) != 'equip') list.push('选项二');
                    game.playAudio('..', 'extension/朔夜/audio/shuoye_tuji_chooseControl.mp3');
                    player.chooseControl(list, 'cancel2').set('choiceList', [
                        `摸两张牌`,
                        `${cards.length ? ('获得' + get.translation(cards)) : '无实体牌'}`,
                    ]).set('ai', () => {
                        const player = get.player();
                        if (cards.length > 1 && cards.some(function (card) {
                            return player.hasUseTarget(card);
                        }) && Math.random() <= (0.1 + (cards.length * 0.2))) return '选项二';
                        return '选项一';
                    }).set('prompt', `你可以选择一项`);
                })
                .then(() => {
                    if (result.control != 'cancel2') {
                        if (result.control == '选项一') {
                            player.draw(2);
                        } else {
                            if (event.cards.length) player.gain(event.cards, 'gain2');
                        }
                    }
                })
        },
        ai: {
            threaten: 1.5,
            "directHit_ai": true,
            skillTagFilter: function (player, tag, arg) {
                return player.countUsed() < player.hujia;
            },
        },
        mod: {
            maxHandcardFinal(player, num) {
                return player.hp + player.hujia;
            },
            targetInRange: function (card, player) {
                if (player.countUsed() < player.hujia) return true;
            },
            cardUsable: function (card, player) {
                if (player.countUsed() < player.hujia) return Infinity;
            },
            aiOrder: function (player, card, num) {
                if (player.countUsed() >= player.hujia) return;
                var numx = get.info(card).usable;
                if (typeof numx == "function") numx = num(card, player);
                if (typeof numx == "number") return num + 10;
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_tuji
//#noname-kit-begin skill:shuoye_chouyan
    shuoye_chouyan: {
        trigger: {
            player: ["damageBefore", "damageBegin"],
        },
        forced: true,
        onremove: true,
        filter(event, player, name) {
            if (name == 'damageBefore') return event.hasNature('fire');
            return event.card && !player.getStorage('shuoye_chouyan').includes(event.card.name);
        },
        async content(event, trigger, player) {
            if (event.triggername == 'damageBefore') {
                trigger.cancel();
                player.loseHp(trigger.num);
            } else {
                game.playAudio('..', 'extension/朔夜/audio/shuoye_chouyan_markAuto.mp3');
                player.markAuto(event.name, [trigger.card.name]);
            }
        },
        marktext: "仇",
        intro: {
            mark(dialog, storage, player) {
                dialog.addAuto([storage.map(info => ['', '', info]), 'vcard']);
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_chouyan
//#noname-kit-begin skill:shuoye_molong
    "shuoye_molong": {
        audio: "ext:朔夜/audio:1",
        enable: ["chooseToUse", "chooseToRespond"],
        filter: function (event, player) {
            if (!player.hujia) return false;
            for (var i of player.getStorage('shuoye_chouyan')) {
                var type = get.type2(i);
                if ((type == "basic" || type == "trick") && event.filterCard(get.autoViewAs({ name: i }, "unsure"), player, event)) return true;
            }
            return false;
        },
        chooseButton: {
            dialog: function (event, player) {
                var list = [];
                for (var name of player.getStorage('shuoye_chouyan')) {
                    if (name == "sha") {
                        if (event.filterCard(get.autoViewAs({ name }, "unsure"), player, event)) list.push(["基本", "", "sha"]);
                        for (var nature of lib.inpile_nature) {
                            if (event.filterCard(get.autoViewAs({ name, nature }, "unsure"), player, event)) list.push(["基本", "", "sha", nature]);
                        }
                    } else if (get.type2(name) == "trick" && event.filterCard(get.autoViewAs({ name }, "unsure"), player, event)) list.push(["锦囊", "", name]);
                    else if (get.type(name) == "basic" && event.filterCard(get.autoViewAs({ name }, "unsure"), player, event)) list.push(["基本", "", name]);
                }
                return ui.create.dialog("仇焰", [list, "vcard"]);
            },
            check: function (button) {
                if (_status.event.getParent().type != "phase") return 1;
                var player = _status.event.player;
                if (["wugu", "zhulu_card", "yiyi", "lulitongxin", "lianjunshengyan", "diaohulishan"].includes(button.link[2])) return 0;
                return player.getUseValue({
                    name: button.link[2],
                    nature: button.link[3],
                });
            },
            backup: function (links, player) {
                return {
                    filterCard: () => false,
                    selectCard: -1,
                    viewAs: { name: links[0][2], nature: links[0][3] },
                    precontent: function () {
                        player.changeHujia(-1);
                        player.unmarkAuto('shuoye_chouyan', [event.result.card.name])
                    },
                };
            },
            prompt: function (links, player) {
                return "移除1点护甲视为使用一张" + (get.translation(links[0][3]) || "") + get.translation(links[0][2]);
            },
        },
        hiddenCard: function (player, name) {
            if (!lib.inpile.includes(name)) return false;
            var type = get.type2(name);
            return (type == "basic" || type == "trick") && player.getStorage('shuoye_chouyan').includes(name) && player.hujia;
        },
        ai: {
            combo: "shuoye_chouyan",
            fireAttack: true,
            respondSha: true,
            respondShan: true,
            skillTagFilter: function (player) {
                if (!player.hujia) return false;
            },
            order: 1,
            result: {
                player: function (player) {
                    if (_status.event.dying) return get.attitude(player, _status.event.dying);
                    return 1;
                },
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_molong
//#noname-kit-begin skill:shuoye_nupao
    "shuoye_nupao": {
        enable: "phaseUse",
        usable: 1,
        async content(event, trigger, player) {
            const shas = player.getCards("h", "sha");
            let num;
            if (player.hp >= 4 && shas.length >= 3) {
                num = 3;
            } else if (player.hp >= 3 && shas.length >= 2) {
                num = 2;
            } else {
                num = 1;
            }
            const map = {};
            const list = [];
            for (let i = 1; i <= player.hp; i++) {
                const cn = get.cnNumber(i, true);
                map[cn] = i;
                list.push(cn);
            }
            player.storage.qimou = true;
            const { result } = await player
                .chooseControl(list, function () {
                    return get.cnNumber(_status.event.goon, true);
                })
                .set("prompt", "失去任意点体力")
                .set("goon", num);
            num = map[result.control] || 1;
            await player.loseHp(num);
        },
        group: "shuoye_nupao_losehp",
        ai: {
            order: 1,
            result: {
                player(player) {
                    if (player.getHp() + player.countCards("hs", card => player.canSaveCard(card, player)) <= 1) return 0;
                    return 1;
                },
            },
        },
        subSkill: {
            losehp: {
                trigger: {
                    player: "loseHpBegin",
                },
                direct: true,
                async content(event, trigger, player) {
                    const list = [];
                    list.push('选项一');
                    if (!player.hasSkill('shuoye_nupao_round')) list.push('选项二');
                    const { result: { control } } = await player.chooseControl(list, 'cancel2').set('choiceList', [
                        `记录“仇焰”${trigger.num}张未记录的牌名，然后增加两倍护甲`,
                        `每轮限一次，随机清除“仇焰”${trigger.num}张已记录的牌名，并对一名角色造成${trigger.num * 2}点火焰伤害`,
                    ]).set('ai', () => {
                        const player = get.player();
                        if (list.includes('选项二') && game.hasPlayer(function (current) {
                            return get.attitude(player, current) < 0 && get.damageEffect(current, player, player, 'fire') > 0
                        })) return '选项二';
                        return '选项一';
                    }).set('prompt', `你可以选择一项`);
                    if (control != 'cancel2') {
                        player.logSkill(event.name);
                        if (control == '选项一') {
                            const list = lib.inpile.filter(info => ['basic', 'trick'].includes(get.type({ name: info }))).map(info => ['', '', info]);
                            const { result: { bool, links } } = await player.chooseButton(['记录“仇焰”', [list, 'vcard']]).set('filterButton', button => {
                                return !player.getStorage('shuoye_chouyan').includes(button.link[2]);
                            }).set('selectButton', trigger.num).set('ai', button => {
                                return player.getUseValue({ name: button.link[2] });
                            });
                            if (bool) {
                                player.logSkill(event.name);
                                player.markAuto('shuoye_chouyan', links.map(info => info[2]));
                            }
                            player.changeHujia(trigger.num * 2);
                        }
                        else {
                            game.playAudio('..', 'extension/朔夜/audio/shuoye_nupao_chooseControl_damage.mp3');
                            player.addTempSkill('shuoye_nupao_round', 'roundStart');
                            const random = player.getStorage('shuoye_chouyan').randomGets(trigger.num);
                            player.unmarkAuto('shuoye_chouyan', random);
                            const { result: { bool, targets } } = await player.chooseTarget(true, `对一名角色造成${trigger.num * 2}点伤害`).set('ai', target => {
                                return get.damageEffect(target, player, player, 'fire');
                            });
                            if (bool) {
                                player.line(targets, 'fire');
                                targets[0].damage('fire', trigger.num * 2);
                            }
                        }
                    }
                },
                sub: true,
                "_priority": 0,
            },
            round: {
                charlotte: true,
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_nupao

//#noname-kit-begin skill:shuoye_diedai
    shuoye_diedai: {
        derivation: "shuoye_geming",
        trigger: {
            global: "damageEnd",
        },
        getLimit: 5,
        forced: true,
        dutySkill: true,
        getIndex(event, player) {
            let num = 0, limit = get.info('shuoye_diedai').getLimit;
            game.countPlayer2(function (current) {
                current.getAllHistory("damage", function (evt) {
                    num += evt.num;
                });
            });
            return Math.floor(num / limit) - player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_diedai').length;
        },
        filter(event, player) {
            let num = 0, limit = get.info('shuoye_diedai').getLimit;
            game.countPlayer2(function (current) {
                current.getAllHistory("damage", function (evt) {
                    num += evt.num;
                });
            });
            return num / limit >= player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_diedai').length;
        },
        async content(event, trigger, player) {
            player.draw();
            player.gainMaxHp();
            player.addSkill('shuoye_diedai_effect');
            player.addMark('shuoye_diedai_effect', 1, false);
            try {
                game.playshuoyeMP4('diedai', false, false, player);
            } catch (e) {
                console.log('game.playshuoyeMP4 is fail');
            }
        },
        group: ["shuoye_diedai_init", "shuoye_diedai_achieve", "shuoye_diedai_fail"],
        subSkill: {
            achieve: {
                trigger: {
                    player: "shuoye_diedaiAfter",
                },
                forced: true,
                skillAnimation: "legend",
                animationColor: "epic",
                filter(event, player) {
                    return player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_diedai').length >= 3;
                },
                async content(event, trigger, player) {
                    player.awakenSkill('shuoye_diedai');
                    game.log(player, '成功完成使命');
                    player.recover();
                    player.addSkills('shuoye_geming');
                },
            },
            fail: {
                trigger: {
                    player: "dying",
                },
                forced: true,
                async content(event, trigger, player) {
                    player.awakenSkill('shuoye_diedai');
                    game.log(player, '使命失败');
                },
            },
            init: {
                trigger: {
                    global: "phaseBefore",
                    player: "enterGame",
                },
                forced: true,
                locked: false,
                filter(event, player) {
                    return (event.name != "phase" || game.phaseNumber == 0) && game.countPlayer() <= 5;
                },
                async content(event, trigger, player) {
                    lib.skill.shuoye_diedai.getLimit = 3;
                },
            },
            effect: {
                onremove: true,
                mod: {
                    maxHandcard(player, num) {
                        return num + player.countMark("shuoye_diedai_effect");
                    },
                    cardUsable(card, player, num) {
                        if (card.name == "sha") return num + player.countMark("shuoye_diedai_effect");
                    },
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_diedai
//#noname-kit-begin skill:shuoye_geming
    shuoye_geming: {
        trigger: {
            player: "useCardToPlayer",
        },
        popup: false,
        filter(event, player) {
            if (player.getHistory('useSkill', evt => evt.skill == 'shuoye_geming').length >= player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_diedai').length) return false;
            return event.target != player;
        },
        async cost(event, trigger, player) {
            event.result = await player.chooseTarget(`你可以令一名角色交给你一张牌或令其本回合非锁定技失效并受到1点火焰伤害`, function (card, player, target) {
                return get.event().getTrigger().targets.includes(target);
            })
                .set('ai', target => {
                    return - get.attitude(player, target);
                })
                .forResult();
        },
        async content(event, trigger, player) {
            const target = event.targets[0];
            player.logSkill(event.name, target);
            const { result: { bool, cards } } = await target.chooseCard('he', `将一张牌交给${get.translation(player)}，否则你本回合非锁定技失效并受到1点火焰伤害`)
                .set('ai', card => {
                    if (get.damageEffect(target, player, player, 'fire') <= 0) return 0;
                    return 20 - get.value(card);
                });
            if (bool) {
                await target.give(cards, player);
                player.addGaintag(cards, 'shuoye_geming');
            } else {
                target.addTempSkill('fengyin');
                target.damage('fire');
            }
        },
        group: "shuoye_geming_use",
        subSkill: {
            use: {
                enable: ["chooseToUse", "chooseToRespond"],
                filter(event, player) {
                    for (var i of lib.inpile) {
                        var type = get.type2(i);
                        if (event.filterCard(get.autoViewAs({ name: i }, "unsure"), player, event) && player.countCards('h', function (card) {
                            return card.hasGaintag('shuoye_geming') && get.type2(card, false) == type;
                        })) return true;
                    }
                    return false;
                },
                chooseButton: {
                    dialog(event, player) {
                        var list = [];
                        for (var i = 0; i < lib.inpile.length; i++) {
                            var name = lib.inpile[i];
                            if (name == "sha") {
                                if (event.filterCard(get.autoViewAs({ name }, "unsure"), player, event)) list.push(["基本", "", "sha"]);
                                for (var nature of lib.inpile_nature) {
                                    if (event.filterCard(get.autoViewAs({ name, nature }, "unsure"), player, event)) list.push(["基本", "", "sha", nature]);
                                }
                            } else if (get.type2(name) == "trick" && event.filterCard(get.autoViewAs({ name }, "unsure"), player, event)) list.push(["锦囊", "", name]);
                            else if (get.type2(name) == "equip" && event.filterCard(get.autoViewAs({ name }, "unsure"), player, event)) list.push(["装备", "", name]);
                            else if (get.type(name) == "basic" && event.filterCard(get.autoViewAs({ name }, "unsure"), player, event)) list.push(["基本", "", name]);
                        }
                        return ui.create.dialog("革命", [list, "vcard"]);
                    },
                    filter(button, player) {
                        if (!player.countCards('h', function (card) {
                            return card.hasGaintag('shuoye_geming') && get.type2(card) == get.type2(button.link[2]);
                        })) return false;
                        return _status.event.getParent().filterCard({ name: button.link[2] }, player, _status.event.getParent());
                    },
                    check(button) {
                        if (_status.event.getParent().type != "phase") return 1;
                        var player = _status.event.player;
                        return player.getUseValue({
                            name: button.link[2],
                            nature: button.link[3],
                        });
                    },
                    backup(links, player) {
                        return {
                            filterCard(card) {
                                return get.type2(card) == get.type2({ name: links[0][2] }) && card.hasGaintag('shuoye_geming');
                            },
                            check(card) {
                                return 8 - get.value(card);
                            },
                            viewAs: {
                                name: links[0][2],
                                nature: links[0][3]
                            },
                        };
                    },
                    prompt(links, player) {
                        return "将一张牌当做" + (get.translation(links[0][3]) || "") + get.translation(links[0][2]) + "使用";
                    },
                },
                hiddenCard(player, name) {
                    if (!lib.inpile.includes(name)) return false;
                    var type = get.type2(name);
                    return (type == "basic" || type == "trick") && player.countCards("h", function (card) {
                        return card.hasGaintag('shuoye_geming') && get.type2(card, false) == type;
                    }) > 0;
                },
                ai: {
                    fireAttack: true,
                    respondSha: true,
                    respondShan: true,
                    skillTagFilter: function (player) {
                        if (!player.countCards("h", function (card) {
                            return card.hasGaintag('shuoye_geming') && get.type2(card, false) == 'basic';
                        })) return false;
                    },
                    order: 1,
                    result: {
                        player: function (player) {
                            if (_status.event.dying) return get.attitude(player, _status.event.dying);
                            return 1;
                        },
                    },
                },
                sub: true,
                "_priority": 0,
            },
            "use_backup": {
                sub: true,
                "_priority": 0,
            },
            equip: {
                trigger: {
                    player: "equipBegin",
                },
                forced: true,
                firstDo: true,
                charlotte: true,
                filter(event, player) {
                    return event.cards && event.cards[0].initName;
                },
                async content(event, trigger, player) {
                    trigger.cards[0].init(trigger.cards[0].initName);
                    trigger.cancel();
                    player.$equip(trigger.cards[0]);
                    game.addVideo('equip', player, get.cardInfo(trigger.cards[0]));
                    game.log(player, '装备了', trigger.card);
                    await game.asyncDelay();
                    var info = get.info(trigger.card);
                    if (info.onEquip && (!info.filterEquip || info.filterEquip(trigger.cards[0], player))) {
                        var next = game.createEvent('equip_' + trigger.cards[0].name);
                        next.setContent(info.onEquip);
                        next.player = player;
                        next.card = trigger.cards[0];
                    }
                    delete player.equiping;
                },
                sub: true,
                "_priority": 0,
            },
            destroy: {
                trigger: {
                    global: ["loseAfter", "cardsDiscardAfter", "equipAfter"],
                },
                firstDo: true,
                forcedDie: true,
                forced: true,
                silent: true,
                popup: false,
                filter(event, player) {
                    return event.getd().some(card => card.trueName);
                },
                async content(event, trigger, player) {
                    for (var card of trigger.cards) {
                        if (card.trueName) {
                            card.init([get.suit(card, false), get.number(card, false), card.trueName]);
                            delete card.initName;
                            delete card.trueName;
                        }
                    }
                },
                sub: true,
                "_priority": 1,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_geming
//#noname-kit-begin skill:shuoye_shouheng
    "shuoye_shouheng": {
        trigger: {
            global: ["dying", "dieAfter"],
        },
        forced: true,
        async content(event, trigger, player) {
            player.addMark('shuoye_shouheng', 1, false);
            game.log(player, '储存了一层', '#g“电能”');
        },
        marktext: "电能",
        intro: {
            name: "电能",
            content: "#",
        },
        group: ["shuoye_shouheng_phase", "shuoye_shouheng_damage"],
        subSkill: {
            phase: {
                trigger: {
                    global: "phaseEnd",
                },
                locked: true,
                filter(event, player) {
                    return player.countMark('shuoye_shouheng') >= 2;
                },
                "prompt2": () => `你可以减少两层“电能”，摸一张牌并执行一个额外回合`,
                async content(event, trigger, player) {
                    player.removeMark('shuoye_shouheng', 2, false);
                    game.log(player, '移除了两层', '#g“电能”');
                    await player.draw();
                    player.insertPhase();
                },
                sub: true,
                "_priority": 0,
            },
            damage: {
                trigger: {
                    player: "damageBegin3",
                },
                locked: true,
                filter(event, player) {
                    return player.countMark('shuoye_shouheng') >= 1;
                },
                "prompt2": () => `你可以减少一层“电能”，令此次受到的伤害-1`,
                async content(event, trigger, player) {
                    player.removeMark('shuoye_shouheng', 1, false);
                    game.log(player, '移除了一层', '#g“电能”');
                    trigger.num--;
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_shouheng
//#noname-kit-begin skill:shuoye_lichang
    "shuoye_lichang": {
        global: "shuoye_lichang_global",
        zhuSkill: true,
        group: "shuoye_lichang_remove",
        subSkill: {
            global: {
                trigger: {
                    player: "useCardToPlayer",
                },
                filter(event, player) {
                    if (player.group != 'qun') return false;
                    if (!game.hasPlayer(function (current) {
                        return current.hasZhuSkill('shuoye_lichang');
                    })) return false;
                    if (event.target == player || event.target.group == 'qun') return false;
                    return player.getHistory('useCard', evt => {
                        return evt.targets && evt.targets.some(target => target.group != 'qun');
                    }).indexOf(event.parent) == 0 && !player.hasHistory('useSkill', evt => evt.skill == 'shuoye_lichang_global');
                },
                "prompt2": () => `你可以摸一张牌`,
                async content(event, trigger, player) {
                    player.draw();
                },
                sub: true,
                "_priority": 0,
            },
            remove: {
                trigger: {
                    target: "useCardToTarget",
                },
                filter(event, player) {
                    if (player.isTempBanned('shuoye_lichang_remove')) return false;
                    if (!player.hasZhuSkill('shuoye_lichang')) return false;
                    return event.player != player && event.player.group == 'qun';
                },
                prompt2(event, player) {
                    return `你可以令${get.translation(event.card)}对你无效`;
                },
                async content(event, trigger, player) {
                    player.tempBanSkill(event.name, 'roundStart', false);
                    trigger.excluded.push(player);
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_lichang

//#noname-kit-begin skill:shuoye_quedi
    "shuoye_quedi": {
        trigger: {
            player: "useCardToPlayered",
        },
        direct: true,
        filter(event, player) {
            if (player.getHistory('useSkill', evt => evt.skill == 'shuoye_quedi').length >= (player.getAllHistory('custom', evt => evt.shuoye_quedi).length + 1)) return false;
            return (
                (get.tag(event.card, 'damage')) &&
                event.targets.length == 1 &&
                (event.target.countGainableCards(player, "hej") > 0 ||
                    player.hasCard(function (i) {
                        return _status.connectMode || (lib.filter.cardDiscardable(i, player, "shuoye_quedi"));
                    }, "h"))
            );
        },
        async content(event, trigger, player) {
            const target = trigger.target;
            var list = [];
            if (target.countGainableCards(player, "h") > 0) list.push("选项一");
            if (
                player.hasCard(function (i) {
                    return get.type(i, player) == "basic" && lib.filter.cardDiscardable(i, player, "shuoye_quedi");
                }, "h")
            )
                list.push("选项二");
            list.push("背水！");
            list.push("cancel2");
            const { result: { control } } = await player
                .chooseControl(list)
                .set("choiceList", ["获得" + get.translation(target) + "的区域内的一张牌", "弃置一张牌并令" + get.translation(trigger.card) + "伤害+1", "背水！减1点体力上限并执行所有选项，选择一张花色，令其本回合不可使用或打出之"])
                .set("prompt", get.prompt(event.name, target))
                .set("ai", function () {
                    var evt = _status.event.getTrigger(),
                        player = evt.player,
                        target = evt.target,
                        card = evt.card;
                    if (get.attitude(player, target) > 0) return "cancel2";
                    var bool1 = target.countGainableCards(player, "hej") > 0;
                    var bool2 =
                        player.hasCard(function (i) {
                            return lib.filter.cardDiscardable(i, player, "shuoye_quedi") && get.value(card, player) < 5;
                        }, "h") &&
                        !target.hasSkillTag("filterDamage", null, {
                            player: player,
                            card: card,
                        });
                    if (bool1 && bool2 && (target.hp <= 2 || (player.isDamaged() && player.maxHp > 3))) return "背水！";
                    if (bool1) return "选项一";
                    if (bool2) return "选项二";
                    return "cancel2";
                });
            if (control != 'cancel2') {
                player.logSkill(event.name, target);
                if (control == "背水！") {
                    await player.loseMaxHp();
                    const { result } = await player.chooseControl(lib.suit.slice(0))
                        .set("prompt", `选择一种花色，本回合${get.translation(target)}不能使用或打出此花色的牌`)
                        .set("ai", function () {
                            const player = get.player();
                            return lib.suit.randomGet();
                        });
                    target.addTempSkill('shuoye_quedi_effect');
                    target.markAuto('shuoye_quedi_effect', [result.control]);
                }
                if ((control == "选项一" || control == "背水！") && target.countGainableCards(player, "hej") > 0) {
                    await player.gainPlayerCard(target, true, "hej");
                }
                if (
                    (control == "选项二" || control == "背水！") &&
                    player.hasCard(function (i) {
                        return lib.filter.cardDiscardable(i, player, "shuoye_quedi");
                    }, "h")
                ) {
                    const { result: { bool } } = await player.chooseToDiscard("h", "弃置一张牌", true);
                    if (bool) {
                        trigger.getParent().baseDamage++;
                    }
                }
            }
        },
        ai: {
            "directHit_ai": true,
            skillTagFilter: function (player, tag, arg) {
                if (tag !== "directHit_ai" || !arg || !arg.card || !arg.target || (arg.card.name != "sha" && arg.card.name != "juedou")) return false;
                if (player.storage.counttrigger && player.storage.counttrigger.shuoye_quedi && player.storage.counttrigger.shuoye_quedi > 0) return false;
                if (
                    arg.target.countCards("h") == 1 &&
                    (arg.card.name != "sha" ||
                        !arg.target.hasSkillTag("freeShan", false, {
                            player: player,
                            card: arg.card,
                        }) ||
                        player.hasSkillTag("unequip", false, {
                            name: arg.card ? arg.card.name : null,
                            target: arg.target,
                            card: arg.card,
                        }) ||
                        player.hasSkillTag("unequip_ai", false, {
                            name: arg.card ? arg.card.name : null,
                            target: arg.target,
                            card: arg.card,
                        }))
                )
                    return true;
                return false;
            },
        },
        subSkill: {
            effect: {
                mark: true,
                charlotte: true,
                onremove: true,
                intro: {
                    content: storage => `本回合不能使用${get.translation(storage)}花色的牌`,
                },
                mod: {
                    "cardEnabled2": function (card, player) {
                        if (player.getStorage("shuoye_quedi_effect").includes(get.suit(card))) return false;
                    },
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_quedi
//#noname-kit-begin skill:shuoye_zhuifeng
    "shuoye_zhuifeng": {
        enable: ["chooseToUse", "chooseToRespond"],
        filter: function (event, player) {
            if (player.getHistory('useSkill', evt => evt.skill == 'shuoye_zhuifeng_backup').length >= (2 + player.countMark('shuoye_zhuifeng'))) return false;
            return get.inpileVCardList(info => {
                const name = info[2], type = get.type(name), infox = get.info({ name: name });
                return get.tag({ name: name }, 'damage') || ['sha', 'jiu'].includes(name);
            }).filter(card => event.filterCard({ name: card[2] }, player, event)).length;
        },
        chooseButton: {
            dialog: function (event, player) {
                const list = get.inpileVCardList(info => {
                    const name = info[2], type = get.type(name), infox = get.info({ name: name });
                    return (get.type({ name: name }) == 'trick' && get.tag({ name: name }, 'damage')) || ['sha', 'jiu'].includes(name);
                }).filter(card => event.filterCard({ name: card[2], nature: card[3] }, player, event));
                const dialog = ui.create.dialog('椎锋', [list, 'vcard']);
                dialog.direct = true;
                return dialog;
            },
            check: function (button) {
                if (_status.event.getParent().type != "phase") return 1;
                var player = _status.event.player;
                if (["wugu", "zhulu_card", "yiyi", "lulitongxin", "lianjunshengyan", "diaohulishan"].includes(button.link[2])) return 0;
                return player.getUseValue({
                    name: button.link[2],
                    nature: button.link[3],
                });
            },
            backup: function (links, player) {
                const next = {
                    filterCard: () => false,
                    selectCard: -1,
                    ignoreMod: true,
                    precontent: function () {
                        if (event.result.card.name == 'jiu') {
                            player.when('jiuBegin')
                                .filter((event, player) => {
                                    return event.skill == 'shuoye_zhuifeng_backup'
                                })
                                .then(() => {
                                    player.addTempSkill('shuoye_zhuifeng_jiubuff');
                                })
                        }
                    },
                };
                const viewAs = {
                    name: links[0][2],
                    nature: links[0][3],
                    suit: "none",
                    number: null,
                    isCard: true,
                };
                next.viewAs = viewAs;
                if (get.info("xunshi").isXunshi(viewAs)) {
                    next.filterTarget = function (card, player, target) {
                        const info = get.info(card);
                        if (info.changeTarget) {
                            let targets = [target];
                            info.changeTarget(player, targets);
                            if (targets.length > 1) return false;
                        }
                        return lib.filter.filterTarget(card, player, target);
                    };
                    next.selectTarget = 1;
                }
                return next;
            },
            prompt: function (links, player) {
                return "使用使用或打出" + (get.translation(links[0][3]) || "") + get.translation(links[0][2]);
            },
        },
        hiddenCard: function (player, name) {
            if (!lib.inpile.includes(name)) return false;
            var type = get.type2(name);
            return ['sha', 'jiu'].includes(name) || (type == "trick" && get.tag({ name: name }, 'damage'));
        },
        ai: {
            fireAttack: true,
            respondSha: true,
            order: 1,
            result: {
                player: function (player) {
                    if (_status.event.dying) return get.attitude(player, _status.event.dying);
                    return 1;
                },
            },
        },
        group: ["shuoye_zhuifeng_use", "shuoye_zhuifeng_add", "shuoye_zhuifeng_effect"],
        subSkill: {
            jiubuff: {
                trigger: {
                    player: "useCard",
                },
                forced: true,
                charlotte: true,
                popup: false,
                firstDo: true,
                filter(event, player) {
                    return event.card.name == 'sha';
                },
                async content(event, trigger, player) {
                    trigger.card._shuoye_zhuifeng = true;
                    player.removeSkill(event.name);
                },
                sub: true,
                "_priority": 0,
            },
            use: {
                enable: "phaseUse",
                direct: true,
                async content(event, trigger, player) {
                    const list2 = [];
                    if (player.countCards('he', function (card) {
                        return get.type(card) == 'equip' && lib.filter.cardDiscardable(card, player, event.name);
                    })) list2.push('弃置装备牌');
                    list2.push('失去体力');
                    const { result: { control } } = await player.chooseControl(list2, 'cancel2').set('prompt', `你可以弃置装备牌或失去体力增加“椎锋”的使用次数`);
                    if (control == 'cancel2') {
                        event.finish();
                        return;
                    }
                    player.logSkill(event.name);
                    if (control == '弃置装备牌') {
                        const { result: { bool, cards } } = await player.chooseToDiscard('he', [1, Infinity], function (card) {
                            return get.type(card) == 'equip';
                        }, true);
                        if (bool) {
                            player.addMark('shuoye_zhuifeng', cards.length, false);
                        }
                    } else {
                        var num = player.hp - 1;
                        if (player.countCards("hs", { name: ["tao", "jiu"] })) {
                            num = player.hp;
                        }
                        var map = {};
                        var list = [];
                        for (var i = 1; i <= player.hp; i++) {
                            var cn = get.cnNumber(i, true);
                            map[cn] = i;
                            list.push(cn);
                        }
                        event.map = map;
                        const { result } = await player
                            .chooseControl(list, function () {
                                return get.cnNumber(_status.event.goon, true);
                            })
                            .set("prompt", "失去任意点体力")
                            .set("goon", num)
                        var num = event.map[result.control] || 1;
                        player.loseHp(num);
                        player.addMark('shuoye_zhuifeng', num, false);
                    }
                },
                sub: true,
                "_priority": 0,
            },
            add: {
                trigger: {
                    player: "phaseJieshuBegin",
                },
                forced: true,
                async content(event, trigger, player) {
                    player.addMark('shuoye_zhuifeng', 2, false);
                },
                sub: true,
                "_priority": 0,
            },
            effect: {
                trigger: {
                    source: "damageSource",
                },
                filter(event, player) {
                    return event.card && ((event.getParent(2).card && event.getParent(2).card._shuoye_zhuifeng) || event.getParent(2).skill == 'shuoye_zhuifeng_backup') && event.player.countCards('hej');
                },
                logTarget: "player",
                prompt2(event, player) {
                    return `你可以观看并获得${get.translation(event.player)}区域内的牌`;
                },
                async content(event, trigger, player) {
                    const { result: { bool, cards } } = await player.choosePlayerCard(trigger.player, 'hej', true, trigger.num, 'visible');
                    if (bool) {
                        player.gain(cards, trigger.player, "give", "bySelf");
                    }
                },
                sub: true,
                "_priority": 0,
            },
        },
    },
//#noname-kit-end skill:shuoye_zhuifeng
//#noname-kit-begin skill:shuoye_choujue
    "shuoye_choujue": {
        trigger: {
            source: ["dying", "dieBegin"],
        },
        forced: true,
        locked: false,
        async content(event, trigger, player) {
            const { result: { index } } = await player.chooseControl('增加体力上限', '回复体力');
            if (index == 0) {
                await player.gainMaxHp();
            } else {
                await player.recover();
            }
            player.draw();
            player.getHistory('custom').push({ shuoye_quedi: true });
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_choujue

//#noname-kit-begin skill:dybl_shishan
    "dybl_shishan": {
        subSkill: {
            damage: {
                audio: "dybl_shishan",
                trigger: {
                    player: "damageBefore",
                },
                filter: function (event, player) {
                    return event.num > 0 && player.storage.dybl_shishan > 0;
                },
                content: function () {
                    trigger.cancel();
                    player.storage.dybl_shishan--;
                },
                check: function (event, player) {
                    return true;
                },
                sub: true,
                "_priority": 0,
            },
            "mark2": {
                marktext: "时删-",
                intro: {
                    content: "你计算其他角色的距离-$",
                },
                sub: true,
                "_priority": 0,
            },
            "mark3": {
                marktext: "时删+",
                intro: {
                    content: "其他角色计算你的距离+$",
                },
                sub: true,
                "_priority": 0,
            },
            round: {
                trigger: {
                    global: "roundStart",
                },
                forced: true,
                content: function () {
                    player.storage.dybl_shishan = 3;
                },
                sub: true,
                "_priority": 0,
            },
        },
        group: ["dybl_shishan_round", "dybl_shishan_damage"],
        mod: {
            globalFrom: function (from, to, distance) {
                return distance - from.countMark('dybl_shishan_mark2');
            },
            globalTo: function (from, to, distance) {
                return distance + to.countMark('dybl_shishan_mark3');
            },
        },
        init: function (player) {
            player.storage.dybl_shishan = 3;
        },
        trigger: {
            global: "phaseZhunbeiBefore",
        },
        audio: "ext:朔夜/audio:2",
        filter: function (event, player) {
            return player.storage.dybl_shishan > 0;
        },
        direct: true,
        content: function () {
            "step 0"
            if (player.storage.dybl_shishan <= 0) {
                event.finish();
            }
            player.chooseControlList([
                '跳过其一个回合内的阶段',
                '你计算其他角色的距离-1（可以叠加）',
                '其他角色计算你的距离+1（可以叠加）',
            ], false).set('ai', function (event, player) {
                var target = trigger.player;
                var player = _status.event.player;
                var att = get.attitude(player, target);
                if (att == 0) {
                    if (player.countMark('dybl_shishan_mark3') == 0) return 2;
                    return false;
                }
                if (att > 2) {
                    if (target.countCards('j') > 0) {
                        return 0;
                    }
                    else {
                        if (target.countCards('h') + 2 > target.getHandcardLimit()) {
                            return 0;
                        }
                        else {
                            if ((player.countMark('dybl_shishan_mark3') < 2)) return 2;
                            else {
                                if (player.storage.dybl_shishan > 1 && player.countMark('dybl_shishan_mark2') < 4) return 1;
                                return false;
                            }
                        }
                    }
                }
                if (att < 0) {
                    if (target.hasJudge() || target.countCards('h') < 3 || target.countCards('h') > target.getHandcardLimit() || target.countCards('h') > 5) return 0;
                    else {
                        if ((player.countMark('dybl_shishan_mark3') < 2)) return 2;
                        else {
                            if (player.storage.dybl_shishan > 1 && player.countMark('dybl_shishan_mark2') < 4) return 1;
                            return false;
                        }
                    }
                }
            });
            "step 1"
            if (result.bool || result.index != 3) {
                player.logSkill('dybl_shishan');
                player.storage.dybl_shishan--;
                if (result.index == 1) {
                    player.addMark('dybl_shishan_mark2');
                    event.finish();
                }
                if (result.index == 2) {
                    player.addMark('dybl_shishan_mark3');
                    event.finish();
                }
                if (result.index == 0) {
                    player.chooseControlList([
                        '跳过其回合开始阶段',
                        '跳过其判定阶段',
                        '跳过其摸牌阶段',
                        '跳过其出牌阶段',
                        '跳过其弃牌阶段',
                        '跳过其回合结束阶段',
                    ], true).set('ai', function (event, player) {
                        var target = trigger.player;
                        var player = _status.event.player;
                        var att = get.attitude(player, target);
                        if (att > 0) {
                            if (player.countCards('j') > 0) return 1;
                            return 5;
                        }
                        if (att < 0) {
                            if (target.hasJudge('lebu') || target.countCards('h') < 3) return 2;
                            return 4;
                        }
                    });
                }
            }
            else {
                event.finish();
            }
            "step 2"
            if (result.index == 0) {
                trigger.player.skip('phaseZhunbei');
            }
            if (result.index == 1) {
                trigger.player.skip('phaseJudge');
            }
            if (result.index == 2) {
                trigger.player.skip('phaseDraw');
            }
            if (result.index == 3) {
                trigger.player.skip('phaseUse');
            }
            if (result.index == 4) {
                trigger.player.skip('phaseDiscard');
            }
            if (result.index == 5) {
                trigger.player.skip('phaseJieshu');
            }
        },
        ai: {
            expose: 0.3,
        },
        "_priority": 0,
    },
//#noname-kit-end skill:dybl_shishan
//#noname-kit-begin skill:dybl_muming
    "dybl_muming": {
        group: "dybl_muming_clear",
        subSkill: {
            "1": {
                audio: "ext:朔夜/audio:true",
                unique: true,
                sub: true,
                "_priority": 0,
            },
            "2": {
                audio: "ext:朔夜/audio:true",
                unique: true,
                sub: true,
                "_priority": 0,
            },
            clear: {
                trigger: {
                    global: "phaseEnd",
                },
                forced: true,
                popup: false,
                content: function () {
                    game.hasPlayer(function (current) {
                        if (current.hasMark('dybl_muming_mark')) {
                            current.removeMark('dybl_muming_mark');
                        }
                    })
                },
                sub: true,
                "_priority": 0,
            },
            mark: {
                marktext: "墓铭",
                intro: {
                    content: "已被墓铭",
                },
                sub: true,
                "_priority": 0,
            },
            effect: {
                onremove: true,
                trigger: {
                    global: "useCard1",
                },
                forced: true,
                usable: 1,
                filter: function (event, player) {
                    return event.player.hasMark('dybl_muming_mark') && event.player.isPhaseUsing();
                },
                content: function () {
                    trigger.player.removeMark('dybl_muming_mark');
                    var type = get.type2(trigger.card);
                    if (player.getStorage('dybl_muming_effect').contains(type)) {
                        player.draw(2);
                        player.logSkill("dybl_muming_1");
                    }
                    else {
                        player.logSkill("dybl_muming_2");
                    }
                    player.removeSkill('dybl_muming_effect');
                },
                sub: true,
                "_priority": 0,
            },
        },
        global: "dybl_muming_mark",
        trigger: {
            global: "phaseBegin",
        },
        audio: "ext:朔夜/audio:1",
        frequent: true,
        filter: function (event, player) {
            return event.player != player;
        },
        content: function () {
            "step 0"

            var target = trigger.player;
            var cards = target.getCards('h')
            if (target.countCards('h') > 0) {
                var content = [get.translation(target) + '的手牌', cards];
                game.log(player, '观看了', target, '的手牌');
                player.chooseControl('ok').set('dialog', content);
            }
            "step 1"
            var list = ['basic', 'trick', 'equip', 'cancel2'];
            if (list.length > 1) {
                player.chooseControl(list).set('ai', function () {
                    if (trigger.player.countCards('h', { type: "equip" })) return list[2];
                    else {
                        if (trigger.player.getCards('h', function (card) {
                            return get.type(card) == 'trick' && card.name != 'wuxie';
                        })) return list[1];
                        else {
                            return list[0];
                        }
                    }
                }).set('prompt', get.prompt('dybl_muming')).set('prompt2', '你可以预测其于出牌阶段使用的第一张牌的类别');
            }
            "step 2"
            if (result.control && result.control != 'cancel2') {

                var type = result.control;
                trigger.player.addMark('dybl_muming_mark');
                player.addTempSkill('dybl_muming_effect', 'phaseUseEnd');
                player.markAuto('dybl_muming_effect', [type]);
            }
        },
        "_priority": 0,
    },
//#noname-kit-end skill:dybl_muming
//#noname-kit-begin skill:dybl_mengyan
    "dybl_mengyan": {
        group: ["dybl_mengyan_player", "dybl_mengyan_sha", "dybl_mengyan_damage"],
        enable: "phaseUse",
        audio: "ext:朔夜/audio:3",
        filterCard: {
            suit: "heart",
        },
        selectCard: [0, 1],
        position: "he",
        check: function (card) {
            var player = _status.event.player;
            if (player.hp > 2) return 6 - get.value(card);
            return 15 - get.value(card);
        },
        filterTarget: function (event, player, target) {
            return target != player;
        },
        prompt: "弃一张红桃牌或失去一点体力",
        content: function () {
            if (cards.length == 0) {
                player.loseHp();
            }
            target.addTempSkill('dybl_mengyan_target');
        },
        ai: {
            expose: 0.3,
            order: function () {
                return get.order({ name: 'sha' }) + 0.2;
            },
            result: {
                target: function (player, target) {
                    if (!player.canUse('sha', target)) return 0;
                    if (target.hasSkill('dybl_mengyan_target')) return 0;
                    if (!target.getCardUsable('sha') || lib.config.mode === 'stone' && !player.isMin() && player.getActCount() + 1 >= player.actcount) return 0;
                    let shas = player.getCards('hs', card => get.name(card) === 'sha' && !ui.selected.cards.includes(card)), card;
                    if (!shas.length || !target.hasSha()) return 0;
                    return -1;
                },
            },
        },
        subSkill: {
            sha: {
                trigger: {
                    player: "useCardAfter",
                },
                forced: true,
                audio: "dybl_mengyan",
                filter: function (event, player) {
                    return event.card.name == 'sha';
                },
                content: function () {
                    game.hasPlayer(function (current) {
                        if (current.hasSkill('dybl_mengyan_target')) {
                            current.removeSkill('dybl_mengyan_target');
                        }
                    })
                },
                sub: true,
                "_priority": 0,
            },
            player: {
                trigger: {
                    player: "useCardToPlayered",
                },
                audio: "dybl_mengyan",
                filter: function (event, player) {
                    return event.card.name == 'sha' && event.target.hasSkill('dybl_mengyan_target');
                },
                forced: true,
                logTarget: "target",
                content: function () {
                    trigger.getParent().directHit.add(trigger.target);
                },
                sub: true,
                "_priority": 0,
            },
            damage: {
                trigger: {
                    source: "damageBegin",
                },
                forced: true,
                audio: "dybl_mengyan",
                filter: function (event, player) {
                    return event.card.name == 'sha' & event.player.hasSkill('dybl_mengyan_target');
                },
                content: function () {
                    trigger.num += 3;
                },
                sub: true,
                "_priority": 0,
            },
            target: {
                charlotte: true,
                mark: true,
                marktext: "蒙眼",
                intro: {
                    content: "",
                },
                ai: {
                    threaten: 5,
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:dybl_mengyan

//#noname-kit-begin skill:shuoye_qunxing
    "shuoye_qunxing": {
        trigger: {
            player: "phaseBegin",
        },
        direct: true,
        locked: false,
        filter: function (event, player) {
            return player.countCards('hes') > 0;;
        },
        content: function () {
            'step 0'
            player.chooseToDiscard('hes', [1, Infinity], get.prompt2(event.name));
            'step 1'
            if (result.bool) {
                player.logSkill(event.name);
                var cards = get.cards(result.cards.length * 2);
                game.cardsGotoOrdering(cards);
                var next = player.chooseToMove('琴弦：请将其中任意张牌置入', true);
                next.set('list', [
                    ['牌堆顶', cards],
                    ['手牌区'],
                    ['武将牌'],
                ]);
                next.set('filterMove', function (from, to, moved) {
                    var start = player.getExpansions('shuoye_qunxing').length;
                    if (to == 2 && (moved[2].length + start) > 6) return false;
                    return true;
                });
                next.set('processAI', function (list) {
                    var cards = list[0][1].slice(0).sort(function (a, b) {
                        return get.value(b) - get.value(a);
                    });
                    return [, cards, cards.splice(2)];
                })
            } else event.finish();
            'step 2'
            var top = result.moved[0];
            var min = result.moved[1];
            var bottom = result.moved[2];
            for (var i = 0; i < top.length; i++) {
                ui.cardPile.insertBefore(top[i], ui.cardPile.firstChild);
            }
            player.gain(min, 'draw');
            player.addToExpansion(bottom, 'giveAuto', player).gaintag.add('shuoye_qunxing');
            game.updateRoundNumber();
            game.delayx();
        },
        onremove: function (player, skill) {
            var cards = player.getExpansions(skill);
            if (cards.length) player.loseToDiscardpile(cards);
        },
        marktext: "星",
        intro: {
            content: "expansion",
            markcount: "expansion",
        },
        group: "shuoye_qunxing_gain",
        subSkill: {
            gain: {
                trigger: {
                    player: "gainAfter",
                },
                direct: true,
                filter: function (event, player) {
                    return (_status.currentPhase != player || player.isPhaseUsing()) && event.cards && event.cards.length > 0
                },
                content: function () {
                    'step 0'
                    var next = player.chooseToMove('请将其中任意张牌置入或置换', true);
                    next.set('list', [
                        ['获得牌', trigger.cards],
                        ['星', player.getExpansions('shuoye_qunxing')],
                    ]);
                    next.set('filterMove', function (from, to, moved) {
                        if (typeof to != 'number') return true;
                        var start = player.getExpansions('shuoye_qunxing').length;
                        if (to == 0 && moved[0].length >= trigger.cards.length) return false;
                        if (to == 1 && (start > 6)) return false;
                        return true;
                    });
                    next.set('filterOk', (moved) => {
                        return moved[0].length <= trigger.cards.length && moved[1].length <= 7;
                    });
                    next.set('processAI', function (list) {
                        var cards = list[0][1].slice(0).sort(function (a, b) {
                            return get.value(b) - get.value(a);
                        });
                        return [cards, cards.splice(2)];
                    });
                    'step 1'
                    if (result.bool) {
                        var top = result.moved[0];
                        var bottom = result.moved[1];
                        var cards = top.filter(card => !trigger.cards.includes(card));
                        player.gain(cards, 'draw', 'fromStorage');
                        player.addToExpansion(bottom, 'giveAuto', player).gaintag.add('shuoye_qunxing');
                    }
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_qunxing
//#noname-kit-begin skill:shuoye_qinxian
    "shuoye_qinxian": {
        trigger: {
            player: "phaseUseBegin",
        },
        forced: true,
        filter: function (event, player) {
            return !player.getEquips('shuoye_xiaotiqin').length;
        },
        content: function () {
            if (!lib.inpile.contains('shuoye_xiaotiqin')) {
                lib.inpile.push('shuoye_xiaotiqin');
                player.equip(game.createCard('shuoye_xiaotiqin', 'heart', 4));
            }
            else {
                var card = get.cardPile(function (card) {
                    return card.name == 'shuoye_xiaotiqin' && !player.getEquips(1).contains(card);
                }, 'field');
                if (card) player.equip(card);
            }
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_qinxian
//#noname-kit-begin skill:shuoye_shangbian
    "shuoye_shangbian": {
        enable: "phaseUse",
        direct: true,
        locked: false,
        filter: function (event, player) {
            return player.getExpansions('shuoye_qunxing').map(card => get.suit(card)).some(i => !player.getHistory('custom', evt => evt.shuoye_shangbian == i).length);
        },
        content: function () {
            'step 0'
            var next = player.chooseCardButton(true, '选择弃置任意张花色相同的星', player.getExpansions('shuoye_qunxing'));
            next.set('filterButton', button => {
                if (ui.selected.buttons.length) {
                    return get.suit(button.link) == get.suit(ui.selected.buttons[0].link);
                }
                return !player.getHistory('custom', evt => evt.shuoye_shangbian == get.suit(button.link)).length;
            });
            next.set('selectButton', [1, Infinity]);
            next.set('complexSelect', true);
            'step 1'
            if (result.bool) {
                player.discard(result.links);
                event.cards = result.links;
                var suit = get.suit(result.links[0]);
                player.getHistory('custom').push({ shuoye_shangbian: suit });
            } else event.finish();
            'step 2'
            var list = [];
            for (var i = 0; i < lib.inpile.length; i++) {
                var name = lib.inpile[i];
                if (name == 'sha') {
                    list.push(['基本', '', 'sha']);
                    for (var j of lib.inpile_nature) {
                        list.push(['基本', '', 'sha', j]);
                    }
                }
                else if (get.type(name) == 'trick') list.push(['锦囊', '', name]);
                else if (get.type(name) == 'basic') list.push(['基本', '', name]);
            }
            if (!list.length) {
                event.finish();
                return;
            }
            player.chooseButton([[list, 'vcard']], '将一张牌当任意基本牌或普通锦囊牌使用').set('ai', function (button) {
                var player = _status.event.player;
                return player.getUseValue({
                    name: button.link[2],
                    nature: button.link[3],
                });
            }).set('filterButton', function (button) {
                var player = _status.event.player;
                return player.hasUseTarget({ name: button.link[2], nature: button.link[3], });
            });
            'step 3'
            if (result.bool) {
                var vcard = { name: result.links[0][2], nature: result.links[0][3] };
                event.cardx = vcard;
                player.chooseTarget('视为使用' + get.translation(vcard.name), function (card, player, target) {
                    return player.canUse(vcard, target, false, false);
                }).set('selectTarget', () => {
                    return [1, event.cards.length];
                }).set('complexSelect', true).set('filterOk', () => {
                    return ui.selected.targets.length == 1 || ui.selected.targets.length == event.cards.length;
                });
            } else event.finish();
            'step 4'
            if (result.bool) {
                if (result.targets.length > 1) {
                    player.useCard(event.cardx, result.targets, true, false);
                } else {
                    player.chooseUseTarget(event.cardx, result.targets[0], true, false).set('oncard', function (card, player) {
                        _status.event.effectCount = event.cards.length;
                    });
                }
            }
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_shangbian
//#noname-kit-begin skill:shuoye_xiezou
    "shuoye_xiezou": {
        trigger: {
            player: "loseAfter",
        },
        forced: true,
        filter: function (event, player) {
            if (!event.xs || !event.xs.length) return false;
            for (var i in event.gaintag_map) {
                if (event.gaintag_map[i].includes('shuoye_qunxing')) return true;
                return false;
            }
        },
        content: function () {
            'step 0'
            var cards = [];
            for (var i of trigger.xs) {
                if (!trigger.gaintag_map[i.cardid] || !trigger.gaintag_map[i.cardid].includes('shuoye_qunxing')) continue;
                var suit = get.suit(i, false);
                cards.add(suit);
            }
            if (!cards.length) {
                event.finish();
                return;
            }
            event.suits = cards;
            'step 1'
            var suit = event.suits.shift();
            var next = game.createEvent('shuoye_xiezou_' + suit);
            next.player = player;
            next.setContent(lib.skill['shuoye_xiezou']['content_' + suit]);
            'step 2'
            if (event.suits.length) event.goto(1);
        },
        "content_spade": function () {
            'step 0'
            player.chooseTarget('获得一名角色的一张牌', function (card, player, target) {
                return target.countGainableCards(player, 'he');
            });
            'step 1'
            if (result.bool) player.gainPlayerCard(result.targets[0], 'he', true);
        },
        "content_heart": function () {
            'step 0'
            player.chooseTarget('令一名角色摸一张牌', function (card, player, target) {
                return true;
            });
            'step 1'
            if (result.bool) result.targets[0].draw();
        },
        "content_club": function () {
            'step 0'
            player.chooseTarget('令一名角色横置', function (card, player, target) {
                return true;
            });
            'step 1'
            if (result.bool) result.targets[0].link(true);
        },
        "content_diamond": function () {
            'step 0'
            player.chooseTarget('弃置一名角色的一张牌', function (card, player, target) {
                return target.countDiscardableCards(player, 'he');
            });
            'step 1'
            if (result.bool) player.discardPlayerCard(result.targets[0], 'he', true);
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_xiezou
//#noname-kit-begin skill:shuoye_xiaotiqin_skill1
    "shuoye_xiaotiqin_skill1": {
        trigger: {
            player: "useCard2",
        },
        equipSkill: true,
        direct: true,
        filter: function (event, player) {
            if (event.shuoye_xiaotiqin_skill || !event.targets) return false;
            return event.card.name == 'sha' && (!event.cards || !event.cards.length);
        },
        content: function () {
            'step 0'
            trigger.shuoye_xiaotiqin_skill = true;
            player.chooseTarget('为' + get.translation(trigger.card) + '增加一个额外目标', function (card, player, target) {
                var player = _status.event.player;
                if (_status.event.targets.contains(target)) return false;
                return lib.filter.targetEnabled2(_status.event.card, player, target) && lib.filter.targetInRange(_status.event.card, player, target);
            }).set('autodelay', true).set('ai', function (target) {
                var trigger = _status.event.getTrigger();
                var player = _status.event.player;
                return get.effect(target, trigger.card, player, player);
            }).set('targets', trigger.targets).set('card', trigger.card);
            'step 1'
            if (result.bool) {
                player.logSkill(event.name, result.targets);
                trigger.targets.add(result.targets[0]);
            }
        },
        "_priority": -25,
    },
//#noname-kit-end skill:shuoye_xiaotiqin_skill1
//#noname-kit-begin skill:shuoye_xiaotiqin_skill2
    "shuoye_xiaotiqin_skill2": {
        enable: "chooseToUse",
        equipSkill: true,
        viewAs: {
            name: "sha",
            nature: "thunder",
            isCard: true,
        },
        filterCard: () => false,
        selectCard: -1,
        viewAsFilter: function (player) {
            if (player.getExpansions('shuoye_qunxing').length < 2) return false;
        },
        filter: function (event, player) {
            if (player.getExpansions('shuoye_qunxing').length < 2) return false;
            var suits = player.getExpansions('shuoye_qunxing').map(card => get.suit(card));
            var suitx = Array.from(new Set(suits)).length;
            if (suitx < 2) return false;
            return [player.name, player.name1, player.name2].some(i => i == 'shuoye_yuanlv');
        },
        precontent: function () {
            'step 0'
            var next = player.chooseCardButton(true, '选择弃置两张“星”', player.getExpansions('shuoye_qunxing'));
            next.set('filterButton', button => {
                if (ui.selected.buttons.length) {
                    return get.suit(button.link) != get.suit(ui.selected.buttons[0].link);
                }
                return true;
            });
            next.set('selectButton', 2);
            next.set('filterOk', () => ui.selected.buttons.length == 2);
            'step 1'
            player.discard(result.links)
        },
        onuse: function (result, player) {
            _status.event.addCount = false;
        },
        ai: {
            yingbian: function (card, player, targets, viewer) {
                if (get.attitude(viewer, player) <= 0) return 0;
                var base = 0, hit = false;
                if (get.cardtag(card, 'yingbian_hit')) {
                    hit = true;
                    if (targets.some(target => {
                        return target.mayHaveShan(viewer) && get.attitude(viewer, target) < 0 && get.damageEffect(target, player, viewer, get.natureList(card)) > 0;
                    })) base += 5;
                }
                if (get.cardtag(card, 'yingbian_add')) {
                    if (game.hasPlayer(function (current) {
                        return !targets.contains(current) && lib.filter.targetEnabled2(card, player, current) && get.effect(current, card, player, player) > 0;
                    })) base += 5;
                }
                if (get.cardtag(card, 'yingbian_damage')) {
                    if (targets.some(target => {
                        return get.attitude(player, target) < 0 && (hit || !target.mayHaveShan(viewer) || player.hasSkillTag('directHit_ai', true, {
                            target: target,
                            card: card,
                        }, true)) && !target.hasSkillTag('filterDamage', null, {
                            player: player,
                            card: card,
                            jiu: true,
                        })
                    })) base += 5;
                }
                return base;
            },
            canLink: function (player, target, card) {
                if (!target.isLinked() && !player.hasSkill('wutiesuolian_skill')) return false;
                if (target.mayHaveShan() && !player.hasSkillTag('directHit_ai', true, {
                    target: target,
                    card: card,
                }, true)) return false;
                if (player.hasSkill('jueqing') || player.hasSkill('gangzhi') || target.hasSkill('gangzhi')) return false;
                return true;
            },
            basic: {
                useful: [5, 3, 1],
                value: [5, 3, 1],
            },
            order: function (item, player) {
                if (player.hasSkillTag('presha', true, null, true)) return 10;
                if (game.hasNature(item, 'linked')) {
                    if (game.hasPlayer(function (current) {
                        return current != player && current.isLinked() && player.canUse(item, current, null, true) && get.effect(current, item, player, player) > 0 && lib.card.sha.ai.canLink(player, current, item);
                    }) && game.countPlayer(function (current) {
                        return current.isLinked() && get.damageEffect(current, player, player, get.nature(item)) > 0;
                    }) > 1) return 3.1;
                    return 3;
                }
                return 3.05;
            },
            result: {
                target: function (player, target, card, isLink) {
                    var eff = function () {
                        if (!isLink && player.hasSkill('jiu')) {
                            if (!target.hasSkillTag('filterDamage', null, {
                                player: player,
                                card: card,
                                jiu: true,
                            })) {
                                if (get.attitude(player, target) > 0) {
                                    return -7;
                                }
                                else {
                                    return -4;
                                }
                            }
                            return -0.5;
                        }
                        return -1.5;
                    }();
                    if (!isLink && target.mayHaveShan() && !player.hasSkillTag('directHit_ai', true, {
                        target: target,
                        card: card,
                    }, true)) return eff / 1.2;
                    return eff;
                },
            },
            tag: {
                respond: 1,
                respondShan: 1,
                damage: function (card) {
                    if (game.hasNature(card, 'poison')) return;
                    return 1;
                },
                natureDamage: function (card) {
                    if (game.hasNature(card, 'linked')) return 1;
                },
                fireDamage: function (card, nature) {
                    if (game.hasNature(card, 'fire')) return 1;
                },
                thunderDamage: function (card, nature) {
                    if (game.hasNature(card, 'thunder')) return 1;
                },
                poisonDamage: function (card, nature) {
                    if (game.hasNature(card, 'poison')) return 1;
                },
            },
        },
        "_priority": -25,
    },
//#noname-kit-end skill:shuoye_xiaotiqin_skill2
//#noname-kit-begin skill:shuoye_xianzong
    "shuoye_xianzong": {
        trigger: {
            player: "damageBegin4",
        },
        forced: true,
        content: function () {
            'step 0'
            player.chooseButton([
                '###' + get.prompt('shuoye_xianzong') + '###', [[
                    ['gain', '增加1点体力上限，然后失去1点体力'],
                    ['lose', '减少1点体力上限'],
                ], 'textbutton']
            ]).set('ai', function (button) {
                if (get.damageEffect(player, trigger.source || player, player) < 0) return 0;
                if (player.hp > 2) return 'gain';
                if (player.maxHp > 3) return 'lose';
                return 0;
            });
            'step 1'
            if (result.bool) {
                player.logSkill(event.name);
                trigger.cancel();
                if (result.links[0] == 'gain') {
                    player.gainMaxHp();
                    player.loseHp();
                } else {
                    player.loseMaxHp();
                }
            }
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_xianzong
//#noname-kit-begin skill:shuoye_tianya
    shuoye_tianya: {
        locked: false,
        zhuanhuanji: true,
        marktext: "☯",
        intro: {
            content(storage, player, skill) {
                if (player.storage.shuoye_tianya) return '你可以弃一张牌，然后将一张牌改成任意点数使用或打出';
                return '你可以弃一张牌，然后将一张牌作为本轮你使用过的一张牌无次数限制的使用或打出';
            },
        },
        enable: "phaseUse",
        usable: 2,
        async content(event, trigger, player) {
            await player.draw();
            await player.loseMaxHp();
            await player.changeZhuanhuanji('shuoye_tianya');
            await player.addAdditionalSkills('shuoye_tianya', `shuoye_tianya_${player.storage[event.name]}`);
            player.markSkill('shuoye_tianya');
        },
        onremove: (player, skill) => player.removeAdditionalSkill(skill),
        subSkill: {
            true: {
                trigger: {
                    player: ["useCard", "respond"],
                },
                popup: false,
                filter(event, player) {
                    if (!player.storage.shuoye_tianya) return false;
                    return player.countCards('hes');
                },
                async cost(event, trigger, player) {
                    event.result = await player.chooseToDiscard('hes', `你可以弃置一张牌，更改${get.translation(trigger.card)}的点数`)
                        .set('chooseonly', true)
                        .forResult();
                },
                async content(event, trigger, player) {
                    player.logSkill(event.name);
                    await player.discard(event.cards);
                    const { result: { bool, links } } = await player.chooseButton(true, [`更改${get.translation(trigger.card)}点数`, [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13], 'tdnodes']])
                        .set('ai', button => {
                            return 1 + Math.random();
                        });
                    if (bool) {
                        game.log(player, '将', trigger.card, '的点数改为', links[0]);
                        trigger.card.number = links[0];
                    }
                },
            },
            false: {
                enable: ["chooseToUse", "chooseToRespond"],
                filter(event, player) {
                    if (player.storage.shuoye_tianya) return false;
                    if (!player.countCards('hse')) return false;
                    const list = player.getRoundHistory('useCard', evt => {
                        return ['basic', 'trick'].includes(get.type(evt.card));
                    }).map(evt => evt.card.name);
                    for (var i of list) {
                        var type = get.type2(i);
                        if (player.getStorage('shuoye_tianya_used').includes(i)) continue;
                        if ((type == 'basic' || type == 'trick') && event.filterCard({ name: i }, player, event)) return true;
                    }
                    return false;
                },
                chooseButton: {
                    dialog(event, player) {
                        const list = player.getRoundHistory('useCard', evt => {
                            return ['basic', 'trick'].includes(get.type(evt.card));
                        }).map(evt => evt.card.name);
                        return ui.create.dialog('天涯', [list, 'vcard']);
                    },
                    filter(button, player) {
                        if (player.getStorage('shuoye_tianya_used').includes(button.link[2])) return false;
                        return _status.event.getParent().filterCard({ name: button.link[2] }, player, _status.event.getParent());
                    },
                    check(button) {
                        if (_status.event.getParent().type != 'phase') return 1;
                        var player = _status.event.player;
                        if (['wugu', 'zhulu_card', 'yiyi', 'lulitongxin', 'lianjunshengyan', 'diaohulishan'].contains(button.link[2])) return 0;
                        return player.getUseValue({
                            name: button.link[2],
                            nature: button.link[3],
                        });
                    },
                    backup(links, player) {
                        return {
                            filterCard: true,
                            check(card) {
                                return 8 - get.value(card);
                            },
                            position: 'hse',
                            viewAs: {
                                name: links[0][2],
                                nature: links[0][3]
                            },
                            log: false,
                            async precontent(event, trigger, player) {
                                const { result: { bool } } = await player.chooseToDiscard('hes', function (card) {
                                    const player = get.player();
                                    return !get.event('cardx').includes(card)
                                })
                                    .set('cardx', event.result.cards)
                                    .set('ai', card => {
                                        return 8 - get.value(card);
                                    });
                                if (bool) {
                                    player.logSkill('shuoye_tianya_backup');
                                    player.addTempSkill('shuoye_tianya_used');
                                    player.markAuto('shuoye_tianya_used', [event.result.card.name]);
                                    event.getParent().addCount = false;
                                } else {
                                    event.parent.cancel();
                                    event.parent.goto(0);
                                    event.getParent(2).goto(0);
                                }
                            },
                        }
                    },
                    prompt(links, player) {
                        return '你可以将一张牌当做' + (get.translation(links[0][3]) || '') + get.translation(links[0][2]) + '使用';
                    },
                },
                hiddenCard(player, name) {
                    if (!lib.inpile.contains(name)) return false;
                    var type = get.type2(name);
                    if (player.getStorage('shuoye_tianya_used').includes(name)) return false;
                    return (type == 'basic' || type == 'trick') && player.countCards('she') > 0 && player.storage.shuoye_tianya == false;
                },
                ai: {
                    respondSha: true,
                    respondShan: true,
                    skillTagFilter(player) {
                        if (!player.countCards('hse') || player.storage.shuoye_tianya) return false;
                    },
                    order: 1,
                    result: {
                        player(player) {
                            if (_status.event.dying) return get.attitude(player, _status.event.dying);
                            return 1;
                        },
                    },
                },
            },
            false_backup: {},
            used: {
                onremove: true,
                intro: {
                    content: "$",
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_tianya
//#noname-kit-begin skill:shuoye_fusheng
    "shuoye_fusheng": {
        trigger: {
            player: "useCardAfter",
        },
        filter: function (event, player) {
            if (typeof get.number(event.card, false) != 'number') return false;
            var cards = player.getExpansions('shuoye_fusheng');
            return !cards.length || cards.map(i => get.number(i)).every(num => get.number(event.card) != num);
        },
        content: function () {
            var cards = trigger.cards.filterInD('oe');
            player.addToExpansion(cards, 'gain2').gaintag.add('shuoye_fusheng');
        },
        intro: {
            markcount: "expansion",
            mark: function (dialog, content, player) {
                var content = player.getExpansions('shuoye_fusheng');
                if (content && content.length) {
                    dialog.addAuto(content);
                }
            },
        },
        group: "shuoye_fusheng_end",
        subSkill: {
            end: {
                trigger: {
                    player: "useCardEnd",
                },
                direct: true,
                filter: function (event, player) {
                    if (typeof get.number(event.card, false) != 'number') return false;
                    if (!player.getExpansions('shuoye_fusheng').length) return false;
                    return player.getExpansions('shuoye_fusheng').map(i => get.number(i)).some(num => get.number(event.card) == num);
                },
                content: function () {
                    'step 0'
                    player.chooseButton(['浮生：你可以弃置一张牌', player.getExpansions('shuoye_fusheng')]);
                    'step 1'
                    if (result.bool) {
                        player.logSkill('shuoye_fusheng');
                        player.loseToDiscardpile(result.links);
                    } else event.finish();
                    'step 2'
                    if (player.getExpansions('shuoye_fusheng').length) {
                        player.chooseButton(['浮生：是否获得一张牌？取消则你摸一张牌', player.getExpansions('shuoye_fusheng')]);
                    } else event.goto(4)
                    'step 3'
                    if (result.bool) {
                        player.gain(result.links, 'gain2', 'fromStorage');
                        event.finish();
                    }
                    'step 4'
                    player.draw();
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_fusheng
//#noname-kit-begin skill:shuoye_duchen
    "shuoye_duchen": {
        audio: "ext:朔夜/audio:1",
        enable: "phaseUse",
        mark: true,
        skillAnimation: true,
        limited: true,
        animationColor: "orange",
        filter: function (event, player) {
            return player.hp > 0;
        },
        content: function () {
            'step 0'
            player.awakenSkill(event.name);
            'step 1'
            var num = player.hp;
            player.addTempSkill('shuoye_duchen_dying');
            player.setStorage('shuoye_duchen_dying', num);
            player.loseHp(num);
        },
        subSkill: {
            dying: {
                trigger: {
                    player: 'dying',
                },
                forced: true,
                popup: false,
                charlotte: true,
                onremove: true,
                filter(event, player) {
                    return event.getParent(2).name == 'shuoye_duchen';
                },
                async content(event, trigger, player) {
                    player.addTempSkill('shuoye_duchen_effect');
                    var next = player.chooseUseTarget({ name: 'sha' }, true, false);
                    next.set('oncard', function (card, player) {
                        _status.event.directHit.addArray(game.players);
                        _status.event.baseDamage += (player.storage[event.name] || 0);
                    });
                    next.card.shuoye_xianzong = true;
                    await next;
                    delete player.storage[event.name];
                },
            },
            effect: {
                trigger: {
                    player: "useCardToPlayered",
                    global: "dieAfter",
                },
                forced: true,
                priority: 15,
                charlotte: true,
                filter: function (event, player) {
                    var i = 1;
                    if (event.name == 'die') return event.getParent(3).card.shuoye_xianzong;
                    if (!event.targets || !event.targets.length) return false;
                    return event.card.name == 'sha' && event.card.shuoye_duchen;
                },
                content: function () {
                    if (trigger.name == 'die') {
                        player.recover(2 - player.hp);
                    } else trigger.targets.forEach(i => i.addTempSkill('fengyin'));
                },
                ai: {
                    unequip: true,
                    skillTagFilter: function (player, tag, arg) {
                        if (!arg || !arg.card || arg.card.name != 'sha' || !arg.card.shuoye_duchen) return false;
                    },
                },
                sub: true,
                "_priority": 1500,
            },
        },
        ai: {
            order: 1,
            result: {
                player: function (player) {
                    return 1;
                },
            },
        },
        intro: {
            content: "limited",
        },
        init: (player, skill) => player.storage[skill] = false,
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_duchen
//#noname-kit-begin skill:shuoye_benghuai
    "shuoye_benghuai": {
        trigger: {
            player: "useCard",
        },
        priority: 10,
        filter: function (event, player) {
            var type1 = get.type2(event.card), type2 = player.storage.shuoye_benghuai_record;
            return type2 && type1 != type2;
        },
        forced: true,
        locked: false,
        content: function () {
            player.draw();
            if (player.countMark('shuoye_benghuai') < 14) player.addMark('shuoye_benghuai');
        },
        mod: {
            attackRange: function (player, num) {
                return num += 1;
            },
        },
        marktext: "空",
        intro: {
            name: "空",
            content: "mark",
        },
        group: ["shuoye_benghuai_damage", "shuoye_benghuai_record"],
        subSkill: {
            damage: {
                trigger: {
                    player: "damageEnd",
                },
                forced: true,
                locked: false,
                content: function () {
                    'step 0'
                    event.count = trigger.num;
                    'step 1'
                    event.count--;
                    player.draw();
                    if (player.countMark('shuoye_benghuai') < 14) player.addMark('shuoye_benghuai');
                    'step 2'
                    if (event.count) event.goto(1)
                },
                sub: true,
                "_priority": 0,
            },
            record: {
                trigger: {
                    player: ["useCardAfter", "respondAfter"],
                },
                forced: true,
                locked: false,
                firstDo: true,
                filter: function (event, player) {
                    return get.type2(event.card) != undefined;
                },
                content: function () {
                    player.storage.shuoye_benghuai_record = get.type2(trigger.card);
                    player.markSkill('shuoye_benghuai_record');
                },
                marktext: "\u0000",
                intro: {
                    markcount: function (storage, player) {
                        return get.translation(storage).slice(0, 1);
                    },
                    content: "$",
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 1000,
    },
//#noname-kit-end skill:shuoye_benghuai
//#noname-kit-begin skill:shuoye_yakong
    "shuoye_yakong": {
        trigger: {
            player: "useCard",
        },
        locked: false,
        filter: function (event, player) {
            return lib.skill.shuoye_yakong.filterx(event) && player.countMark('shuoye_benghuai');
        },
        filterx: function (event) {
            if (event.targets.length == 0) return false;
            var type = get.type(event.card);
            if (type != 'basic' && type != 'trick') return false;
            return true;
        },
        content: function () {
            player.removeMark('shuoye_benghuai');
            if (lib.skill.shuoye_yakong.filterx(trigger)) {
                trigger.effectCount++;
                game.log(trigger.card, '额外结算一次');
            }
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_yakong
//#noname-kit-begin skill:shuoye_zhendang
    "shuoye_zhendang": {
        enable: "phaseUse",
        usable: 1,
        filter: function (event, player) {
            return player.countMark('shuoye_benghuai') > 3;
        },
        content: function () {
            player.removeMark('shuoye_benghuai', 3);
            player.addTempSkill('shuoye_zhendang_effect');
        },
        ai: {
            order: 2,
            result: {
                player: function (player) {
                    return player.hasUseTarget({ name: 'sha' }) && player.countCards('hs', { name: 'sha' });
                },
            },
        },
        subSkill: {
            effect: {
                charlotte: true,
                trigger: {
                    source: "damageBefore",
                },
                forced: true,
                locked: false,
                filter: function (event, player) {
                    return event.card && event.card.name == 'sha';
                },
                content: function () {
                    game.setNature(trigger, 'thunder');
                },
                mod: {
                    cardUsable: function (card, player) {
                        return Infinity;
                    },
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_zhendang
//#noname-kit-begin skill:shuoye_xujie
    "shuoye_xujie": {
        audio: "ext:朔夜/audio:1",
        enable: "phaseUse",
        mark: true,
        skillAnimation: true,
        limited: true,
        animationColor: "orange",
        filter: function (event, player) {
            return player.countMark('shuoye_benghuai') == 14;
        },
        content: function () {
            'step 0'
            player.awakenSkill(event.name);
            'step 1'
            player.gainMaxHp(2);
            player.recover(2);
            player.removeMark('shuoye_benghuai', player.countMark('shuoye_benghuai'));
            'step 2'
            player.turnOver();
            event.targetsx = game.filterPlayer(i => i != player).sortBySeat();
            'step 3'
            event.count = 0;
            event.targetx = event.targetsx.shift();
            'step 4'
            event.count++;
            if (event.targetx.isIn()) event.targetx.damage('thunder');
            if (event.count < 3) event.redo();
            'step 5'
            event.targetx.discard(event.targetx.getCards('hej'));
            if (event.targetsx.length) event.goto(3);
        },
        ai: {
            order: 1,
            result: {
                player: function (player) {
                    return 1;
                },
            },
        },
        intro: {
            content: "limited",
        },
        init: (player, skill) => player.storage[skill] = false,
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_xujie
//#noname-kit-begin skill:shuoye_guanxing
    "shuoye_guanxing": {
        trigger: {
            player: ["phaseZhunbeiBegin", "phaseJieshuBegin"],
        },
        frequent: true,
        content: function () {
            'step 0'
            var cards = get.cards(7);
            game.cardsGotoOrdering(cards);
            var next = player.chooseToMove();
            next.set('list', [
                ['牌堆顶', cards],
                ['牌堆底'],
                ['获得'],
            ]);
            next.set('prompt', '观星：获得其中一个类别的牌，然后将其余牌以任意顺序放回牌堆顶或牌堆底');
            next.set('filterOk', function (moved) {
                if (!moved[2].length) return true;
                return moved[2].every(card => get.type2(card) == get.type2(moved[2][0]));
            });
            next.set('processAI', function (list) {
                var cards = list[0][1], player = _status.event.player;
                var target = (_status.event.getTrigger().name == 'phaseZhunbei') ? player : player.next;
                var att = get.sgn(get.attitude(player, target));
                var top = [];
                var judges = target.getCards('j');
                var stopped = false;
                if (player != target || !target.hasWuxie()) {
                    for (var i = 0; i < judges.length; i++) {
                        var judge = get.judge(judges[i]);
                        cards.sort(function (a, b) {
                            return (judge(b) - judge(a)) * att;
                        });
                        if (judge(cards[0]) * att < 0) {
                            stopped = true; break;
                        }
                        else {
                            top.unshift(cards.shift());
                        }
                    }
                }
                var bottom;
                if (!stopped) {
                    cards.sort(function (a, b) {
                        return (get.value(b, player) - get.value(a, player)) * att;
                    });
                    while (cards.length) {
                        if ((get.value(cards[0], player) <= 5) == (att > 0)) break;
                        top.unshift(cards.shift());
                    }
                }
                bottom = cards;
                var TempCards1 = top.slice(0);
                var TempCards2 = bottom.slice(0);
                var gain = TempCards1.addArray(TempCards2)[TempCards1.addArray(TempCards2).length - 1];
                top.remove(gain);
                bottom.remove(gain);
                return [top, bottom, [gain]];
            });
            'step 1'
            var top = result.moved[0];
            var bottom = result.moved[1];
            var gain = result.moved[2];
            top.reverse();
            for (var i = 0; i < top.length; i++) {
                ui.cardPile.insertBefore(top[i], ui.cardPile.firstChild);
            }
            for (i = 0; i < bottom.length; i++) {
                ui.cardPile.appendChild(bottom[i]);
            }
            player.popup(get.cnNumber(top.length) + '上' + get.cnNumber(bottom.length) + '下');
            game.log(player, '将' + get.cnNumber(top.length) + '张牌置于牌堆顶');
            game.log(player, '将' + get.cnNumber(bottom.length) + '张牌置于牌堆底');
            game.updateRoundNumber();
            player.gain(gain, 'draw');
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_guanxing
//#noname-kit-begin skill:shuoye_jiugong
    "shuoye_jiugong": {
        trigger: {
            player: "useCard",
        },
        direct: true,
        filter: function (event, player) {
            return player.countCards('hes');
        },
        content: function () {
            'step 0'
            player.chooseToDiscard('hes', function (card) {
                for (var i = 0; i < ui.selected.cards.length; i++) {
                    if (get.type(card) == get.type(ui.selected.cards[i])) return false;
                }
                return true;
            }).set('complexCard', true).set('selectCard', [1, 3]);
            'step 1'
            if (result.bool) {
                player.logSkill(event.name)
                var num = player.countMark(event.name);
                if (num >= 9) return;
                if ((num + result.cards.length) >= 9) {
                    player.addMark(event.name, 9 - num);
                } else player.addMark(event.name, result.cards.length);
            }
        },
        mod: {
            maxHandcardBase: function (player, num) {
                return player.maxHp + player.getStorage('shuoye_jiugong');
            },
        },
        marktext: "宫",
        intro: {
            name: "宫",
            content: "mark",
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_jiugong
//#noname-kit-begin skill:shuoye_wuxing
    "shuoye_wuxing": {
        enable: "phaseUse",
        usable: 3,
        filter: function (event, player) {
            return player.countMark('shuoye_jiugong')
        },
        filterTarget: true,
        content: function () {
            'step 0'
            player.removeMark('shuoye_jiugong');
            player.chooseButton(true, [
                '五行', [[
                    ['xuanwu', '玄武：本轮如果受到大于一的伤害，将其改为一，且你受到伤害时可摸一张牌'],
                    ['zhuque', '朱雀：本轮造成的伤害都改为火焰伤害，且你每造成一点伤害，可以弃置一名角色一张牌'],
                    ['canglong', '苍龙：本轮使用牌点数为上一张的约数或倍数时可摸一张牌'],
                    ['baihu', '白虎：本轮出牌后可进行判定，为黑则不可被响应，为红则额外结算一次'],
                    ['qilin', '麒麟：本轮每回合限一次，你可将一张牌作为任意牌使用'],
                ], 'textbutton']
            ]);
            'step 1'
            if (result.bool) {
                target.addTempSkill('shuoye_wuxing_' + result.links[0], 'roundStart');
                if (['xuanwu', 'zhuque'].includes(result.links[0])) {
                    player.addTempSkill('shuoye_wuxing_' + result.links[0] + '2', 'roundStart');
                }
            }
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_wuxing
//#noname-kit-begin skill:shuoye_wuxing_xuanwu
    "shuoye_wuxing_xuanwu": {
        trigger: {
            player: "damageBegin3",
        },
        forced: true,
        charlotte: true,
        filter: function (event, player) {
            return event.num > 1;
        },
        content: function () {
            trigger.num = 1;
        },
        ai: {
            filterDamage: true,
            skillTagFilter: function (player, tag, arg) {
                if (arg && arg.player) {
                    if (arg.player.hasSkillTag('jueqing', false, player)) return false;
                }
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_wuxing_xuanwu
//#noname-kit-begin skill:shuoye_wuxing_xuanwu2
    "shuoye_wuxing_xuanwu2": {
        trigger: {
            player: "damageBegin1",
        },
        charlotte: true,
        prompt: "当你受到伤害时，你可以摸一张牌",
        content: function () {
            player.draw();
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_wuxing_xuanwu2
//#noname-kit-begin skill:shuoye_wuxing_zhuque
    "shuoye_wuxing_zhuque": {
        trigger: {
            source: "damageBegin1",
        },
        forced: true,
        charlotte: true,
        filter: function (event, player) {
            return true;
        },
        content: function () {
            game.setNature(trigger, 'fire');
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_wuxing_zhuque
//#noname-kit-begin skill:shuoye_wuxing_zhuque2
    "shuoye_wuxing_zhuque2": {
        trigger: {
            source: "damageSource",
        },
        direct: true,
        charlotte: true,
        filter: function (event, player) {
            return game.hasPlayer(current => current.countDiscardableCards('he', player));
        },
        content: function () {
            'step 0'
            event.count = trigger.num;
            'step 1'
            event.count--;
            player.chooseTarget('你可以弃置一名角色的一张牌', function (card, player, target) {
                return target.countDiscardableCards('he', player);
            });
            'step 2'
            if (result.bool) {
                var target = result.targets[0];
                player.logSkill(event.name, target);
                player.discardPlayerCard('he', target, true);
            }
            'step 3'
            if (event.count && game.hasPlayer(current => current.countDiscardableCards('he', player))) event.goto(1);
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_wuxing_zhuque2
//#noname-kit-begin skill:shuoye_wuxing_canglong
    "shuoye_wuxing_canglong": {
        trigger: {
            player: ["useCard", "useCardAfter"],
        },
        direct: true,
        charlotte: true,
        filter: function (event, player, name) {
            if (name == 'useCardAfter') return typeof get.number(event.card) == 'number';
            var num1 = get.number(event.card), num2 = player.storage.shuoye_wuxing_canglong;
            return typeof num1 == 'number' && typeof num2 == 'number' && (num2 % num1 == 0 || num1 % num2 == 0);
        },
        content: function () {
            'step 0'
            if (event.triggername == 'useCardAfter') {
                player.storage.shuoye_wuxing_canglong = get.number(trigger.card);
                player.markSkill('xingtu');
                event.finish();
                return;
            }
            player.chooseBool('你可以摸一张牌');
            'step 1'
            if (result.bool) {
                player.draw();
            }
        },
        mod: {
            aiOrder: function (player, card, num) {
                var num1 = get.number(card), num2 = player.storage.shuoye_wuxing_canglong;
                if (typeof num1 == 'number' && typeof num2 == 'number' && (num2 % num1 == 0 || num1 % num2 == 0)) return num + 5;
            },
        },
        marktext: "苍龙",
        intro: {
            content: "当前记录：X=#",
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_wuxing_canglong
//#noname-kit-begin skill:shuoye_wuxing_baihu
    "shuoye_wuxing_baihu": {
        trigger: {
            player: "useCard",
        },
        frequent: true,
        charlotte: true,
        filter: function (event, player) {
            return ['basic', 'trick'].includes(get.type(event.card));
        },
        content: function () {
            'step 0'
            player.judge();
            'step 1'
            if (result.color == 'black') {
                trigger.directHit.addArray(game.players);
            } else if (result.color == 'red') {
                trigger.effectCount++
            }
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_wuxing_baihu
//#noname-kit-begin skill:shuoye_wuxing_qilin
    "shuoye_wuxing_qilin": {
        enable: ["chooseToUse", "chooseToRespond"],
        filter: function (event, player) {
            if (!player.countCards('hse') || player.hasSkill('shuoye_wuxing_qilin2')) return false;
            for (var i of lib.inpile) {
                var type = get.type2(i);
                if ((type == 'basic' || type == 'trick') && event.filterCard({ name: i }, player, event)) return true;
            }
            return false;
        },
        chooseButton: {
            dialog: function (event, player) {
                var list = [];
                for (var i = 0; i < lib.inpile.length; i++) {
                    var name = lib.inpile[i];
                    if (name == 'sha') {
                        if (event.filterCard({ name: name }, player, event)) list.push(['基本', '', 'sha']);
                        for (var j of lib.inpile_nature) {
                            if (event.filterCard({ name: name, nature: j }, player, event)) list.push(['基本', '', 'sha', j]);
                        }
                    }
                    else if (get.type2(name) == 'trick' && event.filterCard({ name: name }, player, event)) list.push(['锦囊', '', name]);
                    else if (get.type(name) == 'basic' && event.filterCard({ name: name }, player, event)) list.push(['基本', '', name]);
                }
                return ui.create.dialog('麒麟', [list, 'vcard']);
            },
            filter: function (button, player) {
                return _status.event.getParent().filterCard({ name: button.link[2] }, player, _status.event.getParent());
            },
            check: function (button) {
                if (_status.event.getParent().type != 'phase') return 1;
                var player = _status.event.player;
                if (['wugu', 'zhulu_card', 'yiyi', 'lulitongxin', 'lianjunshengyan', 'diaohulishan'].contains(button.link[2])) return 0;
                return player.getUseValue({
                    name: button.link[2],
                    nature: button.link[3],
                });
            },
            backup: function (links, player) {
                return {
                    filterCard: true,
                    popname: true,
                    check: function (card) {
                        return 8 - get.value(card);
                    },
                    position: 'hse',
                    viewAs: { name: links[0][2], nature: links[0][3] },
                    precontent: function () {
                        player.addTempSkill('shuoye_wuxing_qilin2');
                    },
                }
            },
            prompt: function (links, player) {
                return '将一张牌当做' + (get.translation(links[0][3]) || '') + get.translation(links[0][2]) + '使用';
            },
        },
        hiddenCard: function (player, name) {
            if (!lib.inpile.contains(name)) return false;
            var type = get.type2(name);
            return (type == 'basic' || type == 'trick') && player.countCards('she') > 0 && !player.hasSkill('shuoye_wuxing_qilin2');
        },
        ai: {
            fireAttack: true,
            respondSha: true,
            respondShan: true,
            skillTagFilter: function (player) {
                if (!player.countCards('hse') || player.hasSkill('shuoye_wuxing_qilin2')) return false;
            },
            order: 1,
            result: {
                player: function (player) {
                    if (_status.event.dying) return get.attitude(player, _status.event.dying);
                    return 1;
                },
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_wuxing_qilin
//#noname-kit-begin skill:shuoye_wuxing_qilin2
    "shuoye_wuxing_qilin2": {
        charlotte: true,
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_wuxing_qilin2
//#noname-kit-begin skill:shuoye_bazhen
    "shuoye_bazhen": {
        enable: "phaseUse",
        mark: true,
        skillAnimation: true,
        limited: true,
        animationColor: "orange",
        filterTarget: function (card, player, target) {
            return target.countGainableCards('hej', player);
        },
        selectTarget: [0, 1],
        content: function () {
            'step 0'
            player.awakenSkill(event.name);
            'step 1'
            if (target) {
                player.gainPlayerCard(target, 'hej', true);
            } else player.draw();
            'step 2'
            player.gainMaxHp(2)
            player.recover();
            player.addTempSkill('shuoye_bazhen_effect', 'roundStart');
        },
        ai: {
            order: 10,
            result: {
                target: -1,
            },
        },
        intro: {
            content: "limited",
        },
        init: (player, skill) => player.storage[skill] = false,
        subSkill: {
            effect: {
                trigger: {
                    player: "loseAfter",
                    global: ["equipAfter", "addJudgeAfter", "gainAfter", "loseAsyncAfter", "addToExpansionAfter"],
                },
                direct: true,
                charlotte: true,
                filter: function (event, player) {
                    if (event.name == 'gain' && event.player == player) return false;
                    var evt = event.getl(player);
                    return evt && evt.cards2 && evt.cards2.length;
                },
                content: function () {
                    'step 0'
                    player.chooseTarget('令一名角色回复1点体力', function (card, player, target) {
                        return target.isDamaged();
                    }).set('ai', function (target) {
                        return get.recoverEffect(target, _status.event.player, _status.event.player)
                    });
                    'step 1'
                    if (result.bool) {
                        var target = result.targets[0];
                        player.logSkill(event.name, target);
                        target.recover();
                    }
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_bazhen
//#noname-kit-begin skill:shuoye_baishe
    "shuoye_baishe": {
        audio: "ext:朔夜/audio:12",
        enable: "chooseToUse",
        prompt: "你可以将黑色当做【借刀杀人】或者【无懈可击】，红色牌当【乐不思蜀】使用",
        intro: {
            content: "#/14",
        },
        filter(event, player) {
            var filter = event.filterCard;
            if ((filter({ name: 'lebu' }, player, event)) && player.countCards('hes', { color: 'red' })) return true;
            if ((filter({ name: 'jiedao' }, player, event) || filter({ name: 'wuxie' }, player, event)) && player.countCards('hes', { color: 'black' })) return true;
            return false;
        },
        chooseButton: {
            dialog(event, player) {
                var list = [];
                if (event.filterCard({ name: 'jiedao' }, player, event)) list.push(['锦囊', '', 'jiedao']);
                if (event.filterCard({ name: 'wuxie' }, player, event)) list.push(['锦囊', '', 'wuxie']);
                if (event.filterCard({ name: 'lebu' }, player, event)) list.push(['锦囊', '', 'lebu']);
                return ui.create.dialog('白蛇', [list, 'vcard']);
            },
            filter(button, player) {
                return _status.event.getParent().filterCard({ name: button.link[2] }, player, _status.event.getParent());
            },
            check(button) {
                if (_status.event.getParent().type != 'phase') return 1;
                var player = _status.event.player;
                return player.getUseValue({
                    name: button.link[2],
                    nature: button.link[3],
                });
            },
            backup(links, player) {
                return {
                    filterCard(card, player) {
                        if ((links[0][2]) == 'lebu') return get.color(card) == 'red';
                        else if ((links[0][2]) == 'jiedao' || (links[0][2]) == 'wuxie') return get.color(card) == 'black';
                    },
                    popname: true,
                    check(card) {
                        return 7 - get.value(card);
                    },
                    precontent() {
                        player.addMark('shuoye_baishe', 1, false);
                        if (player.countMark('shuoye_baishe') < 14) return;
                        player.addSkill('shuoye_xinyue');
                        player.addSkill('shuoye_qiangyun');
                    },
                    position: 'hes',
                    viewAs: {
                        name: links[0][2],
                        nature: links[0][3],
                    },
                }
            },
            prompt(links, player) {
                return '将一张牌当做' + (get.translation(links[0][3]) || '') + get.translation(links[0][2]) + '使用';
            },
        },
        ai: {
            order: 7,
            result: {
                player(player) {
                    return 1;
                },
            },
        },
        hiddenCard(player, name) {
            if (name == 'wuxie' && _status.connectMode && player.countCards('hes', { color: 'black' }) > 0) return true;
            if (name == 'wuxie') return player.countCards('hes', { color: 'black' });
        },
    },
//#noname-kit-end skill:shuoye_baishe
//#noname-kit-begin skill:shuoye_xinyue
    shuoye_xinyue: {
        enable: "phaseUse",
        limited: true,
        skillAnimation: true,
        animationColor: "water",
        content() {
            'step 0'
            player.awakenSkill(event.name);
            'step 1'
            game.playAudio('../extension', '朔夜', 'audio/shuoye_xinyue_before.mp3');
            event.targets1 = game.filterPlayer().sortBySeat();
            event.targets2 = game.filterPlayer(i => i != player).sortBySeat()
            'step 2'
            game.playAudio('../extension', '朔夜', 'audio/shuoye_xinyue_begin.mp3');
            game.delay();
            'step 3'
            var current = event.targets1.shift();
            if (current.isIn()) current.damage();
            if (event.targets1.length) event.redo();
            'step 4'
            game.playAudio('../extension', '朔夜', 'audio/shuoye_xinyue_end.mp3');
            game.delay();
            'step 5'
            var cur = event.targets2.shift();
            if (cur.isIn() && cur.countCards('e')) {
                if (cur.countCards('e')) {
                    cur.discard(cur.getCards('e'));
                }
            }
            if (event.targets2.length) event.redo();
            'step 6'
            game.playAudio('../extension', '朔夜', 'audio/shuoye_xinyue_after.mp3');
            game.delay();
            'step 7'
            game.playAudio('../extension', '朔夜', 'audio/shuoye_xinyue_finally.mp3');
            game.delay();
            player.gainMaxHp();
            player.recover();
            player.addSkill('shuoye_tianzao');
            game.playAudio('../extension', '朔夜', 'audio/shuoye_xinyue_shangtiantang' + (Math.random() < 0.5 ? '1' : '2') + '.mp3');
        },
        ai: {
            order: 10,
            result: {
                player: function (player) {
                    return game.countPlayer(function (current) {
                        if (current != player) {
                            return get.sgn(get.damageEffect(current, player, player));
                        }
                    });
                },
            },
        },
        intro: {
            content: "limited",
        },
        init: (player, skill) => player.storage[skill] = false,
        mark: true,
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_xinyue
//#noname-kit-begin skill:shuoye_tianzao
    "shuoye_tianzao": {
        audio: "ext:朔夜/audio:2",
        trigger: {
            player: "loseAfter",
            global: ["phaseBefore", "equipAfter", "addJudgeAfter", "gainAfter", "loseAsyncAfter", "addToExpansionAfter"],
        },
        forced: true,
        filter: function (event, player) {
            if (event.name == 'phase') return true;
            if (event.name == 'gain' && event.player == player) return player.countCards('h') > 7;
            var evt = event.getl(player);
            if (!evt || !evt.hs || evt.hs.length == 0 || player.countCards('h') >= 7) return false;
            var evt = event;
            for (var i = 0; i < 7; i++) {
                evt = evt.getParent('shuoye_tianzao');
                if (evt.name != 'shuoye_tianzao') return true;
            }
            return false;
        },
        content: function () {
            var num = 7 - player.countCards('h');
            if (num > 0) player.draw(num);
            else if (num < 0) player.chooseToDiscard('h', true, -num);
        },
        mod: {
            cardnature: function (card, player) {
                if (get.name(card) == 'sha') return 'thunder';
            },
        },
        group: ["shuoye_tianzao_1", "shuoye_tianzao_2"],
        subSkill: {
            "1": {
                trigger: {
                    player: ["useCard", "useCardToPlayered"],
                },
                forced: true,
                filter: function (event, player, name) {
                    if (name == 'useCard') return event.card.name == 'sha' && game.hasNature(event.card, 'thunder');
                    return event.card.name == 'sha' && game.hasNature(event.card, 'thunder') && !event.getParent().directHit.contains(event.target);
                },
                logTarget: "target",
                content: function () {
                    if (event.triggername == 'useCard') {
                        trigger.baseDamage += 1;
                        return;
                    }
                    var id = trigger.target.playerid;
                    var map = trigger.getParent().customArgs;
                    if (!map[id]) map[id] = {};
                    if (typeof map[id].shanRequired == 'number') {
                        map[id].shanRequired++;
                    }
                    else {
                        map[id].shanRequired = 2;
                    }
                },
                ai: {
                    "directHit_ai": true,
                    skillTagFilter: function (player, tag, arg) {
                        if (arg.card.name != 'sha' || arg.target.countCards('h', 'shan') > 1) return false;
                    },
                },
                sub: true,
                "_priority": 0,
            },
            "2": {
                audio: "ext:朔夜/audio:2",
                trigger: {
                    player: "phaseAfter",
                },
                "prompt2": "你可以执行一个额外的回合",
                filter: function (event, player) {
                    return event.name == 'phase' && !event.skill;
                },
                content: function () {
                    player.insertPhase();
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_tianzao
//#noname-kit-begin skill:shuoye_qiangyun
    "shuoye_qiangyun": {
        audio: "ext:朔夜/audio:2",
        trigger: {
            player: "dying",
        },
        forced: true,
        content: function () {
            'step 0'
            player.judge(function (card) {
                return get.suit(card) == 'heart' ? 2 : -2;
            });
            'step 1'
            if (result.bool) {
                game.playAudio('../extension', '朔夜', 'audio/判红桃复活.mp3');
                player.recover(1 - player.hp);
            }
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_qiangyun
//#noname-kit-begin skill:shuoye_shuangsheng
    shuoye_shuangsheng: {
        derivation: ["shuoye_shuangsheng_true", "shuoye_shuangsheng_recover", "shuoye_shuangsheng_false", "shuoye_shuangsheng_damage"],
        mark: true,
        locked: false,
        zhuanhuanji: true,
        marktext: "☯",
        intro: {
            content: function (storage, player, skill) {
                var str = player.storage[skill] ? '你可以弃该花色的牌，视为对他人或自己使用【桃】。场上每有一名角色恢复1点体力，你可摸一张牌' : '该花色的牌可以造成双倍伤害。场上每有角色造成1点伤害，你摸一张牌';
                if (player.storage[skill + '_Skill']) {
                    str += '<br><li>当前花色：';
                    str += get.translation(player.storage[skill + '_Skill']);
                }
                return str;
            },
        },
        enable: "phaseUse",
        usable: 1,
        content: function () {
            'step 0'
            player.draw();
            player.changeZhuanhuanji('shuoye_shuangsheng');
            'step 1'
            if (player.storage[event.name] == true) game.playAudio('../extension', '朔夜', 'audio/shuoye_shuangsheng_changeZhuanhuanji_false.mp3');
            else game.playAudio('../extension', '朔夜', 'audio/shuoye_shuangsheng_changeZhuanhuanji_true.mp3');
            player.storage[event.name + '_Skill'] = get.suit(result[0]);
            var storage = player.storage[event.name];
            player.addAdditionalSkill(event.name, lib.skill[event.name].derivation.slice(0).splice(storage ? 0 : 2, -2));
        },
        mod: {
            cardUsable: function (card, player, num) {
                if (!player.storage.shuoye_shuangsheng_Skill) return;
                var suit = player.storage.shuoye_shuangsheng_Skill;
                if (get.suit(card) == suit) return Infinity;
            },
            targetInRange: function (card, player) {
                if (!player.storage.shuoye_shuangsheng_Skill) return;
                var suit = player.storage.shuoye_shuangsheng_Skill;
                if (get.suit(card) == suit) return true;
            },
        },
        subSkill: {
            true: {
                enable: "chooseToUse",
                viewAsFilter: function (player) {
                    if (!player.storage.shuoye_shuangsheng_Skill) return false;
                    var suit = player.storage.shuoye_shuangsheng_Skill;
                    return player.countCards('hes', { suit: suit }) > 0;
                },
                filterCard: function (card) {
                    var player = _status.event.player;
                    var suit = player.storage.shuoye_shuangsheng_Skill;
                    return get.suit(card) == suit;
                },
                position: "hes",
                viewAs: {
                    name: "tao",
                    isCard: true,
                },
                prompt: "视为使用一张【桃】",
                check: function (card) {
                    return 10 - get.value(card);
                },
                sub: true,
                ai: {
                    basic: {
                        order: (card, player) => {
                            if (player.hasSkillTag('pretao')) return 9;
                            return 2;
                        },
                        useful: (card, i) => {
                            let player = _status.event.player;
                            if (!game.checkMod(card, player, 'unchanged', 'cardEnabled2', player)) return 2 / (1 + i);
                            let fs = game.filterPlayer(current => {
                                return get.attitude(player, current) > 0 && current.hp <= 2;
                            }), damaged = 0, needs = 0;
                            fs.forEach(f => {
                                if (f.hp > 3 || !lib.filter.cardSavable(card, player, f)) return;
                                if (f.hp > 1) damaged++;
                                else needs++;
                            });
                            if (needs && damaged) return 5 * needs + 3 * damaged;
                            if (needs + damaged > 1 || player.hasSkillTag('maixie')) return 8;
                            if (player.hp / player.maxHp < 0.7) return 7 + Math.abs(player.hp / player.maxHp - 0.5);
                            if (needs) return 7;
                            if (damaged) return Math.max(3, 7.8 - i);
                            return Math.max(1, 7.2 - i);
                        },
                        value: (card, player) => {
                            let fs = game.filterPlayer(current => {
                                return get.attitude(_status.event.player, current) > 0;
                            }), damaged = 0, needs = 0;
                            fs.forEach(f => {
                                if (!player.canUse('tao', f)) return;
                                if (f.hp <= 1) needs++;
                                else if (f.hp == 2) damaged++;
                            });
                            if (needs && damaged || player.hasSkillTag('maixie')) return Math.max(9, 5 * needs + 3 * damaged);
                            if (needs || damaged > 1) return 8;
                            if (damaged) return 7.5;
                            return Math.max(5, 9.2 - player.hp);
                        },
                    },
                    result: {
                        target: (player, target) => {
                            if (target.hasSkillTag('maixie')) return 3;
                            return 2;
                        },
                        "target_use": (player, target, card) => {
                            if (player === _status.currentPhase && player.hasSkillTag('nokeep', true, {
                                card: card,
                                target: target
                            }, true)) return 2;
                            let mode = get.mode(),
                                taos = player.getCards('hs', i => get.name(i) === 'tao' && lib.filter.cardEnabled(i, target, 'forceEnable'));
                            if (target.hp > 0) {
                                if (!player.isPhaseUsing()) return 0;
                                let min = 7.2 - 4 * player.hp / player.maxHp,
                                    nd = player.needsToDiscard(-player.countCards('h', i => !taos.includes(i) && get.value(i) < min)),
                                    keep = nd ? 0 : 2;
                                if (nd > 2 || taos.length > 1 && (nd > 1 || nd && player.hp < 1 + taos.length) || target.identity === 'zhu' && (nd || target.hp < 3) && (mode === 'identity' || mode === 'versus' || mode === 'chess') || !player.hasFriend()) return 2;
                                if (game.hasPlayer(current => {
                                    return player !== current && current.identity === 'zhu' && current.hp < 3 && (mode === 'identity' || mode === 'versus' || mode === 'chess') && get.attitude(player, current) > 0;
                                })) keep = 3;
                                else if (nd === 2 || player.hp < 2) return 2;
                                if (nd === 2 && player.hp <= 1) return 2;
                                if (keep === 3) return 0;
                                if (taos.length <= player.hp / 2) keep = 1;
                                if (keep && game.countPlayer(current => {
                                    if (player !== current && current.hp < 3 && player.hp > current.hp && get.attitude(player, current) > 2) {
                                        keep += player.hp - current.hp;
                                        return true;
                                    }
                                    return false;
                                })) {
                                    if (keep > 2) return 0;
                                }
                                return 2;
                            }
                            if (target.isZhu2() || target === game.boss) return 2;
                            if (player !== target) {
                                if (target.hp < 0 && taos.length + target.hp <= 0) return 0;
                                if (Math.abs(get.attitude(player, target)) < 1) return 0;
                            }
                            if (!player.getFriends().length) return 2;
                            let tri = _status.event.getTrigger(),
                                num = game.countPlayer(current => {
                                    if (get.attitude(current, target) > 0) return current.countCards('hs', i => get.name(i) === 'tao' && lib.filter.cardEnabled(i, target, 'forceEnable'));
                                }),
                                dis = 1,
                                t = _status.currentPhase || game.me;
                            while (t !== target) {
                                let att = get.attitude(player, t);
                                if (att < -2) dis++;
                                else if (att < 1) dis += 0.45;
                                t = t.next;
                            }
                            if (mode === 'identity') {
                                if (tri && tri.name === 'dying') {
                                    if (target.identity === 'fan') {
                                        if (!tri.source && player !== target || tri.source && tri.source !== target && player.getFriends().includes(tri.source.identity)) {
                                            if (num > dis || player === target && player.countCards('hs', { type: 'basic' }) > 1.6 * dis) return 2;
                                            return 0;
                                        }
                                    }
                                    else if (tri.source && tri.source.isZhu && (target.identity === 'zhong' || target.identity === 'mingzhong') &&
                                        (tri.source.countCards('he') > 2 || player === tri.source && player.hasCard((i) => i.name !== 'tao', 'he'))) return 2;
                                    //if(player!==target&&!target.isZhu&&target.countCards('hs')<dis) return 0;
                                }
                                if (player.identity === 'zhu') {
                                    if (player.hp <= 1 && player !== target && taos + player.countCards('hs', 'jiu') <= Math.min(dis, game.countPlayer(current => {
                                        return current.identity === 'fan';
                                    }))) return 0;
                                }
                            }
                            else if (mode === 'stone' && target.isMin() && player !== target && tri && tri.name === 'dying' && player.side === target.side && tri.source !== target.getEnemy()) return 0;
                            return 2;
                        },
                    },
                    tag: {
                        recover: 1,
                        save: 1,
                    },
                },
                "_priority": 0,
            },
            recover: {
                trigger: {
                    global: "recoverEnd",
                },
                filter: function (event, player) {
                    return player.storage.shuoye_shuangsheng && player.storage.shuoye_shuangsheng == true;
                },
                "prompt2": "当有角色回复1点体力后，你可以摸一张牌",
                content: function () {
                    'step 0'
                    event.count = trigger.num;
                    'step 1'
                    event.count--;
                    player.draw();
                    'step 2'
                    if (event.count > 0 && player.hasSkill('shuoye_shuangsheng')) {
                        player.chooseBool(get.prompt2('shuoye_shuangsheng')).set('frequentSkill', 'shuoye_shuangsheng');
                    }
                    'step 3'
                    if (result.bool) {
                        event.goto(1);
                    }
                },
                sub: true,
                "_priority": 0,
            },
            false: {
                trigger: {
                    source: "damageBegin1",
                },
                filter: function (event, player) {
                    if (!player.storage.shuoye_shuangsheng || player.storage.shuoye_shuangsheng == true) return false;
                    if (!player.storage.shuoye_shuangsheng_Skill) return;
                    var suit = player.storage.shuoye_shuangsheng_Skill;
                    return event.card && get.suit(event.card) == suit;
                },
                "prompt2": function (event, player) {
                    return '你可以令' + get.translation(event.card) + '造成的伤害翻倍';
                },
                content: function () {
                    trigger.num = trigger.num * 2;
                },
                sub: true,
                "_priority": 0,
            },
            damage: {
                trigger: {
                    global: "damageSource",
                },
                forced: true,
                locked: false,
                priority: 22,
                filter: function (event, player) {
                    return player.storage.shuoye_shuangsheng == false;
                },
                content: function () {
                    player.draw(trigger.num);
                },
                sub: true,
                "_priority": 2200,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_shuangsheng
//#noname-kit-begin skill:shuoye_yongheng
    "shuoye_yongheng": {
        trigger: {
            global: "useCardEnd",
        },
        forced: true,
        locked: false,
        filter: function (event, player) {
            if (!get.tag(event.card, 'damage')) return false;
            if (!event.targets || !event.targets.includes(player)) return false;
            return event.player.getHistory('useCard', function (evt) {
                return get.tag(event.card, 'damage');
            }).indexOf(event) == 0 && !player.hasHistory('damage', evt => evt.card == event.card);
        },
        logTarget: "player",
        content: function () {
            player.addTempSkill(event.name + '_cancel');
            player.markAuto(event.name + '_cancel', [trigger.player]);
        },
        subSkill: {
            cancel: {
                trigger: {
                    player: "damageBefore",
                },
                charlotte: true,
                firstDo: true,
                silent: true,
                onremove: true,
                filter: function (event, player) {
                    return event.source && player.getStorage('shuoye_yongheng_cancel').includes(event.source);
                },
                content: function () {
                    trigger.cancel();
                },
                sub: true,
                forced: true,
                popup: false,
                "_priority": 1,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_yongheng
//#noname-kit-begin skill:shuoye_laoyin
    "shuoye_laoyin": {
        derivation: ["shuoye_laoyin_zhongmo", "shuoye_laoyin_dansheng"],
        enable: "phaseUse",
        usable: 1,
        filterTarget: true,
        content: function () {
            'step 0'
            player.loseMaxHp();
            player.chooseControl(['终末', '诞生']).set('ai', function () {
                return Math.ceil(Math.random());
            });
            'step 1'
            target.addSkill(result.control == '终末' ? 'shuoye_laoyin_zhongmo' : 'shuoye_laoyin_dansheng');
            target.addMark(result.control == '终末' ? 'shuoye_laoyin_zhongmo' : 'shuoye_laoyin_dansheng');
        },
        ai: {
            order: 10,
            result: {
                target: function (player, target) {
                    if (player.maxHp < 2) return 0;
                    return -1;
                },
            },
        },
        group: "shuoye_laoyin_die",
        subSkill: {
            die: {
                trigger: {
                    global: "dieAfter",
                },
                forced: true,
                locked: false,
                priority: 12,
                filter: function (event, player) {
                    return lib.skill.shuoye_laoyin.derivation.some(i => event.player.countMark(i));
                },
                content: function () {
                    var num = 0;
                    lib.skill.shuoye_laoyin.derivation.forEach(i => num += trigger.player.countMark(i) ? 1 : 0);
                    player.gainMaxHp(num);
                },
                sub: true,
                "_priority": 1200,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_laoyin
//#noname-kit-begin skill:shuoye_laoyin_zhongmo
    "shuoye_laoyin_zhongmo": {
        trigger: {
            global: "useCard",
        },
        charlotte: true,
        firstDo: true,
        silent: true,
        filter: function (event, player) {
            return get.tag(event.card, 'damage');
        },
        content: function () {
            if (trigger.player == player) {
                trigger.directHit.addArray(game.filterPlayer());
            } else trigger.directHit.add(player);

        },
        ai: {
            "directHit_ai": true,
            skillTagFilter: function (player, tag, arg) {
                return player.countMark('shuoye_laoyin_zhongmo');
            },
        },
        mark: true,
        intro: {
            markcount: () => 0,
            content: "终末",
        },
        forced: true,
        popup: false,
        "_priority": 1,
    },
//#noname-kit-end skill:shuoye_laoyin_zhongmo
//#noname-kit-begin skill:shuoye_laoyin_dansheng
    "shuoye_laoyin_dansheng": {
        trigger: {
            source: "damageBefore",
            player: "damageBefore",
        },
        direct: true,
        filter: function (event, player) {
            if (!event.source || !event.source.isIn()) return false;
            return [event.source, event.player].some(p => p != player);
        },
        content: function () {
            'step 0'
            trigger.source.chooseBool('将此伤害改为令' + get.translation(trigger.player) + '回复体力').set('ai', () => {
                return get.attitude(_status.event.player, trigger.player) > 0;
            });
            'step 1'
            if (!result.bool) return;
            var sourcex = [trigger.source == player ? 'player' : 'source'];
            player.logSkill(event.name, sourcex);
            trigger.cancel();
            trigger.player.recover(trigger.num);
        },
        mark: true,
        intro: {
            markcount: () => 0,
            content: "诞生",
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_laoyin_dansheng
//#noname-kit-begin skill:shuoye_kuanghuan
    "shuoye_kuanghuan": {
        audio: "ext:朔夜/audio:2",
        trigger: {
            player: ["useCard", "respond"],
        },
        direct: true,
        filter: function (event, player) {
            if (player.hasSkill('shuoye_kuanghuan_used')) return false;
            if (!player.storage.shuoye_kuanghuan_mark) return false;
            return get.type(event.card) != player.storage.shuoye_kuanghuan_mark;
        },
        content: function () {
            'step 0'
            var num = player.storage[event.name];
            var list = ['选项一', '选项二'];
            player.chooseControl(list, 'cancel2').set('choiceList', [
                '摸一张牌，并令X加或减一',
                '摸X（' + get.cnNumber(num) + '）张牌，然后本回合不能再发动此技能',
            ]);
            'step 1'
            if (result.control == 'cancel2') {
                event.finish();
                return;
            }
            player.logSkill(event.name);
            if (result.control == '选项一') {
                player.draw();
                player.chooseControl('+1', '-1');
            } else {
                var num = player.storage[event.name];
                if (num > 0) player.draw(num);
                player.addTempSkill(event.name + '_used');
                event.finish();
            }
            'step 2'
            player.storage[event.name] += (result.control == '+1' ? 1 : -1);
            if (player.storage[event.name] < 0) player.storage[event.name] = 0;
        },
        init: (player, skill) => {
            if (!player.storage[skill]) player.storage[skill] = 0;
            player.addSkill('shuoye_kuanghuan_mark');
        },
        onremove: (player, skill) => {
            player.removeSkill('shuoye_kuanghuan_mark');
        },
        subSkill: {
            used: {
                charlotte: true,
                mark: true,
                onremove: true,
                intro: {
                    markcount: function (storage) {
                        return '失效';
                    },
                },
                sub: true,
                "_priority": 0,
            },
            mark: {
                trigger: {
                    player: ["useCardAfter", "respondAfter"],
                },
                charlotte: true,
                silent: true,
                content: function () {
                    player.storage.shuoye_kuanghuan_mark = get.type2(trigger.card);
                },
                mark: true,
                intro: {
                    markcount: function (card, player) {
                        return get.translation(card);
                    },
                    content: "$",
                },
                sub: true,
                forced: true,
                popup: false,
                "_priority": 1,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_kuanghuan
//#noname-kit-begin skill:shuoye_lianjin
    "shuoye_lianjin": {
        audio: "ext:朔夜/audio:2",
        enable: ["chooseToUse", "chooseToRespond"],
        filter: function (event, player) {
            if (!player.countCards('hse')) return false;
            if (!player.storage.shuoye_kuanghuan) return false;
            for (var i of lib.inpile) {
                var type = get.type2(i);
                if (!['basic', 'trick'].includes(type)) continue;
                if (player.getStorage('shuoye_lianjin_used').includes(i)) continue;
                if (get.cardNameLength(i) != player.storage.shuoye_kuanghuan) continue;
                if (event.filterCard({ name: i }, player, event)) return true;
            }
            return false;
        },
        chooseButton: {
            dialog: function (event, player) {
                var list = [];
                for (var i = 0; i < lib.inpile.length; i++) {
                    var name = lib.inpile[i];
                    if (get.type2(name) == 'trick' && event.filterCard({ name: name }, player, event)) list.push(['锦囊', '', name]);
                    else if (get.type(name) == 'basic' && event.filterCard({ name: name }, player, event)) list.push(['基本', '', name]);
                }
                return ui.create.dialog('炼金', [list, 'vcard']);
            },
            filter: function (button, player) {
                if (player.getStorage('shuoye_lianjin_used').includes(button.link[2])) return false;
                if (get.cardNameLength(button.link[2]) != player.storage.shuoye_kuanghuan) return false;
                return _status.event.getParent().filterCard({ name: button.link[2] }, player, _status.event.getParent());
            },
            check: function (button) {
                if (_status.event.getParent().type != 'phase') return 1;
                var player = _status.event.player;
                if (['wugu', 'zhulu_card', 'yiyi', 'lulitongxin', 'lianjunshengyan', 'diaohulishan'].contains(button.link[2])) return 0;
                return player.getUseValue({
                    name: button.link[2],
                    nature: button.link[3],
                });
            },
            backup: function (links, player) {
                return {
                    audio: 'shuoye_lianjin',
                    filterCard: true,
                    popname: true,
                    check: function (card) {
                        return 8 - get.value(card);
                    },
                    position: 'hse',
                    viewAs: { name: links[0][2], nature: links[0][3] },
                    onuse: function () {
                        _status.event.addCount = false;
                    },
                    precontent: function () {
                        player.addTempSkill('shuoye_lianjin_used');
                        player.markAuto('shuoye_lianjin_used', [event.result.card.name])
                    },
                }
            },
            prompt: function (links, player) {
                return '将一张牌当做' + (get.translation(links[0][3]) || '') + get.translation(links[0][2]) + '使用';
            },
        },
        hiddenCard: function (player, name) {
            if (!lib.inpile.contains(name)) return false;
            if (!player.storage.shuoye_kuanghuan) return false;
            var type = get.type2(name);
            return (type == 'basic' || type == 'trick') && player.countCards('she') > 0 && get.cardNameLength(name) == player.storage.shuoye_kuanghuan;
        },
        ai: {
            combo: "shuoye_kuanghuan",
            respondSha: true,
            respondShan: true,
            skillTagFilter: function (player) {
                if (!player.countCards('hse') || !player.storage.shuoye_kuanghuan) return false;
            },
            order: 1,
            result: {
                player: function (player) {
                    if (_status.event.dying) return get.attitude(player, _status.event.dying);
                    return 1;
                },
            },
        },
        subSkill: {
            backup: {
                sub: true,
                "_priority": 0,
            },
            used: {
                charlotte: true,
                onremove: true,
                mark: true,
                intro: {
                    content: "已使用过的牌名：$",
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_lianjin
//#noname-kit-begin skill:shuoye_zhuyuan
    "shuoye_zhuyuan": {
        global: "shuoye_zhuyuan_global",
        marktext: "愿",
        intro: {
            content: "expansion",
            markcount: "expansion",
        },
        onremove: function (player, skill) {
            var cards = player.getExpansions(skill);
            if (cards.length) player.loseToDiscardpile(cards);
        },
        subSkill: {
            global: {
                trigger: {
                    player: "phaseDrawBegin2",
                },
                filter(event, player) {
                    if (!game.hasPlayer(current => current.hasSkill('shuoye_zhuyuan'))) return false;
                    return !event.numFixed;
                },
                prompt2: "你可以多摸三张牌，然后将两张牌置于武将牌上，称为【愿】",
                async content(event, trigger, player) {
                    trigger.num += 3;
                    trigger._shuoye_zhuyuan = true;
                    player.when('gainAfter')
                        .filter((event, player) => event.getParent(2)._shuoye_zhuyuan && player.countCards('he') >= 2)
                        .then(() => {
                            if (player.countCards('he') >= 2) player.chooseCard('he', 2, true, '将两张牌置于武将牌上，称为“愿”');
                            else event.finish();
                        })
                        .then(() => {
                            player.addToExpansion(result.cards, 'giveAuto').gaintag.add('shuoye_zhuyuan');
                        })
                },
                sub: true,
                "_priority": 0,
            },
        },
        "_priority": 0,
    },
//#noname-kit-end skill:shuoye_zhuyuan
//#noname-kit-begin skill:shuoye_eyao
    "shuoye_eyao": {
        enable: ["chooseToUse", "chooseToRespond"],
        hiddenCard: function (player, name) {
            const targets = game.filterPlayer(target => target.getExpansions('shuoye_zhuyuan').length);
            const cards = targets.map(target => target.getExpansions('shuoye_zhuyuan')).flat();;
            const list = cards.map(card => card.name);
            if (list.includes(name) && _status.currentPhase != player) return true;
        },
        filter: function (event, player) {
            if (_status.currentPhase == player || event.responded || event.shuoye_eyao) return false;
            const targets = game.filterPlayer(target => target.getExpansions('shuoye_zhuyuan').length);
            const cards = targets.map(target => target.getExpansions('shuoye_zhuyuan')).flat();
            const list = cards.map(card => card.name);
            for (var i of lib.inpile) {
                if (list.includes(i) && event.filterCard(get.autoViewAs({ name: i }, 'unsure'), player, event)) return true;
            }
            return false;
        },
        delay: false,
        async content(event, trigger, player) {
            var evt = event.getParent(2);
            evt.set('shuoye_eyao', true);
            const targets = game.filterPlayer(target => target.getExpansions('shuoye_zhuyuan').length);
            var cards = targets.map(target => target.getExpansions('shuoye_zhuyuan')).flat()
                .filter(function (card) {
                    return evt.filterCard(card, evt.player, evt);
                });
            var aozhan = player.hasSkill('aozhan');
            const { result } = await player.chooseButton(['恶曜：选择要使用或打出的牌', cards])
                .set('filterButton', function (button) {
                    return _status.event.cards.includes(button.link);
                })
                .set('cards', cards)
                .set('ai', function (button) {
                    var evt = _status.event.getParent(3), player = _status.event.player;
                    if (evt.type == 'phase' && !player.hasValueTarget(button.link, null, true)) return 0;
                    if (evt && evt.ai) {
                        var tmp = _status.event;
                        _status.event = evt;
                        var result = (evt.ai || event.ai1)(button.link, _status.event.player, evt);
                        _status.event = tmp;
                        return result;
                    }
                    return 1;
                });
            if (result.bool && result.links && result.links.length) {
                var card = result.links[0];
                var name = card.name;
                game.broadcastAll(function (result, name) {
                    lib.skill.shuoye_eyao_backup.viewAs = { name: name, cards: [result], isCard: true };
                }, card, name);
                evt.set('_backupevent', 'shuoye_eyao_backup');
                evt.set('openskilldialog', ('请选择' + get.translation(card) + '的目标'))
                evt.backup('shuoye_eyao_backup');
            }
            evt.goto(0);
        },
        ai: {
            effect: {
                target: function (card, player, target, effect) {
                    if (get.tag(card, 'respondShan')) return 0.7;
                    if (get.tag(card, 'respondSha')) return 0.7;
                },
            },
            order: 12,
            respondShan: true,
            respondSha: true,
            result: {
                player: function (player) {
                    if (_status.event.dying) return get.attitude(player, _status.event.dying);
                    return 1;
                },
            },
        },
        marktext: "曜",
        intro: {
            content: "mark",
        },
        group: "shuoye_eyao_useCard",
        subSkill: {
            useCard: {
                trigger: {
                    global: "useCard",
                },
                direct: true,
                locked: true,
                filter(event, player) {
                    return event.player.getExpansions('shuoye_zhuyuan').length;
                },
                async content(event, trigger, player) {
                    const cards = trigger.player.getExpansions('shuoye_zhuyuan').filter(card => player.hasUseTarget(card));
                    if (cards.length) {
                        const { result } = await player.chooseButton(['选择要使用的牌', cards]).set('ai', function (button) {
                            return get.order(button.link);
                        });
                        if (result.bool) {
                            const card = result.links[0];
                            player.logSkill(event.name);
                            const { result: { bool } } = await player.chooseUseTarget(card, true, false);
                            if (player.hasHistory('sourceDamage', evt => evt.getParent(4) == event)) {
                                const count = player.getHistory('sourceDamage', evt => evt.getParent(4) == event).map(evt => evt.num).reduce((p, c) => p + c, 0);
                                await player.addMark('shuoye_eyao', count);
                                if (player.countMark('shuoye_eyao') >= player.maxHp) {
                                    player.removeMark('shuoye_eyao', player.countMark('shuoye_eyao'));
                                    await player.gainMaxHp();
                                    player.recover();
                                }
                            }
                        }
                    }
                },
                sub: true,
                "_priority": 0,
            },
            backup: {
                sourceSkill: "shuoye_eyao",
                precontent: function () {
                    delete event.result.skill;
                    var name = event.result.card.name, cards = event.result.card.cards.slice(0);
                    event.result.cards = cards;
                    var rcard = cards[0], card;
                    if (rcard.name == name) card = get.autoViewAs(rcard);
                    else card = get.autoViewAs({ name, isCard: true });
                    event.result.card = card;
                },
                filterCard: function () { return false },
                selectCard: -1,
            },
        },
    },
//#noname-kit-end skill:shuoye_eyao
//#noname-kit-begin skill:shuoye_jingtu
    shuoye_jingtu: {
        dieContentx() {
            'step 0'
            event.forceDie = true;
            if (player.isIn() && (!_status.shuoye_jingtu_return || !_status.shuoye_jingtu_return[player.playerid])) {
                event.reserveOut = true;
                game.log(player, '进入了修整状态');
                game.log(player, '移出了游戏');
                //game.addGlobalSkill('shuoye_jingtu_return');
                if (!_status.shuoye_jingtu_return) _status.shuoye_jingtu_return = {};
                _status.shuoye_jingtu_return[player.playerid] = 1;
            }
            else event.finish();
            if (!game.countPlayer()) game.over();
            else if (player.hp != 0) {
                player.changeHp(0 - player.hp, false).forceDie = true;
            }
            game.broadcastAll(function (player) {
                if (player.isLinked()) {
                    if (get.is.linked2(player)) {
                        player.classList.toggle('linked2');
                    }
                    else {
                        player.classList.toggle('linked');
                    }
                }
                if (player.isTurnedOver()) {
                    player.classList.toggle('turnedover');
                }
            }, player);
            game.addVideo('link', player, player.isLinked());
            game.addVideo('turnOver', player, player.classList.contains('turnedover'));
            'step 1'
            event.trigger('die');
            'step 2'
            if (event.reserveOut) {
                if (!game.reserveDead) {
                    for (var mark in player.marks) {
                        if (['shuoye_zhuyuan', 'shuoye_eyao'].includes(mark)) continue;
                        player.unmarkSkill(mark);
                    }
                    var count = 1;
                    var list = Array.from(player.node.marks.childNodes);
                    if (list.some(i => i.name == 'mbdanggu')) count++;
                    while (player.node.marks.childNodes.length > count) {
                        var node = player.node.marks.lastChild;
                        if (node.name == 'mbdanggu') {
                            node = node.previousSibling;
                        }
                        node.remove();
                    }
                    game.broadcast(function (player, count) {
                        while (player.node.marks.childNodes.length > count) {
                            var node = player.node.marks.lastChild;
                            if (node.name == 'mbdanggu') {
                                node = node.previousSibling;
                            }
                            node.remove();
                        }
                    }, player, count);
                }
                for (var i in player.tempSkills) {
                    player.removeSkill(i);
                }
                var skills = player.getSkills();
                for (var i = 0; i < skills.length; i++) {
                    if (lib.skill[skills[i]].temp) {
                        player.removeSkill(skills[i]);
                    }
                }
                event.cards = player.getCards('hejsx');
                if (event.cards.length) {
                    player.discard(event.cards).forceDie = true;
                }
            }
            'step 3'
            if (event.reserveOut) {
                game.broadcastAll(function (player, list) {
                    player.classList.add('out');
                    if (list.includes(player.name1) || player.name1 == 'shichangshi') {
                        player.smoothAvatar(false);
                        player.node.avatar.setBackground(player.name1 + '_dead', 'character');
                    }
                    if (list.includes(player.name2) || player.name2 == 'shichangshi') {
                        player.smoothAvatar(true);
                        player.node.avatar2.setBackground(player.name2 + '_dead', 'character');
                    }
                }, player, lib.skill.mbdanggu.changshi.map(i => i[0]));
            }
        },
        group: ['shuoye_jingtu_begin', 'shuoye_jingtu_end', 'shuoye_jingtu_die', 'shuoye_jingtu_return'],
        subSkill: {
            begin: {
                trigger: {
                    player: 'phaseBegin',
                },
                popup: false,
                locked: true,
                filter(event, player) {
                    return game.hasPlayer(current => current.getExpansions('shuoye_zhuyuan').length);
                },
                async cost(event, trigger, player) {
                    event.result = await player.chooseTarget(function (card, player, target) {
                        return target.getExpansions('shuoye_zhuyuan').length;
                    })
                        .set('selectTarget', [1, game.countPlayer()])
                        .set('prompt', get.prompt('shuoye_jingtu'))
                        .set('prompt2', `你的回合开始时，你可以将任意名角色武将牌上的【愿】置入你的手牌区，然后你减少等量的体力上限`)
                        .set('ai', function (target) {
                            if (ui.selected.targets.length >= player.maxHp - 1) return 0;
                            return 1;
                        }).forResult();
                },
                async content(event, trigger, player) {
                    player.logSkill(event.name, event.targets);
                    for (const target of event.targets) {
                        await player.gain(target.getExpansions('shuoye_zhuyuan'), 'gain2');
                    }
                    player.loseMaxHp(event.targets.length);
                },
            },
            end: {
                trigger: {
                    player: 'phaseEnd',
                },
                locked: true,
                filter(event, player) {
                    return player.maxHp > 3;
                },
                prompt2(event, player) {
                    return `你的回合结束时，若你的体力上限大于3，你可以减少一点体力上限，然后进入一轮修整状态`;
                },
                async content(event, trigger, player) {
                    player.loseMaxHp();
                    player.die().shuoye_jingtu_end = true;
                },
            },
            die: {
                trigger: {
                    player: "dieBefore",
                },
                forced: true,
                direct: true,
                priority: 15,
                filter(event, player) {
                    if (!event.shuoye_jingtu_end) return false;
                    return event.getParent().name != 'giveup' && player.maxHp > 0;
                },
                async content(event, trigger, player) {
                    if (_status.mbmowang_return && _status.mbmowang_return[player.playerid]) {
                        trigger.cancel();
                    }
                    else {
                        player.logSkill(event.name);
                        game.broadcastAll(function () {
                            if (lib.config.background_speak) game.playAudio('die', 'shichangshiRest');
                        });
                        trigger.setContent(lib.skill.mbmowang.dieContent);
                        trigger.includeOut = true;
                    }
                },
            },
            return: {
                trigger: {
                    global: 'roundStart',
                },
                forced: true,
                charlotte: true,
                silent: true,
                forceDie: true,
                forceOut: true,
                filter(event, player) {
                    return !event._mbmowang_return && player.isOut() && _status.mbmowang_return[player.playerid];
                },
                async content(event, trigger, player) {
                    trigger._mbmowang_return = true;
                    game.broadcastAll(function (player) {
                        player.classList.remove('out');
                    }, player);
                    game.log(player, '移回了游戏');
                    delete _status.mbmowang_return[player.playerid];
                    await player.recoverTo(player.maxHp);
                    event.trigger('restEnd');
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_jingtu
//#noname-kit-begin skill:shuoye_yimeng
    "shuoye_yimeng": {
        trigger: {
            player: "phaseUseBegin",
        },
        filter(event, player) {
            const num = player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_yimeng').length + 1;
            const numx = player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_jingtu').length;
            var targets = game.filterPlayer(target => target != player);
            return targets.every(target => player.getAllHistory('useSkill', evt => evt.skill == 'shuoye_jingtu' && evt.targets && evt.targets.includes(target)).length >= num);
        },
        async content(event, trigger, player) {
            const targets = game.filterPlayer(target => target != player);
            while (targets.length) {
                const target = targets.shift();
                if (target.isIn()) target.damage('thunder');
                if (target.countDiscardableCards(player, 'h')) {
                    const { result } = await player.discardPlayerCard(target, 'h', 3, true);
                }
                target.discard(target.getCards('e')).set('discarder', player);
            }
            player.addTempSkill('shuoye_yimeng_effect', { player: 'phaseUseBefore' });
        },
        subSkill: {
            effect: {
                trigger: {
                    source: "damageBegin1",
                    player: "useCard",
                },
                forced: true,
                popup: false,
                charlotte: true,
                filter(event, player, name) {
                    if (name == 'useCard') return true;
                    return !event.hasNature('thunder');
                },
                async content(event, trigger, player) {
                    if (event.triggername == 'damageBegin1') game.setNature(trigger, 'thunder');
                    else trigger.directHit.addArray(game.players);
                },
                mark: true,
                intro: {
                    content: "你造成的伤害都视为雷电伤害且使用牌不可被响应",
                },
                sub: true,
                "_priority": 0,
            },
        },
    },
//#noname-kit-end skill:shuoye_yimeng

//#noname-kit-begin skill:shuoye_zhongzhuang
    shuoye_zhongzhuang: {
        locked: true,
        getLimit: 7,
        group: ['shuoye_zhongzhuang_trick', 'shuoye_zhongzhuang_basic'],
        subSkill: {
            trick: {
                trigger: {
                    player: "gainAfter",
                    global: "loseAsyncAfter",
                },
                forced: true,
                filter(event, player) {
                    if (!player.countCards('he', function (card) {
                        return lib.filter.cardDiscardable(card, player, 'shuoye_zhongzhuang')
                    })) return false;
                    return event.getg(player).some(card => get.type2(card, false) == 'trick');
                },
                getIndex(event, player) {
                    if (!player.countCards('he', function (card) {
                        return lib.filter.cardDiscardable(card, player, 'shuoye_zhongzhuang')
                    })) return false;
                    return event.getg(player).filter(card => get.type2(card, false) == 'trick').length;
                },
                async content(event, trigger, player) {
                    if (
                        player.countCards('he', function (card) {
                            return lib.filter.cardDiscardable(card, player, 'shuoye_zhongzhuang')
                        })
                    ) {
                        await player.chooseToDiscard('hes', true)
                            .set('ai', card => {
                                let player = get.player(),
                                    val = 6;
                                if (player.hasSkill('shuoye_zhongzhuang') && get.type(card) == 'basic') val += 3;
                                return val - get.value(card);
                            });
                    }
                },
            },
            basic: {
                trigger: {
                    player: "loseAfter",
                    global: ["gainAfter", "equipAfter", "addJudgeAfter", "loseAsyncAfter", "addToExpansionAfter"],
                },
                forced: true,
                filter(event, player) {
                    const evt = event.getl(player);
                    if (!evt.cards2.length) return false;
                    return evt.cards2.some(card => get.type(card, false) == 'basic');
                },
                getIndex(event, player) {
                    const evt = event.getl(player);
                    if (!evt.cards2.length) return false;
                    return evt.cards2.filter(card => get.type(card, false) == 'basic').length;
                },
                async content(event, trigger, player) {
                    player.draw();
                    if (player.getHistory('useSkill', evt => evt.skill == event.name).length <= 3 &&
                        player.countMark('charge') < get.info('shuoye_zhongzhuang').getLimit) {
                        player.addMark('charge');
                    }
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_zhongzhuang
//#noname-kit-begin skill:shuoye_zhongmu
    shuoye_zhongmu: {
        enable: 'phaseUse',
        usable: 1,
        locked: false,
        changeSkill: true,
        filter(event, player, name) {
            if (player.countMark('charge') < 7) return false;
            if (!player.countCards('hes', function (card) {
                return get.type(card) != 'basic';
            })) return false;
            return get.inpileVCardList(info => {
                const name = info[2], type = get.type(name), infox = get.info({ name: name });
                return type == 'basic';
            }).filter(card => event.filterCard({ name: card[2], nature: card[3] }, player, event)).length;
        },
        async content(event, trigger, player) {
            player.removeMark('charge', player.countMark('charge'));
            for (var i = 0; i < 7; i++) {
                const list = get.inpileVCardList(info => {
                    const name = info[2], type = get.type(name), infox = get.info({ name: name });
                    return type == 'basic';
                }).filter(card => player.hasUseTarget({
                    name: card[2],
                    nature: card[3],
                    storage: {
                        shuoye_zhongmu: true,
                    },
                }, false, false));
                if (!list.length) break;
                const { result: { bool, links } } = await player.chooseButton(['你可以将一张非基本牌当做任意一张基本牌使用（无距离和次数限制），然后你可以重复此流程', [list, 'vcard']])
                    .set('filterButton', button => {
                        const player = get.player();
                        return player.hasUseTarget({
                            name: button.link[2],
                            nature: button.link[3],
                            storage: {
                                shuoye_zhongmu: true,
                            },
                        })
                    })
                    .set('ai', button => {
                        const player = get.player();
                        return player.getUseValue({
                            name: button.link[2],
                            nature: button.link[3],
                            storage: {
                                shuoye_zhongmu: true,
                            }
                        })
                    })
                if (bool) {
                    const card = {
                        name: links[0][2],
                        nature: links[0][3],
                        storage: {
                            shuoye_zhongmu: true,
                        },
                    };
                    game.broadcastAll(function (card) {
                        lib.skill.shuoye_zhongmu_backup.viewAs = card;
                        lib.skill.shuoye_zhongmu_backup.prompt = ('选择' + get.translation(name) + '的目标');
                    }, card);
                    var next = player.chooseToUse();
                    next.set("openskilldialog", `###${get.prompt("shuoye_zhongmu")}###你可以将一张非基本牌当做${get.translation(card)}使用，然后你可以重复此流程。`);
                    next.set("norestore", true);
                    next.set("_backupevent", "shuoye_zhongmu_backup");
                    next.set("addCount", false);
                    next.set("logSkill", "shuoye_zhongmu");
                    next.set("custom", {
                        add: {},
                        replace: { window: function () { } },
                    });
                    next.backup("shuoye_zhongmu_backup");
                    const { result } = await next;
                    if (!result.bool) break;
                }
                else break;
            }
        },
        mod: {
            cardUsable(card, player) {
                if (typeof card == "object") {
                    if (card.storage.shuoye_zhongmu) return Infinity;
                }
            },
            targetInRange(card, player, target) {
                if (card.storage.shuoye_zhongmu) return true;
            },
        },
        ai: {
            order() {
                return 3.1;
            },
            result: {
                player(player) {
                    return 1;
                },
            },
        },
        subSkill: {
            backup: {
                filterCard(card) {
                    return get.itemtype(card) == "card" && get.type(card) != 'basic';
                },
                selectCard: 1,
                position: "hes",
                "ai1"(card) {
                    var player = get.player();
                    var maxVal = 6;
                    return maxVal - get.value(card);
                },
                log: false,
                async precontent(event, trigger, player) {
                    event.getParent().addCount = false;
                }
            },
        },
    },
//#noname-kit-end skill:shuoye_zhongmu
//#noname-kit-begin skill:shuoye_lengjing
    shuoye_lengjing: {
        trigger: {
            player: "phaseJieshuBegin",
        },
        popup: false,
        getLimit: 7,
        async cost(event, trigger, player) {
            event.result = await player.chooseToDiscard(`结束阶段，你可以弃置任意张牌并增加等于半数的护甲（向下取整）。`, 'hes')
                .set('selectCard', [1, Infinity])
                .set('ai', card => {
                    const player = get.player();
                    if (player.hujia > 5) return 0;
                    var val = 6;
                    if (player.hasSkill('shuoye_zhongzhuang') && get.type(card) == 'basic') val += 3;
                    return val - get.value(card);
                })
                .set('chooseonly', true)
                .forResult();
        },
        async content(event, trigger, player) {
            player.logSkill(event.name);
            const num = Math.floor(event.cards.length / 2);
            await player.discard(event.cards);
            if (num > 0) player.changeHujia(num);
        },
        mod: {
            cardUsable(card, player, num) {
                if (!player.isPhaseUsing()) return;
                if (card.name == "sha") return num + 1;
            },
        },
    },
//#noname-kit-end skill:shuoye_lengjing
//#noname-kit-begin skill:shuoye_fengji
    shuoye_fengji: {
        trigger: {
            global: 'roundStart',
        },
        zhuSkill: true,
        filter(event, player) {
            if (!player.hasZhuSkill('shuoye_fengji')) return false;
            if (game.roundNumber <= 1) return false;
            return game.hasPlayer(target => {
                return target.getRoundHistory('sourceDamage', evt => evt, 1).length;
            });
        },
        logTarget(event, player) {
            return game.filterPlayer(target => {
                return target.getRoundHistory('sourceDamage', evt => evt, 1).length;
            });
        },
        async content(event, trigger, player) {
            for (const target of event.targets) {
                const { result: { bool, cards } } = await target
                    .chooseToDiscard("he", "弃置一张牌，或令" + get.translation(player) + "摸一张牌")
                    .set("goon", get.attitude(target, player) < 0)
                    .set("ai", function (card) {
                        if (!_status.event.goon) return -get.value(card);
                        return 6 - get.value(card);
                    });
                if (!bool) await player.draw();
            }
        },
    },
//#noname-kit-end skill:shuoye_fengji


//#noname-kit-begin skill:shuoye_sixiang
    shuoye_sixiang: {
        trigger: {
            global: "damageBegin",
        },
        forced: true,
        locked: false,
        filter(event, player) {
            return event.player != player && event.getParent().name != 'shuoye_fandu';
        },
        async content(event, trigger, player) {
            await player.draw();
            trigger.player.addMark('shuoye_sixiang_mark');
        },
        group: "shuoye_sixiang_use",
        subSkill: {
            use: {
                trigger: {
                    global: "phaseBegin",
                },
                direct: true,
                filter(event, player) {
                    return player.inRange(event.player) && player.hasCard(function (card) {
                        return player.hasUseTarget(card)
                    }, 'h');
                },
                async content(event, trigger, player) {
                    player.chooseToUse({
                        prompt: get.prompt(event.name),
                        prompt2: "是否使用一张牌？",
                        filterCard(card, player) {
                            if (get.itemtype(card) != "card") return false;
                            return lib.filter.filterCard.apply(this, arguments);
                        },
                        ai1(card) {
                            return get.player().getUseValue(card);
                        },
                    });
                },
            },
            mark: {
                mark: true,
                marktext: '赤',
                intro: {
                    content: `mark`,
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_sixiang
//#noname-kit-begin skill:shuoye_santu
    shuoye_santu: {
        audio: "ext:朔夜/audio:1",
        trigger: {
            player: "phaseUseBegin",
        },
        async content(event, trigger, player) {
            player.changeSkin({ characterName: "shuoye_huangquan" }, "shuoye_huangquan_shadow");
            const num = player.getAllHistory('useSkill', evt => evt.skill == event.name).length
            await player.loseHp();
            await player.gainMaxHp();
            player.addSkill('shuoye_santu_effect', { player: ['phaseUseAfter', 'phaseUseSkipped'] });
        },
        subSkill: {
            effect: {
                trigger: {
                    player: "useCard",
                },
                forced: true,
                charlotte: true,
                filter(event, player) {
                    return event.card.name == 'sha';
                },
                async content(event, trigger, player) {
                    if (!game.hasNature(trigger.card)) {
                        trigger.baseDamage++;
                    } else if (game.hasNature(trigger.card, 'thunder')) {
                        const targets = trigger.targets;
                        for (const target of targets) {
                            target.addTempSkill('fengyin');
                        }
                    }
                    else if (game.hasNature(trigger.card, 'fire')) {
                        trigger.directHit.addArray(game.filterPlayer());
                        trigger.card._shuoye_santu = true;
                        player.addTempSkill('shuoye_santu_loseHp');
                    }
                },
            },
            loseHp: {
                trigger: {
                    source: 'damageBefore',
                },
                forced: true,
                popup: false,
                charlotte: true,
                filter(event, player) {
                    return event.card && event.card._shuoye_santu;
                },
                async content(eventt, trigger, player) {
                    trigger.cancel();
                    trigger.player.loseHp(trigger.num);
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_santu
//#noname-kit-begin skill:shuoye_yuzhan
    shuoye_yuzhan: {
        mod: {
            cardUsable(card, player, num) {
                if (card.storage && card.storage.shuoye_yuzhan) return Infinity;
            },
        },
        enable: "phaseUse",
        usable: 2,
        filter(event, player) {
            var hs = player.getCards("h");
            if (!hs.length) return false;
            return get.inpileVCardList(info => {
                const name = info[2];
                if (name != "sha") return false;
                return get.type(name) == "basic";
            })
                .some(card => event.filterCard({
                    name: card[2],
                    nature: card[3],
                    storage: {
                        shuoye_yuzhan: true,
                    },
                    cards: hs
                }, player, event));
        },
        chooseButton: {
            dialog(event, player) {
                const hs = player.getCards("h");
                const list = get.inpileVCardList(info => {
                    const name = info[2];
                    if (name != "sha") return false;
                    return get.type(name) == "basic";
                })
                    .filter(card => event.filterCard({
                        name: card[2],
                        nature: card[3],
                        storage: {
                            shuoye_yuzhan: true,
                        },
                        cards: hs
                    }, player, event));
                return ui.create.dialog("雨斩", [list, "vcard"]);
            },
            filter(button, player) {
                const hs = player.getCards("h");
                return _status.event.getParent().filterCard({
                    name: button.link[2],
                    nature: button.link[3],
                    storage: {
                        shuoye_yuzhan: true,
                    },
                    cards: hs
                }, player, _status.event.getParent());
            },
            check(button) {
                if (_status.event.getParent().type != "phase") return 1;
                const player = get.event("player"),
                    value = player.getUseValue({ name: button.link[2], nature: button.link[3] });
                return value;
            },
            backup(links, player) {
                return {
                    viewAs: {
                        name: links[0][2],
                        nature: links[0][3],
                        storage: {
                            shuoye_yuzhan: true,
                        }
                    },
                    filterCard: true,
                    selectCard: -1,
                    check(card) {
                        return 7.5 - get.value(card);
                    },
                    selectTarget: -1,
                    log: false,
                    async precontent(event, trigger, player) {
                        player.logSkill("shuoye_yuzhan");
                        event.getParent().addCount = false;
                    },
                    ai: {
                        directHit_ai: true,
                        skillTagFilter(player, tag, arg) {
                            if (get.event("skill") != "shuoye_yuzhan_backup") return false;
                            return arg && arg.card && arg.card.name == "sha";
                        },
                    },
                };
            },
            prompt(links, player) {
                return "将所有手牌牌当作" + (get.translation(links[0][3]) || "") + "【" + get.translation(links[0][2]) + "】使用";
            },
        },
        hiddenCard(player, name) {
            return name == "sha" && player.countCards("hes");
        },
        ai: {
            fireAttack: true,
            respondSha: true,
            skillTagFilter(player, tag, arg) {
                if (arg == "respond") return false;
            },
            order(item, player) {
                if (player && _status.event.type == "phase" && player.hasValueTarget({ name: "sha" }, true, true)) {
                    let max = 0,
                        names = get.inpileVCardList(info => {
                            const name = info[2];
                            if (name != "sha") return false;
                            return get.type(name) == "basic";
                        });
                    names = names.map(namex => {
                        return { name: namex[2], nature: namex[3] };
                    });
                    names.forEach(card => {
                        if (player.getUseValue(card) > 0) {
                            let temp = get.order(card);
                            if (temp > max) max = temp;
                        }
                    });
                    if (max > 0) max += 15;
                    return max;
                }
                return 0.5;
            },
            result: {
                player(player) {
                    return 1;
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_yuzhan
//#noname-kit-begin skill:shuoye_fandu
    shuoye_fandu: {
        audio: "ext:朔夜/audio:1",
        trigger: {
            player: 'phaseUseEnd',
        },
        filter(event, player) {
            return game.hasPlayer(target => target.countMark('shuoye_sixiang_mark'));
        },
        async content(event, trigger, player) {
            player.changeSkin({ characterName: "shuoye_huangquan" }, "shuoye_huangquan_shadow");
            player.removeSkill('shuoye_santu_effect');
            await player.loseMaxHp();
            const targets = game.filterPlayer(target => target.countMark('shuoye_sixiang_mark'));
            for (const target of targets) {
                const num = target.countMark('shuoye_sixiang_mark');
                await target.damage(num, 'thunder');
                target.removeMark('shuoye_sixiang_mark', num);
                target.unmarkSkill('shuoye_sixiang_mark');
            }
        },
    },
//#noname-kit-end skill:shuoye_fandu
    //飞鸟马时
//#noname-kit-begin skill:shuoye_jijia
    shuoye_jijia: {
        audio: "ext:朔夜/audio:2",
        enable: "phaseUse",
        filter(event, player) {
            const history1 = player.getAllHistory("useSkill", evt => evt.skill == "shuoye_jijia").length,
                history2 = 1 + player.getAllHistory("useSkill", evt => evt.skill == "shuoye_zhongzhan").length;
            if (history1 >= history2) return false;
            return !game.hasPlayer(target => target.getEquips("shuoye_abishu").length);
        },
        filterTarget: true,
        async content(event, trigger, player) {
            const target = event.targets[0];
            const card = get.cardPile("shuoye_abishu", "field") || game.createCard2("shuoye_abishu", "spade", 2);
            if (!card.storage) card.storage = {};
            if (typeof card.storage.shuoye_abishu != "number") {
                card.storage.shuoye_abishu = 5;
            }
            game.broadcast(
                (card, storage) => {
                    card.storage = storage;
                },
                card,
                card.storage
            );
            if (card) {
                await target.gain();
                await game.delayx();
                await target.equip(card);
            }
        },
        ai: {
            order: 1,
            result: {
                target(player, target) {
                    return get.attitude(player, target);
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_jijia
//#noname-kit-begin skill:shuoye_zhongzhan
    shuoye_zhongzhan: {
        audio: "ext:朔夜/audio:2",
        trigger: {
            source: "dieAfter",
        },
        forced: true,
        locked: false,
        persevereSkill: true,
        async content(event, trigger, player) { },
        group: "shuoye_zhongzhan_use",
        subSkill: {
            use: {
                audio: "shuoye_zhongzhan",
                enable: "phaseUse",
                usable: 1,
                filter(event, player) {
                    return !player.hasSkill("shuoye_zhongzhan_effect");
                },
                prompt: "",
                async content(event, trigger, player) {
                    if (player.storage.shuoye_zhongzhan_effect) delete player.storage.shuoye_zhongzhan_effect;
                    await player.addAdditionalSkills("dchuanli_sunquan", "wushuang");
                    player.addSkill("shuoye_zhongzhan_effect");
                },
                ai: {
                    order: 1,
                },
            },
            effect: {
                charlotte: true,
                onremove(player, skill) {
                    delete player.storage[skill];
                },
                trigger: {
                    player: "phaseAfter",
                },
                forced: true,
                popup: false,
                async content(event, trigger, player) {
                    if (!player.storage.shuoye_zhongzhan_effect) {
                        player.storage.shuoye_zhongzhan_effect = true;
                    } else {
                        await player.removeAdditionalSkills("shuoye_zhongzhan_effect");
                        player.removeSkill("shuoye_zhongzhan_effect");
                    }
                },
                mod: {
                    cardEnabled(card, player) {
                        if (get.name(card) == "shan") return false;
                    },
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_zhongzhan
//#noname-kit-begin skill:shuoye_abishu_skill
    shuoye_abishu_skill: {
        audio: "ext:朔夜/audio:2",
        equipSkill: true,
        mod: {
            cardUsable(card, player, num) {
                if (!player.isPhaseUsing()) return;
                if (card.name == "sha") return num++;
            },
        },
        group: ["shuoye_abishu_skill_damage", "shuoye_abishu_skill_use", "shuoye_abishu_skill_hujia"],
        subSkill: {
            damage: {
                audio: "shuoye_abishu_skill",
                trigger: {
                    source: "damageBegin1",
                },
                equipSkill: true,
                prompt2: "你造成伤害时，你可以可减少1点此牌的耐久度令此伤害加1。",
                async content(event, trigger, player) {
                    trigger.num++;
                    const cards = player.getCards("e", card => {
                        return card.name.startsWith("shuoye_abishu") && card.storage?.shuoye_abishu > 0;
                    });
                    for (const card of cards) {
                        card.storage.shuoye_abishu--;
                        game.log(card, "减少了", "#y1点", "#g耐久值");
                        game.broadcast(
                            (card, storage) => {
                                card.storage = storage;
                            },
                            card,
                            card.storage
                        );
                    }
                    await event.trigger("shuoye_abishuOnRemove");
                },
            },
            use: {
                audio: "shuoye_abishu_skill",
                equipSkill: true,
                enable: "chooseToUse",
                filter(event, player) {
                    return get.inpileVCardList(info => {
                        const name = info[2], type = get.type(name), infox = get.info({ name: name });
                        if (type != 'basic' && type != 'trick') return false;
                        if (!get.tag({ name: name }, 'damage')) return false;
                        if (get.info("xunshi").isXunshi({ name: name })) return false;
                        return !player.getStorage("shuoye_abishu_skill_use").includes(name);
                    }).some(card => event.filterCard({ name: card[2], nature: card[3] }, player, event));
                },
                chooseButton: {
                    dialog(event, player) {
                        const list = lib.inpile.slice().concat("binglinchengxiax").filter(name => {
                            const type = get.type(name), infox = get.info({ name: name });
                            if (type != 'basic' && type != 'trick') return false;
                            if (!get.tag({ name: name }, 'damage')) return false;
                            if (get.info("xunshi").isXunshi({ name: name })) return false;
                            return !player.getStorage("shuoye_abishu_skill_use").includes(name);
                        }).filter(name => event.filterCard({ name: name }, player, event));
                        return ui.create.dialog('阿比舒', [list, 'vcard']);
                    },
                    check(button) {
                        if (_status.event.getParent().type != 'phase') return 1;
                        return get.event('player').getUseValue({ name: button.link[2], nature: button.link[3] });
                    },
                    backup(links, player) {
                        return {
                            viewAs: {
                                name: links[0][2],
                                nature: links[0][3],
                            },
                            filterCard: () => false,
                            selectCard: -1,
                            ai1(card) {
                                return 1;
                            },
                            log: false,
                            async precontent(event, trigger, player) {
                                if (!player.storage.shuoye_abishu_skill_use) {
                                    player.when("phaseEnd")
                                        .then(() => {
                                            delete player.storage.shuoye_abishu_skill_use;
                                        });
                                }
                                player.markAuto("shuoye_abishu_skill_use", [event.result.card.name]);
                                const cards = player.getCards("e", card => {
                                    return card.name.startsWith("shuoye_abishu") && card.storage?.shuoye_abishu > 0;
                                });
                                for (const card of cards) {
                                    card.storage.shuoye_abishu--;
                                    game.log(card, "减少了", "#y1点", "#g耐久值");
                                    game.broadcast(
                                        (card, storage) => {
                                            card.storage = storage;
                                        },
                                        card,
                                        card.storage
                                    );
                                }
                                await event.trigger("shuoye_abishuOnRemove");
                            },
                        }
                    },
                    prompt(links, player) {
                        return "视为使用一张" + (get.translation(links[0][3]) || "") + get.translation(links[0][2]);
                    },
                },
                hiddenCard(player, name) {
                    return lib.inpile.includes(name) && player.getStorage("shuoye_abishu_skill_use").includes(name);
                },
                ai: {
                    order: 1,
                    respondSha: true,
                    skillTagFilter(player, tag, arg) {
                        if (arg == 'respond') return false;
                        return get.info('shuoye_abishu_skill_use').hiddenCard(player, 'sha');
                    },
                    result: {
                        player: 1,
                    },
                },
            },
            use_backup: {},
            hujia: {
                audio: "shuoye_abishu_skill",
                trigger: {
                    player: "damageEnd",
                },
                forced: true,
                equipSkill: true,
                filter(event, player) {
                    return !player.hujia;
                },
                async content(event, trigger, player) {
                    player.changeHujia(1);
                    const cards = player.getCards("e", card => {
                        return card.name.startsWith("shuoye_abishu") && card.storage?.shuoye_abishu > 0;
                    });
                    for (const card of cards) {
                        card.storage.shuoye_abishu--;
                        game.log(card, "减少了", "#y1点", "#g耐久值");
                        game.broadcast(
                            (card, storage) => {
                                card.storage = storage;
                            },
                            card,
                            card.storage
                        );
                    }
                    await event.trigger("shuoye_abishuOnRemove");
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_abishu_skill
//#noname-kit-begin skill:shuoye_abishu_effect
    shuoye_abishu_effect: {
        audio: "shuoye_abishu_skill",
        equipSkill: true,
        trigger: {
            player: ["loseBefore", "shuoye_abishuOnRemove", "equipBefore", "equipAfter"],
        },
        filter(event, player, name) {
            if (name == "shuoye_abishuOnRemove") {
                return player.hasCard(card => card.name.startsWith("shuoye_abishu") && card.storage?.shuoye_abishu <= 0, "e");
            }
            if (event.name == "equip") {
                if (name == "equipBefore") return true;
                if (!event.card.name.startsWith("shuoye_abishu")) return false;
                return player.hasCard(card => {
                    return !event.cards.includes(card) && lib.filter.cardDiscardable(card, player);
                }, "e");
            }
            if (event.getParent(2).name == "disableEquip") return false;
            if (event.getParent(3).name == "shuoye_abishu" || event.getParent(3).name == "shuoye_abishu_recast") return false;
            return player.hasCard(card => {
                if (!event.cards.includes(card)) return false;
                return card.name.startsWith("shuoye_abishu") && card.storage?.shuoye_abishu > 0;
            }, "e");
        },
        forced: true,
        async content(event, trigger, player) {
            if (event.triggername == "shuoye_abishuOnRemove") {
                const cards = player.getCards("e", card => card.name.startsWith("shuoye_abishu") && card.storage?.shuoye_abishu <= 0);
                await player.lose(cards, ui.special);
                for (const card of cards) {
                    card.fix();
                    card.remove();
                    card.destroyed = true;
                }
                game.log(cards, "被移出了游戏");
            } else if (trigger.name == "equip") {
                if (event.triggername == "equipBefore") {
                    trigger.cancel();
                    if (trigger.cards.length) await player.recast(trigger.cards);
                }
                else {
                    const cards = player.getCards("e", card => {
                        return !trigger.cards.includes(card) && lib.filter.cardRecastable(card, player);
                    });
                    await player.changeHujia(1);
                    await player.recast(cards);
                }
            } else {
                const cards = player.getCards("e", card => {
                    if (!trigger.cards.includes(card)) return false;
                    return card.name.startsWith("shuoye_abishu") && card.storage?.shuoye_abishu > 0;
                });
                trigger.cards.removeArray(cards);
                for (const card of cards) {
                    card.storage.shuoye_abishu--;
                    game.log(card, "减少了", "#y1点", "#g耐久值");
                    game.broadcast(
                        (card, storage) => {
                            card.storage = storage;
                        },
                        card,
                        card.storage
                    );
                }
                await event.trigger("shuoye_abishuOnRemove");
            }
        },
    },
//#noname-kit-end skill:shuoye_abishu_effect
    //艾丽丝
//#noname-kit-begin skill:shuoye_qingsao
    shuoye_qingsao: {
        enable: "phaseUse",
        usable: 1,
        filterCard: () => false,
        selectCard: -1,
        async content(event, trigger, player) {
            const judgeEvent = player.judge(card => {
                if (get.type(card) != "equip") return 2;
                return -1;
            });
            judgeEvent.judge2 = result => result.bool;
            const { result } = await judgeEvent;
            const suit = get.suit(result.card);
            if (result.bool) {
                const list = get.inpileVCardList(info => {
                    const name = info[2], nature = info[3], type = get.type(name), infox = get.info({ name: name });
                    if (nature) return false;
                    return type == get.type2(result.card);
                }).filter(card => player.hasUseTarget({ name: card[2], nature: card[3] }));
                if (!list.length) return;
                const { result: { bool, links } } = await player.chooseButton(["是否将一张牌当下列一张牌使用？", [list, "vcard"]])
                    .set("ai", function (button) {
                        return _status.event.player.getUseValue({
                            name: button.link[2],
                            nature: button.link[3],
                        });
                    });
                game.broadcastAll(
                    function (card) {
                        lib.skill.shuoye_qingsao_backup.viewAs = card;
                    },
                    { name: links[0][2] },
                );
                var next = player.chooseToUse();
                next.set("filterCard", card => get.suit(card) == suit);
                next.set("openskilldialog", "将一张牌当做" + get.translation(links[0][2]) + "使用");
                next.set("norestore", true);
                next.set("addCount", false);
                next.set("_backupevent", "shuoye_qingsao_backup");
                next.set("custom", {
                    add: {},
                    replace: { window() { } },
                });
                next.backup("shuoye_qingsao_backup");
                if (!player.hasSkill("shuoye_guanga_effect")) {
                    next.set("selectTarget", 1);
                }
                event.result = await next.forResult();
            } else event.result = { bool: false, }
            if (event.result.bool || !result.bool) {
                if (get.position(result.card, true) == "d") {
                    await player.gain(result.card);
                }
                if (player.getStat("skill").shuoye_qingsao) delete player.getStat("skill").shuoye_qingsao;
                player.addSkill("shuoye_qingsao_record");
                if (!player.getStorage("shuoye_qingsao_record").includes(suit)) {
                    player.markAuto("shuoye_qingsao_record", [suit]);
                } else {
                    await player.loseHp();
                }
            }
        },
        ai: {
            order: 8,
            result: {
                player: 1,
            },
        },
        subSkill: {
            backup: {

            },
            record: {
                charlotte: true,
                onremove: true,
            },
        },
    },
//#noname-kit-end skill:shuoye_qingsao
//#noname-kit-begin skill:shuoye_zhongshen
    shuoye_zhongshen: {
        trigger: {
            player: "dying",
        },
        locked: false,
        filter(event, player) {
            return player.getAllHistory("useSkill", evt => evt.skill == "shuoye_zhongshen").length < 3;
        },
        async content(event, trigger, player) {
            var cards = [];
            for (var i of lib.suit) {
                var card = get.cardPile(function (card) {
                    return get.suit(card, false) == i;
                });
                if (card) cards.push(card);
            }
            if (cards.length) {
                await player.gain(cards, "gain2");
                player.addGaintag(cards, "shuoye_zhongshen");
            }
        },
        onremove(player, skill) {
            player.removeGaintag(skill);
        },
        mod: {
            ignoredHandcard(card) {
                if (card.hasGaintag("shuoye_zhongshen")) return true;
            },
            cardDiscardable(card, player, name) {
                if (name == "phaseDiscard" && card.hasGaintag("shuoye_zhongshen")) return false;
            },
        },
    },
//#noname-kit-end skill:shuoye_zhongshen
//#noname-kit-begin skill:shuoye_guanga
    shuoye_guanga: {
        enable: "phaseUse",
        limited: true,
        skillAnimation: true,
        animationColor: "orange",
        async content(event, trigger, player) {
            player.awakenSkill(event.name);
            player.removeSkill("shuoye_qingsao_record");
            player.addTempSkill("shuoye_guanga_effect");
        },
        ai: {
            order: 10,
            result: {
                player(player) {
                    return player.getStorage("shuoye_qingsao_record").length >= 3;
                },
            },
        },
        subSkill: {
            effect: {
                charlotte: true,
            },
        },
    },
//#noname-kit-end skill:shuoye_guanga
    //虚构集
//#noname-kit-begin skill:shuoye_yixiang
    shuoye_yixiang: {
        trigger: {
            global: "useCardAfter",
        },
        forced: true,
        filter(event, player) {
            return !get.is.virtualCard(event.card);
        },
        async content(event, trigger, player) {
            if (trigger.targets?.length > 1) player.addMark("shuoye_yixiang_qunxiang");
            else player.addMark("shuoye_yixiang_dubai");
        },
        subSkill: {
            qunxiang: {
                marktext: "群像",
                intro: {
                    name: "群像",
                    content: "mark",
                },
            },
            dubai: {
                marktext: "独白",
                intro: {
                    name: "独白",
                    content: "mark",
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_yixiang
//#noname-kit-begin skill:shuoye_yinyu
    shuoye_yinyu: {
        trigger: {
            player: "useCardBefore",
        },
        usable(skill, player) {
            return 1 + player.countMark("shuoye_yinyu");
        },
        async cost(event, trigger, player) {
            const choiceList = [
                ["cardNameLength", "牌名字数"],
                ["type", "类型"],
                ["suit", "花色"],
            ];
            const { result: { bool, links } } = await player.chooseButton(2, [get.prompt2(event.name.slice(0, -5)), [choiceList, "tdnodes"]])
                .set("ai", button => {
                    return 1 + Math.random();
                });
            if (bool) event.result = { bool, cost_data: { links } };
        },
        async content(event, trigger, player) {
            trigger.card._shuoye_yinyu = true;
            const links = event.cost_data.links,
                mingzhi = get[links[0]](trigger.card),
                anzhi = (links[1] == "cardNameLength" ? "牌名字数" : (links[1] == "type" ? "类型" : "花色"));
            var choiceList;
            switch (links[1]) {
                case "cardNameLength": {
                    const num = Math.max(get.cardNameLength(trigger.card), 4)
                    choiceList = Array.from({ length: num }).map((_, info) => info + 1);
                }
                    break;
                case "type": {
                    choiceList = ["basic", "trick", "equip"];
                }
                    break;
                case "suit": {
                    choiceList = lib.suit;
                }
                    break;
            }
            player.say("声明了" + mingzhi);
            game.log(player, "声明了", mingzhi);
            const targets = game
                .filterPlayer(function (current) {
                    return current != player;
                })
                .sortBySeat(_status.currentPhase);
            const targets2 = [];
            for (const target of targets) {
                const { result } = await target.chooseButton(true, [`选择猜测${get.translation(player)}使用牌的${anzhi}`, [choiceList, "tdnodes"]])
                    .set("ai", button => {
                        return 1 + Math.random();
                    })
                if (result.bool) {
                    if (get[links[1]](trigger.card) == result.links[0]) {
                        targets2.add(target);
                        target.say("猜测正确");
                        game.log(target, "猜测正确");
                    } else {
                        target.say("猜测错误");
                        game.log(target, "猜测错误");
                        var card = get.discardPile(function (card) {
                            return card.name == "shuoye_xugouren";
                        });
                        if (card) await player.gain(card, "gain2");
                    }
                }
            }
            if (!targets2.length) {
                await player.gainMaxHp();
                player.addMark("shuoye_yinyu", 1, false);
            }
        },
    },
//#noname-kit-end skill:shuoye_yinyu
//#noname-kit-begin skill:shuoye_migong
    shuoye_migong: {
        trigger: {
            player: "useCard",
        },
        filter(event, player) {
            if (["shuoye_yixiang_qunxiang", "shuoye_yixiang_dubai"].every(mark => !player.countMark(mark))) return false;
            return event.card._shuoye_yinyu || event.card.name == "shuoye_xugouren";
        },
        async cost(event, trigger, player) {
            const choiceList = [
                ["shuoye_yixiang_qunxiang", "群像"],
                ["shuoye_yixiang_dubai", "独白"],
            ];
            const { result: { bool, links } } = await player.chooseButton([1, 2], [get.prompt2(event.name.slice(0, -5)), [choiceList, "tdnodes"]])
                .set("filterButton", button => {
                    const player = get.player(),
                        trigger = get.event().getTrigger();
                    if (!player.countMark(button.link)) return false;
                    if (button.link == "shuoye_yixiang_qunxiang") {
                        return game.hasPlayer(function (current) {
                            return !trigger.targets.includes(current) && lib.filter.targetEnabled2(trigger.card, player, current) && lib.filter.targetInRange(trigger.card, player, current);
                        });
                    }
                    return true;
                })
                .set("ai", button => {
                    return 1 + Math.random();
                });
            if (bool) event.result = { bool, cost_data: { links } }
        },
        async content(event, trigger, player) {
            const links = event.cost_data.links;
            if (links.includes("shuoye_yixiang_qunxiang")) {
                const targets = await player.chooseTarget(true)
                    .set("prompt", "请选择额外指定的目标")
                    .set("filterTarget", function (card, player, target) {
                        const trigger = _status.event.getTrigger();
                        return !trigger.targets.includes(target) && lib.filter.targetEnabled2(trigger.card, player, target) && lib.filter.targetInRange(trigger.card, player, target);
                    })
                    .set("selectTarget", () => {
                        const player = get.player();
                        return [1, player.countMark("shuoye_yixiang_qunxiang")];
                    })
                    .set("ai", target => {
                        const player = get.player(),
                            trigger = get.event().getTrigger();
                        return get.effect(target, trigger.card, player, player) + 0.01;
                    })
                    .forResultTargets();
                player.line(targets);
                player.removeMark("shuoye_yixiang_qunxiang", targets.length);
                if (!event.isMine() && !event.isOnline()) await game.asyncDelay();
                game.log(targets, "成为了", trigger.card, "的额外目标");
                trigger.targets.addArray(targets);
            }
            if (links.includes("shuoye_yixiang_dubai")) {
                const { result } = await player.chooseButton(true, ["选择视为使用一张牌", [["sha", "jiu"], "vcard"]])
                    .set("ai", button => {
                        const player = get.player();
                        return player.getUseValue(button.link);
                    })
                player.removeMark("shuoye_yixiang_dubai");
                player.when("useCardAfter")
                    .filter(event => event == trigger)
                    .then(() => {
                        if (player.hasUseTarget({ name: name }, true, false)) player.chooseUseTarget({ name: name }, false, true);
                    })
                    .vars({ name: result.links[0][2] })
            }
        },
    },
//#noname-kit-end skill:shuoye_migong
//#noname-kit-begin skill:shuoye_xugou
    shuoye_xugou: {
        trigger: {
            global: "phaseBefore",
            player: "enterGame",
        },
        forced: true,
        filter(event, player) {
            return (event.name != "phase" || game.phaseNumber == 0) && !lib.inpile.includes("qizhengxiangsheng");
        },
        content() {
            var cards = [];
            for (var i = 2; i < 10; i++) {
                cards.push(game.createCard2("shuoye_xugouren", i % 2 ? "club" : "spade", i));
            }
            game.broadcastAll(function () {
                lib.inpile.add("shuoye_xugouren");
            });
            game.cardsGotoPile(cards, () => {
                return ui.cardPile.childNodes[get.rand(0, ui.cardPile.childNodes.length - 1)];
            });
        },
        group: "shuoye_xugou_remove",
        subSkill: {
            remove: {
                trigger: {
                    target: "useCardToBefore",
                },
                forced: true,
                priority: 15,
                filter(event, player) {
                    return event.card && event.card.name == "shuoye_xugouren";
                },
                content() {
                    trigger.cancel();
                },
                ai: {
                    effect: {
                        target(card, player, target) {
                            if (card && card.name == "shuoye_xugouren") return "zeroplayertarget";
                        },
                    },
                },
            },
        },
    },
//#noname-kit-end skill:shuoye_xugou
};

export default skills;
