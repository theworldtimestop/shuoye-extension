import { lib, game, ui, get, ai, _status } from "noname"

const characterTitles = {
	shuoye_zuguoren: "渴爱",
	shuoye_feiniaomashi:'秘密女仆',
	shuoye_ailisi:'女仆勇者',
};
export default characterTitles;
