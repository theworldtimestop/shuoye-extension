import { lib, game, ui, get, ai, _status } from "../../../../noname.js";
import characters from "./character.js";
import cards from "./card.js";
import pinyins from "./pinyin.js";
import skills from "./skill.js";
import translates from "./translate.js";
import characterIntros from "./intro.js";
import characterFilters from "./characterFilter.js";
import characterTitles from "./characterTitle.js";
import characterReplaces from "./characterReplace.js";
import dynamicTranslates from "./dynamicTranslate.js";
import voices from "./voices.js";
import { characterSort, characterSortTranslate } from "./sort.js";

game.import("character", function () {
	const shuoye= {
		name: "shuoye",
		connect: true,
		character: { ...characters },
		characterSort: {
			shuoye: characterSort,
		},
		characterFilter: { ...characterFilters },
		characterTitle: {...characterTitles},
		characterSubstitute: {
			shuoye_miaoshitiannv: [["shuoye_miaoshitiannv_shadow", ["ext:朔夜/image/shuoye_miaoshitiannv_shadow.jpg"]]],
			shuoye_huangquan: [["shuoye_huangquan_shadow", ["ext:朔夜/image/shuoye_huangquan_shadow.jpg"]]],
			shuoye_fengchuanxiangzi: [["shuoye_fengchuanxiangzi_shadow", ["ext:朔夜/image/shuoye_fengchuanxiangzi_shadow.jpg"]]],
			shuoye_tianqixinghun: [["shuoye_tianqixinghun_shadow", ["ext:朔夜/image/shuoye_tianqixinghun_shadow.png"]]],
		},
		dynamicTranslate: { ...dynamicTranslates },
		characterIntro: { ...characterIntros },
		characterReplace: { ...characterReplaces },
		card: { ...cards },
		skill: { ...skills },
		translate: { ...translates, ...voices, ...characterSortTranslate },
		pinyins: { ...pinyins },
	};
	if(lib.device||lib.node){
        for (let i in shuoye.character){
            shuoye.character[i][4].push('ext:朔夜/image/' + i + '.jpg');
        }
    }
    else{
        for(let i in shuoye.character) {
            shuoye.character[i][4].push('db:extension-朔夜:'+i+'.jpg');
        }
    }
    lib.config.all.characters.push('shuoye');
    lib.translate['shuoye_character_config']='朔夜';
    return shuoye;
});

